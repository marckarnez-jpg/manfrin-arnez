const H=require('./a1lib');const {L,row,fs}=H;
(async()=>{const b=await L.browser();
 // backup gerado pela 6.2-dev.1 (bk_main.json) restaurado na 6.1 DEV anterior (DEV_FILE aponta para a antiga)
 const bk=JSON.parse(fs.readFileSync('bk_main.json','utf8'));
 // leitura do livro-caixa gravado pela 6.2 (com chaves extras prev/quarentena presentes) pela 6.1 anterior
 const led=JSON.stringify([row(1),row(2)]);
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':led,'ma-ledger-v1-prev':'[]','ma-ledger-v1-rejeitados-20260101000000':'{"x":1}'}});const p=r.page;
 const n=await H.shown(p);await H.addRow(p,'6.1 lendo dados da 6.2');const k=await H.appKeys(p);
 L.record('A1-80','6.1 anterior lê o livro-caixa gravado pela 6.2-dev.1 e ignora as chaves extras',(n===2&&JSON.parse(k['ma-ledger-v1']).length===3&&k['ma-ledger-v1-prev']==='[]')?'APROVADO':'REPROVADO',`linhas vistas=${n}; após novo lançamento=${JSON.parse(k['ma-ledger-v1']).length}; chaves extras intactas=${k['ma-ledger-v1-prev']==='[]'}`);
 await p.evaluate(()=>go('backup'));const nav=p.waitForNavigation({timeout:40000}).catch(()=>null);
 await p.setInputFiles('#backup-load','bk_main.json');await nav;await H.reloadWait(p);
 const k2=await H.appKeys(p);
 L.record('A1-81','Backup geral gerado pela 6.2-dev.1 é restaurável na 6.1 anterior',(JSON.parse(k2['ma-ledger-v1']).length===bk.ledger.length&&bk.format==='manfrin-arnez-backup'&&bk.version===2)?'APROVADO':'REPROVADO',`formato=${bk.format} v${bk.version}; lançamentos no backup=${bk.ledger.length}, após restaurar=${JSON.parse(k2['ma-ledger-v1']).length}; campos de topo=[${Object.keys(bk).join(', ')}]`);
 fs.writeFileSync('r_compat.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);process.exit(1)});
