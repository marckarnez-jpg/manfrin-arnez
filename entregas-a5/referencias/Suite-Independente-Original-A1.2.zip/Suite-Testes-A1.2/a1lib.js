const L=require('./lib');const fs=require('fs');
const row=(i,x={})=>({id:'Cora:T'+i,date:'2026-09-0'+i,bank:'Cora',description:'Lanc ficticio '+i,amount:1000*i,kind:'Receita',...x});
const reloadWait=p=>p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});
const appKeys=async(p)=>{const raw=await L.rawStore(p,true);const o={};for(const k in raw)if(k.startsWith(L.PREFIX))o[k.slice(L.PREFIX.length)]=raw[k].text;return o};
const realKeys=async(p)=>{const raw=await L.rawStore(p);const o={};for(const k in raw)if(!k.startsWith(L.PREFIX))o[k]=raw[k].hash;return o};
const get=(p,k)=>p.evaluate(k=>localStorage.getItem(k),k);
const toLedger=p=>p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
async function addRow(p,desc,val='50',date='2026-10-05'){await p.evaluate(([d,v,dt])=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value=dt;f.elements.description.value=d;f.elements.amount.value=v;f.requestSubmit()},[desc,val,date]);await p.waitForTimeout(500);return msg(p)}
const msg=p=>p.evaluate(()=>document.getElementById('ledger-message')?.textContent||'');
const shown=p=>p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}));return document.querySelectorAll('#transactions select[data-row]').length});
const banner=p=>p.evaluate(()=>{const e=document.getElementById('ma62-ledger-alert');return e?{text:e.textContent.slice(0,260),visibleHere:!!(e.offsetParent)}:null});
const qKeys=ks=>Object.keys(ks).filter(k=>k.startsWith('ma-ledger-v1-rejeitados-'));
const SENT=()=>({'ma-care-v2':JSON.stringify({version:2,patients:[{id:'SENT1',name:'SENTINELA-REAL',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]}),'ma-ledger-v1':JSON.stringify([{id:'SENT-L1',date:'2026-01-01',bank:'Cora',description:'SENTINELA-REAL-LANC',amount:999,kind:'Receita'}]),'ma-ledger-v1-prev':'SENTINELA-PREV','ma-ledger-v1-rejeitados-20260101000000':'SENTINELA-Q','ma-academy-v55':'{"version":55,"s":1}','ma61-sanitary-checklist-v1':'{"version":1,"s":1}'});
const saturate=p=>p.evaluate(()=>{let n=0;for(const size of [200000,50000,5000,500,50,5,1]){for(;;){try{localStorage.setItem('__fill'+n,'x'.repeat(size))}catch(e){break}n++}}return n});
const freeSpace=(p,F)=>p.evaluate(F=>{localStorage.removeItem('__fill0');localStorage.setItem('__fill0','x'.repeat(200000-F));return true},F);
const unfill=p=>p.evaluate(()=>{for(let i=0;i<4000;i++)localStorage.removeItem('__fill'+i)});
const same=(a,b)=>a===b;
module.exports={L,fs,row,reloadWait,appKeys,realKeys,get,toLedger,addRow,msg,shown,banner,qKeys,SENT,saturate,freeSpace,unfill,same};
