// B1: AJ-1 — backup geral
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
(async()=>{const b=await L.browser();let r,p,k,dl,m;
 // B-10 legado só na categoria: corrigir pela UI destrava?
 const LEG2=JSON.stringify([...ok3,{id:'Cora:Z',date:'2026-09-09',bank:'Cora',description:'categoria antiga',amount:700,kind:'Pix'}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':LEG2}});p=r.page;
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 const sel=await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row="3"]');if(!s)return null;s.value='Receita';s.dispatchEvent(new Event('change',{bubbles:true}));return true});await p.waitForTimeout(600);
 k=await B.appKeys(p);const z=JSON.parse(k['ma-ledger-v1']).find(x=>x.id==='Cora:Z');
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},6000);
 R('B-10','Legado com categoria inválida: corrigir a categoria pela tela remove a marcação e libera o backup',!!z&&z.kind==='Receita'&&!!dl,`select encontrado=${!!sel}; kind gravado=${z&&z.kind}; backup após corrigir=${!!dl}; msg="${(await B.bmsg(p)).slice(0,100)}"`,'AMARELO');
 await r.ctx.close();
 // B-11 cadastro ilegível (readError)
 for(const [nm,val] of [['JSON inválido','{bad json'],['versão desconhecida','{"version":99,"patients":[{"id":"P1"}],"records":[],"notes":[]}']]){
  r=await L.openDev(b,{seed:{'ma-care-v2':val,'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
  dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(p);k=await B.appKeys(p);
  R('B-11-'+(nm[0]==='J'?'a':'b'),`Cadastro com ${nm}: backup geral não finge conter os pacientes; dado armazenado intacto`,!dl&&/BLOQUEADO/i.test(m)&&k['ma-care-v2']===val,`arquivo=${!!dl}; cadastro intacto=${k['ma-care-v2']===val}; msg="${m.slice(0,150)}"`,'VERMELHO');
  await r.ctx.close();}
 // B-12 duas abas (memória desatualizada)
 const ctx=await b.newContext({acceptDownloads:true});
 await ctx.addInitScript(({s,P})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(s))localStorage.setItem(P+k,v)}}catch(e){}},{s:{'ma-ledger-v1':JSON.stringify(ok3)},P:L.PREFIX});
 const mk=async()=>{const pg=await ctx.newPage();pg.on('dialog',d=>d.accept());await pg.goto(L.DEV,{timeout:240000});await pg.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return pg};
 const A=await mk(),Bp=await mk();
 await B.addRow(Bp,'da aba B','77');
 dl=await B.tryDownload(A,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(A);
 R('B-12','Duas abas: backup na aba desatualizada é recusado (não exporta lista antiga)',!dl&&/outra aba|recarregue/i.test(m),`arquivo=${!!dl}; msg="${m.slice(0,160)}"`,'AMARELO');
 await ctx.close();
 fs.writeFileSync('r_b1x.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b1x.json',JSON.stringify(L.results,null,1));process.exit(1)});
