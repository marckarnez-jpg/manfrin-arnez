const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
(async()=>{const b=await L.browser();let r,p,k,dl;
 // exclusão limpa mensagem antiga (AJ-7)
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(10))}});p=r.page;
 await B.addRow(p,'primeiro','5');await B.saturate(p);const mf=await B.addRow(p,'falha','5');await B.freeSpace(p,200000);
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 await p.evaluate(()=>document.querySelector('#transactions [data-delete]').click());await p.waitForTimeout(500);const md=await B.msg(p);
 R('B-77','AJ-7: depois de falha por falta de espaço, uma exclusão bem-sucedida limpa a mensagem de erro antiga',/Não foi possível salvar/i.test(mf)&&!/Não foi possível salvar/i.test(md),`msg da falha="${mf.slice(0,60)}"; msg após excluir="${md}"`,'AMARELO');
 await r.ctx.close();
 // original bruto em estado de quarentena = texto armazenado
 const Q=JSON.stringify([...ok3,{foo:1}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':Q}});p=r.page;
 dl=await B.tryDownload(p,()=>{[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/original bruto/i.test(x.textContent)).click()});const tx=await B.saveDl(dl,'raw_b78.json');
 R('B-78','Faixa: "Baixar original bruto" em estado de quarentena devolve o texto armazenado exato (inclui a linha rejeitada)',tx===Q,`idêntico=${tx===Q}; arquivo=${dl&&dl.suggestedFilename()}`,'AMARELO');
 await r.ctx.close();
 // restaurar backup limpo com quarentena presente: o backup volta a ser possível?
 const bk={format:'manfrin-arnez-backup',version:2,care:{version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]},ledger:[{id:'Cora:R5',date:'2026-09-05',bank:'Cora',description:'Restaurado ficticio',amount:5000,kind:'Receita'}],rateSettings:{}};
 fs.writeFileSync('bk_restore_b79.json',JSON.stringify(bk));
 r=await L.openDev(b,{seed:{'ma-ledger-v1':Q}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_restore_b79.json');
 await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1500);
 k=await B.appKeys(p);
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},5000);const mm=await B.bmsg(p);
 R('B-79','Depois de RESTAURAR um backup limpo, o backup geral volta a funcionar (quarentena antiga não deve travar para sempre)',!!dl,`livro após restaurar=${JSON.parse(k['ma-ledger-v1']).length} linha(s); chaves de quarentena restantes=${B.qKeys(k).length}; backup gerado=${!!dl}; msg="${mm.slice(0,110)}"`,'VERMELHO');
 await r.ctx.close();
 fs.writeFileSync('r_b9.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b9.json',JSON.stringify(L.results,null,1));process.exit(1)});
