// T4: preservação de módulos, desempenho, cota, P1-7b refeito
const L=require('./lib');const fs=require('fs');
const read=(p,k)=>p.evaluate(k=>localStorage.getItem(k),k);
(async()=>{const b=await L.browser();
 {const r=await L.openDev(b);const p=r.page;
  // Financeiro
  const fin=await p.evaluate(()=>{go('dash');const d=document.getElementById('dash').innerText.length;go('accounting');const a=document.getElementById('accounting').innerText.length;go('ledger');return {d,a}});
  await p.evaluate(()=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value='Lanc DEV modulo';f.elements.amount.value='50';f.requestSubmit()});await p.waitForTimeout(500);
  let led=JSON.parse(await read(p,'ma-ledger-v1')||'[]');
  const [dl]=await Promise.all([p.waitForEvent('download'),p.evaluate(()=>document.getElementById('export').click())]);
  await dl.saveAs('exp.csv');const csv=fs.readFileSync('exp.csv','utf8');
  L.record('MOD-FIN','Financeiro: dashboard, contabilidade, conciliação, lançamento e exportação CSV',(fin.d>100&&fin.a>100&&led.length>=1&&csv.includes('Lanc DEV modulo'))?'APROVADO':'REPROVADO',`texto dash=${fin.d} acct=${fin.a}; lançamentos gravados=${led.length}; CSV baixado contém o lançamento=${csv.includes('Lanc DEV modulo')} (${csv.split('\n')[0].slice(0,60)})`);
  // Simulador
  const sim=await p.evaluate(()=>{go('sim');const t0=document.getElementById('sim').innerText;const set=(i,v)=>{const e=document.getElementById(i);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))};set('sale','10000');set('entry','1000');document.getElementById('installments').value='3';document.getElementById('installments').dispatchEvent(new Event('change',{bubbles:true}));const t1=document.getElementById('sim').innerText;return {changed:t0!==t1,len:t1.length,rates:document.querySelectorAll('#ma53-rates-table input[data-rate]').length,ma57:!!document.getElementById('ma57-save')}});
  L.record('MOD-SIM','Simulador: entradas recalculam resultado; tabela de taxas 1x–10x; bloco ma57 presente',(sim.changed&&sim.rates===10&&sim.ma57)?'APROVADO':'REPROVADO',`resultado muda ao editar=${sim.changed}; campos de taxa=${sim.rates}; ma57=${sim.ma57}`);
  // Pacientes
  const pat=await p.evaluate(()=>{go('patients');const s=document.getElementById('patient-search');s.value='a';s.dispatchEvent(new Event('input',{bubbles:true}));return {len:document.getElementById('patients').innerText.length}});
  const careBefore=JSON.parse(await read(p,'ma-care-v2')).patients.length;
  await p.evaluate(()=>{document.getElementById('new-patient').click();const f=document.getElementById('patient-form');f.elements.name.value='Paciente Ficticio Modulo';f.requestSubmit()});await p.waitForTimeout(700);
  const careAfter=JSON.parse(await read(p,'ma-care-v2'));
  const added=careAfter.patients.some(x=>x.name==='Paciente Ficticio Modulo');
  L.record('MOD-PAC','Pacientes: lista, busca e cadastro persistido',(pat.len>200&&added)?'APROVADO':'REPROVADO',`pacientes antes=${careBefore}, depois=${careAfter.patients.length}; novo paciente gravado=${added}`);
  // Academia/Laboratório/Exocad
  const lab=await p.evaluate(async()=>{go('ma55-academy');const q=s=>document.querySelector(s);const res={};
   const btns=[...document.querySelectorAll('#ma55-academy button')];const byText=t=>btns.find(b=>b.textContent.includes(t));
   res.studio=!!byText('Estúdio visual');res.oficina=!!byText('Oficina visual');res.wash=!!byText('Laboratório guiado');
   byText('Estúdio visual')?.click();await new Promise(r=>setTimeout(r,200));res.studioSteps=(document.getElementById('ma58-steps')?.textContent||'').length;
   byText('Oficina visual')?.click();await new Promise(r=>setTimeout(r,200));res.workCards=document.querySelectorAll('#ma59-cards [data-piece]').length;
   byText('Laboratório guiado')?.click();await new Promise(r=>setTimeout(r,200));res.washStages=document.querySelectorAll('#ma60-wash-stages > *').length;
   res.blastTab=!!document.querySelector('[data-ma60-tab=blast]');
   res.exocadPdf=typeof window.ma59ManualExocad==='string'&&window.ma59ManualExocad.startsWith('JVBER');res.exocadLen=(window.ma59ManualExocad||'').length;
   res.docBtns=[...document.querySelectorAll('#ma59-docs [data-doc]')].map(b=>b.dataset.doc);
   res.pops=document.getElementById('ma55-pop-list')?.children.length;
   return res});
  const labOk=lab.studio&&lab.oficina&&lab.wash&&lab.studioSteps>0&&lab.workCards>=8&&lab.exocadPdf&&lab.blastTab;
  L.record('MOD-ACAD','Academia/POPs, Laboratório Digital (maquiagem 5.8, oficina 5.9, lavagem/jateamento 6.0) e manual Exocad embutido',labOk?'APROVADO':'REPROVADO',JSON.stringify(lab));
  // Sanitário presente
  const san=await p.evaluate(()=>({n:document.querySelectorAll('#ma61-groups details.ma61-group').length}));
  L.record('MOD-SAN','Central Sanitária presente e renderizada',san.n===8?'APROVADO':'REPROVADO',`grupos renderizados=${san.n}`);
  // DESEMPENHO: custo isolado de mergeCodental
  const perf=await p.evaluate(()=>{const g=window;if(typeof g.mergeCodental!=='function')return {fn:false};const db=JSON.parse(JSON.stringify(g.MA_SEED));const t=performance.now();const res=g.mergeCodental(db,g.MA_CODENTAL);return {fn:true,ms:Math.round(performance.now()-t),pac:res.db.patients.length,seed:g.MA_SEED.patients.length,cod:g.MA_CODENTAL.patients?.length}});
  L.record('P0-4','Desempenho: mergeCodental (executa em toda abertura) com dados DEV',perf.ms>5000?'REPROVADO':'APROVADO',`mergeCodental isolado=${perf.ms} ms (seed ${perf.seed} + feed ${perf.cod} → ${perf.pac} pacientes); carga total da página=${r.loadMs} ms`,{amarelo:perf.ms>5000});
  // COTA
  const q=await p.evaluate(()=>{const filler='x'.repeat(100000);let n=0;try{for(;n<60;n++)localStorage.setItem('__fill'+n,filler)}catch(e){}const total=n*100000;const before=document.getElementById('storage-status')?.textContent;return {chunks:n,total}});
  await p.evaluate(()=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-06';f.elements.description.value='Lanc sob cota cheia';f.elements.amount.value='10';f.requestSubmit()});await p.waitForTimeout(700);
  const st=await p.evaluate(()=>({status:document.getElementById('storage-status')?.textContent?.slice(0,140),saved:(localStorage.getItem('ma-ledger-v1')||'').includes('Lanc sob cota cheia')}));
  const warned=/não|falha|erro|cota|espaço/i.test(st.status||'')&&!st.saved;
  L.record('QUOTA-01','Cota cheia: falha de gravação é percebida pelo usuário?',st.saved?'NÃO TESTADO':(warned?'APROVADO':'AMARELO'),`enchimento ${q.total} chars de outras chaves até recusar; lançamento gravado=${st.saved}; mensagem="${st.status}"`);
  await p.evaluate(()=>{for(let i=0;i<60;i++)localStorage.removeItem('__fill'+i)});
  // errors
  L.record('SMK-03','Sem erros de console após uso dos módulos',r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length} ${r.errors.slice(0,3).join(' | ')}`);
  await r.ctx.close();}
 // P1-7b refeito com leitura REAL do armazenamento (rawStore)
 {const own=[{id:'Cora:T1',date:'2026-09-01',bank:'Cora',description:'Lanc ficticio 1',amount:1000,kind:'Receita'}];
  const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(own)}});const p=r.page;
  const k0=Object.keys(await L.rawStore(p)).sort();
  await p.evaluate(()=>go('backup'));
  const nav=p.waitForNavigation({timeout:30000}).catch(()=>null);
  await p.setInputFiles('#backup-load','bk_restore.json');await nav;
  await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:120000});
  const raw=await L.rawStore(p,true);const k1=Object.keys(raw).sort();
  const extra=k1.filter(k=>!k0.includes(k));
  const holdsOld=Object.values(raw).some(v=>v.text&&v.text.includes('Lanc ficticio 1'));
  L.record('P1-7b','Restauração preserva uma cópia automática dos dados anteriores?',holdsOld?'APROVADO':'REPROVADO',`chaves reais antes=${k0.length}, depois=${k1.length}; novas chaves=[${extra.map(k=>k.replace(L.PREFIX,'P:')).join(',')}]; algum valor armazenado ainda contém o lançamento anterior=${holdsOld} → ${holdsOld?'ok':'dados anteriores irrecuperáveis após restaurar (VERMELHO)'}`,{vermelho:!holdsOld});
  await r.ctx.close();}
 fs.writeFileSync('t4.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('t4.json',JSON.stringify(L.results,null,1));process.exit(1)});
