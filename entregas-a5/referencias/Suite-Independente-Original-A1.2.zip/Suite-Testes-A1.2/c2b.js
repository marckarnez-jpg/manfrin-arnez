// C2: A1.2 — AJ-13 (aprovação externa), AJ-14 (-prev e cópias por operação), AJ-15 (sem limite 900k, cota real, falhas)
const B=require('./b_lib');const {L,R,fs}=B;
const SNAP='ma-ledger-v1-session-prev-';
const snapKeys=k=>Object.keys(k).filter(x=>x.startsWith(SNAP)).sort();
async function ctxWith(b,seed,hook){const ctx=await b.newContext({acceptDownloads:true,viewport:{width:1280,height:900}});const page=await ctx.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message.slice(0,150)));
 page.on('dialog',d=>d.accept());
 await page.addInitScript(({seed,PREFIX})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(seed))localStorage.setItem(PREFIX+k,v);}}catch(e){}
  if(window===window.top){
   const so=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){const s=String(k);
     if(window.__failLedger&&s.endsWith('ma-ledger-v1'))throw new DOMException('QuotaExceededError','QuotaExceededError');
     return so.call(this,k,v)};
   const go_=Storage.prototype.getItem;Storage.prototype.getItem=function(k){const v=go_.call(this,k);if(window.__corruptSnap&&String(k).includes('session-prev-')&&v!==null)return v+'X';return v};
  }
 },{seed,PREFIX:L.PREFIX});
 await page.goto(L.DEV,{timeout:240000});await page.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return {ctx,page,errors}}
const nScreen=p=>B.shown(p);
const bannerBtn=(p,re)=>p.evaluate(src=>{go('ledger');const b=[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>new RegExp(src,'i').test(x.textContent));if(!b)return false;b.click();return true},re.source);
(async()=>{const b=await L.browser();let r,p,k,m,ai;
 const ok40=JSON.stringify(B.mkRows(40));
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok40}));
 await B.saturate(p);await B.freeSpace(p,500);m=await B.addRow(p,'tenta','5');
 const has=await p.evaluate(()=>go('ledger')||!!document.getElementById('ma62-verify-ledger-file'));
 fs.writeFileSync('ext_wrong.json',ok40.slice(0,-1)+' ]');
 await p.setInputFiles('#ma62-verify-ledger-file','ext_wrong.json');await p.waitForTimeout(600);m=await B.msg(p);
 let m2=await B.addRow(p,'apos errado','5');k=await B.appKeys(p);
 R('C-41','AJ-13: arquivo externo errado é rejeitado na verificação (mensagem "NÃO verificada") e a gravação continua recusada',has&&/NÃO verificada/i.test(m)&&k['ma-ledger-v1']===ok40,`input presente=${has}; msg verificação="${m.slice(0,140)}"; livro intacto=${k['ma-ledger-v1']===ok40}; msg gravação="${m2.slice(0,80)}"`,'AMARELO');
 fs.writeFileSync('ext_ok.json',ok40);
 await p.setInputFiles('#ma62-verify-ledger-file','ext_ok.json');await p.waitForTimeout(600);const mv=await B.msg(p);ai=await B.alertInfo(p);
 m=await B.addRow(p,'verificado','5');k=await B.appKeys(p);ai=await B.alertInfo(p);
 const wroteV=JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='verificado');
 R('C-42','AJ-13: arquivo externo idêntico (verificado pelo conteúdo) libera uma operação e o estado é rotulado "verificado pelo conteúdo"',wroteV&&/verificad[ao] pelo conteúdo/i.test(ai.text),`gravou=${wroteV}; faixa="${ai.text.slice(0,260)}"`,'AMARELO');
 m=await B.addRow(p,'segunda','5');k=await B.appKeys(p);
 R('C-42b','AJ-13: a verificação por conteúdo também vale uma única operação',!JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='segunda'),`msg="${m.slice(0,100)}"`,'VERMELHO');
 // arquivo externo de estado antigo (livro mudou depois do download)
 await r.close();
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c2b.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c2b.json',JSON.stringify(L.results,null,1)));
