const B=require('./b_lib');const {L,R,fs}=B;const row=(i,x={})=>({id:'Cora:T'+i,date:'2026-09-0'+i,bank:'Cora',description:'Lanc ficticio '+i,amount:1000*i,kind:'Receita',...x});
async function ctxWith(b,seed,hook){const ctx=await b.newContext({acceptDownloads:true,viewport:{width:1280,height:900}});const page=await ctx.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message.slice(0,150)));page.on('dialog',d=>d.accept());
 await page.addInitScript(({seed,PREFIX,hook})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(seed))localStorage.setItem(PREFIX+k,v);}}catch(e){}
  if(hook==='quarantine-fail'){const o=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(String(k).includes('rejeitados'))throw new DOMException('QuotaExceededError','QuotaExceededError');return o.call(this,k,v)}}
 },{seed,PREFIX:L.PREFIX,hook});
 await page.goto(L.DEV,{timeout:240000});await page.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return {ctx,page,errors}}
(async()=>{const b=await L.browser();
 const bad={id:'Cora:BAD',date:'2026-09-09',bank:'Cora',description:'<img src=x onerror="window.__x=1">',kind:'Receita'};
 const RAW=JSON.stringify([row(1),bad,row(2)]);
 {const {ctx,page:p,errors}=await ctxWith(b,{'ma-ledger-v1':RAW},null);
  await p.evaluate(()=>{go('dash');document.querySelector('#ma62-ledger-alert details').open=true});
  const stored=await B.appKeys(p);const qk=B.qKeys(stored);
  const dl=await B.tryDownload(p,()=>{document.querySelector('#ma62-ledger-alert details button').click()});const tx=await B.saveDl(dl,'q_b81.json');
  const x=await p.evaluate(()=>({flag:window.__x,imgs:document.querySelectorAll('#ma62-ledger-alert img, #transactions img').length}));
  R('B-81','Download individual da quarentena devolve o corpo exato; conteúdo malicioso de linha rejeitada não executa nem aparece como HTML',qk.length===1&&tx===stored[qk[0]]&&JSON.parse(tx).rows[0].row.id==='Cora:BAD'&&!x.flag&&!x.imgs,`download=${!!dl}; idêntico ao armazenado=${tx===stored[qk[0]]}; window.__x=${x.flag}; <img> injetadas=${x.imgs}; erros=${errors.length}`,'VERMELHO');
  await ctx.close();}
 {const {ctx,page:p,errors}=await ctxWith(b,{'ma-ledger-v1':RAW},'quarantine-fail');
  const bn=await B.alertInfo(p);const m=await B.addRow(p,'tentativa sem quarentena');const k=await B.appKeys(p);
  R('B-80','Falha ao gravar a quarentena: livro-caixa bloqueado, original intacto, nada gravado',k['ma-ledger-v1']===RAW&&bn&&/BLOQUEADO/.test(bn.text)&&!('ma-ledger-v1-prev' in k)&&B.qKeys(k).length===0,`texto idêntico=${k['ma-ledger-v1']===RAW}; aviso="${bn&&bn.text.slice(0,110)}"; msg ao adicionar="${m.slice(0,70)}"; erros=${errors.length}`,'VERMELHO');
  await ctx.close();}
 fs.writeFileSync('r_b10.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b10.json',JSON.stringify(L.results,null,1));process.exit(1)});
