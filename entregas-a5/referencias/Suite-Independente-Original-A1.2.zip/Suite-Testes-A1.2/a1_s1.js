// S1: linha inválida entre válidas + isolamento com sentinelas reais (inclui as novas chaves)
const H=require('./a1lib');const {L,row}=H;
(async()=>{const b=await L.browser();
 const good=[row(1),row(2),row(3)];const bad={id:'Cora:BAD',date:'2026-09-09',bank:'Cora',description:'sem valor',kind:'Receita'};
 const seedRaw=JSON.stringify([good[0],good[1],bad,good[2]]);
 const SENT=H.SENT();
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':seedRaw},realSeed:SENT});const p=r.page;
 const real0=await H.realKeys(p);
 const k0=await H.appKeys(p);const q0=H.qKeys(k0);
 const nShown=await H.shown(p);const bn=await H.banner(p);
 let qbody=q0.length?JSON.parse(k0[q0[0]]):null;
 L.record('A1-01','Linha inválida entre válidas: válidas visíveis, original intacto, rejeitada em quarentena',(nShown===3&&k0['ma-ledger-v1']===seedRaw&&q0.length===1&&qbody?.rows?.length===1&&qbody.rows[0].index===3&&qbody.rows[0].row.id==='Cora:BAD'&&!('ma-ledger-v1-prev' in k0))?'APROVADO':'REPROVADO',
  `linhas exibidas=${nShown} (esperado 3); ma-ledger-v1 idêntico ao semeado=${k0['ma-ledger-v1']===seedRaw}; chaves de quarentena=${q0.length}; linhas rejeitadas=${qbody?.rows?.length} (posição ${qbody?.rows?.[0]?.index}, motivo "${qbody?.rows?.[0]?.reason?.slice(0,50)}"); chave prev ainda ausente=${!('ma-ledger-v1-prev' in k0)}`);
 L.record('A1-02','Aviso de quarentena visível na página do livro-caixa',(bn&&bn.visibleHere&&/1 linha/.test(bn.text))?'APROVADO':'REPROVADO',`aviso="${bn?.text?.slice(0,140)}"; visível=${bn?.visibleHere}`);
 // visibilidade fora da página Conciliação
 const other=await p.evaluate(()=>{const out={};for(const pg of ['ma56-home','dash','accounting','ma55-contador']){go(pg);const e=document.getElementById('ma62-ledger-alert');out[pg]=!!(e&&e.offsetParent)}return out});
 L.record('A1-03','Aviso aparece também nas telas que usam o livro-caixa (início, Visão financeira, Contabilidade, Relatório do contador)',Object.values(other).some(Boolean)?'APROVADO':'REPROVADO',`visível em: ${JSON.stringify(other)} → o aviso só existe dentro da Conciliação; quem abre o início ou o relatório do contador não vê o alerta`,{amarelo:true});
 // gravação 1
 const m1=await H.addRow(p,'Novo A1 s1');
 const k1=await H.appKeys(p);
 const main1=JSON.parse(k1['ma-ledger-v1']);
 L.record('A1-04','Novo lançamento com quarentena: válidas + novo gravadas, inválida fora do principal',(main1.length===4&&main1.every(x=>x.id!=='Cora:BAD')&&main1.some(x=>x.description==='Novo A1 s1'))?'APROVADO':'REPROVADO',`principal=${main1.length} linhas [${main1.map(x=>x.description).join('; ')}]; mensagem="${m1}"`);
 L.record('A1-05','Backup do estado anterior: ma-ledger-v1-prev é cópia byte a byte do texto original',k1['ma-ledger-v1-prev']===seedRaw?'APROVADO':'REPROVADO',`prev idêntico ao original=${k1['ma-ledger-v1-prev']===seedRaw} (${k1['ma-ledger-v1-prev']?.length} caracteres)`);
 L.record('A1-06','Quarentena preservada após a gravação (mesmo conteúdo, sem duplicar)',(H.qKeys(k1).length===1&&k1[q0[0]]===k0[q0[0]])?'APROVADO':'REPROVADO',`chaves de quarentena=${H.qKeys(k1).length}; conteúdo inalterado=${k1[q0[0]]===k0[q0[0]]}`);
 // gravações 2 e 3: categoria e exclusão
 await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row]');s.value='A classificar';s.dispatchEvent(new Event('change',{bubbles:true}))});await p.waitForTimeout(300);
 const kCat=await H.appKeys(p);
 await p.evaluate(()=>{document.querySelector('#transactions [data-delete]').click()});await p.waitForTimeout(300);
 const kDel=await H.appKeys(p);
 L.record('A1-07','Snapshot prev não muda em gravações seguintes da mesma sessão (categoria, exclusão)',(kCat['ma-ledger-v1-prev']===seedRaw&&kDel['ma-ledger-v1-prev']===seedRaw&&JSON.parse(kCat['ma-ledger-v1']).some(x=>x.kind==='A classificar'))?'APROVADO':'REPROVADO',`prev após categoria idêntico=${kCat['ma-ledger-v1-prev']===seedRaw}; após exclusão idêntico=${kDel['ma-ledger-v1-prev']===seedRaw}; categoria gravada=${JSON.parse(kCat['ma-ledger-v1']).filter(x=>x.kind==='A classificar').length>0}; linhas após exclusão=${JSON.parse(kDel['ma-ledger-v1']).length}`);
 // recarga: sem aviso, sem nova quarentena
 const afterSession=kDel['ma-ledger-v1'];
 await p.reload();await H.reloadWait(p);
 const k2=await H.appKeys(p);const bn2=await H.banner(p);
 L.record('A1-08','Após recarregar: dados persistem, sem nova quarentena, aviso some',(k2['ma-ledger-v1']===afterSession&&H.qKeys(k2).length===1&&!bn2)?'APROVADO':'REPROVADO',`principal inalterado=${k2['ma-ledger-v1']===afterSession}; chaves de quarentena=${H.qKeys(k2).length}; aviso=${bn2?'presente':'ausente'} → a linha rejeitada só existe agora na chave de quarentena e na cópia prev, sem nenhum aviso ou tela para revisá-la`);
 L.record('A1-09','A quarentena continua acessível ao usuário após recarregar (tela ou botão para revisar/recuperar)',(await p.evaluate(()=>!!document.querySelector('[data-ma62-quarantine], #ma62-ledger-alert')))?'APROVADO':'REPROVADO','Depois da primeira gravação e do reload não existe aviso, botão de download nem tela de revisão; a recuperação depende de abrir o armazenamento do navegador manualmente.',{amarelo:true});
 // sessão 2: prev passa a ser o estado da sessão 1
 await H.addRow(p,'Novo A1 s1 sessao2');
 const k3=await H.appKeys(p);
 L.record('A1-10','Limite do backup: ma-ledger-v1-prev guarda uma única geração',k3['ma-ledger-v1-prev']===seedRaw?'APROVADO':'REPROVADO',`após a primeira gravação da 2ª sessão, prev == original da 1ª sessão: ${k3['ma-ledger-v1-prev']===seedRaw}; prev agora == estado final da 1ª sessão: ${k3['ma-ledger-v1-prev']===afterSession}. O texto original só sobrevive (parcialmente) na chave de quarentena.`,{amarelo:true});
 // isolamento
 const real1=await H.realKeys(p);
 const changed=Object.keys(real0).filter(k=>real0[k]!==real1[k]);
 L.record('A1-11','Isolamento: 6 chaves reais fictícias (incl. ma-ledger-v1-prev e quarentena sentinelas) intactas e nenhuma chave nova fora do prefixo',(changed.length===0&&Object.keys(real1).length===Object.keys(real0).length)?'APROVADO':'REPROVADO',`chaves reais antes=${Object.keys(real0).length}, depois=${Object.keys(real1).length}; alteradas=${changed.length}; o app leu o prev sentinela real? ${k3['ma-ledger-v1-prev']==='SENTINELA-PREV'}`);
 L.record('A1-12','Erros de console no cenário',r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length} ${r.errors.slice(0,2).join('|')}; carga=${r.loadMs} ms`);
 require('fs').writeFileSync('r_s1.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s1.json',JSON.stringify(L.results,null,1));process.exit(1)});
