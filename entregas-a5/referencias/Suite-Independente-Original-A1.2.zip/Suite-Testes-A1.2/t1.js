// T1: isolamento + smoke de módulos + sanidade. Somente dados fictícios.
const L=require('./lib');const fs=require('fs');
(async()=>{const b=await L.browser();
 const SENT={'ma-care-v2':JSON.stringify({version:2,patients:[{id:'SENT1',name:'SENTINELA-REAL-PACIENTE',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]}),
  'ma-ledger-v1':JSON.stringify([{id:'SENT-L1',date:'2026-01-01',bank:'Cora',description:'SENTINELA-REAL-LANC',amount:999,kind:'Receita'}]),
  'ma-academy-v55':'{"version":55,"sentinela":"REAL-ACAD"}','ma56-project-checklist-v1':'{"version":1,"sentinela":"REAL-CK"}',
  'ma-installment-rates-v1':'{"sentinela":"REAL-RATES"}','ma-account-month-last-v1':'"2026-01"','ma61-sanitary-checklist-v1':'{"version":1,"sentinela":"REAL-SAN"}'};
 const r=await L.openDev(b,{realSeed:SENT});const p=r.page;
 const before=await L.rawStore(p);
 const realKeys=Object.keys(SENT);
 // --- smoke: todas as páginas existem e abrem
 const pages=await p.evaluate(()=>[...document.querySelectorAll('main .page')].map(x=>x.id));
 const shown={};
 for(const id of pages){shown[id]=await p.evaluate(id=>{go(id);const el=document.getElementById(id);return !el.hidden&&el.textContent.trim().length>20},id)}
 L.record('SMK-01','Todas as páginas abrem e têm conteúdo',Object.values(shown).every(Boolean)?'APROVADO':'REPROVADO',`${pages.length} páginas: `+Object.entries(shown).map(([k,v])=>k+(v?'':'(FALHOU)')).join(', '));
 L.record('SMK-02','Sem erros de console/pageerror na carga',r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length} ${r.errors.slice(0,3).join(' | ')}`);
 L.record('PERF-01','Tempo de carga DEV (4,6k+4,9k fictícios) no Chromium headless',r.loadMs>5000?'REPROVADO':'APROVADO',`carga=${r.loadMs} ms (limite de aceitação 5000 ms)`);
 // --- navegação por módulo (botões do menu)
 const navs=await p.evaluate(()=>[...document.querySelectorAll('aside nav button[data-page]')].map(b=>[b.dataset.page,b.textContent.trim().slice(0,40)]));
 console.log('NAV',JSON.stringify(navs));
 fs.writeFileSync('nav.json',JSON.stringify({pages,navs}));
 // --- fluxo de trabalho: lançamento, paciente, sanitário, academia
 await p.evaluate(()=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value='Lanc DEV T1';f.elements.amount.value='123,45';f.requestSubmit()});
 await p.waitForTimeout(500);
 await p.evaluate(()=>{go('ma61-sanitary')});
 const san1=await p.evaluate(()=>({fr:document.getElementById('ma61-front-total').textContent,cap:document.getElementById('ma61-front-caption').textContent,ok:+document.getElementById('ma61-ok').textContent,warn:+document.getElementById('ma61-warn').textContent,bad:+document.getElementById('ma61-bad').textContent}));
 console.log('SAN1',JSON.stringify(san1));
 await p.selectOption('#ma61-group','all');
 // altera um item para amarelo -> vermelho
 await p.evaluate(()=>{const s=document.querySelector('#ma61-groups select');s.value='warn';s.dispatchEvent(new Event('change',{bubbles:true}))});
 await p.waitForTimeout(300);
 const after=await L.rawStore(p,true);
 let changed=[];for(const k of realKeys){const a=before[k],c=after[k];if(!c||a.hash!==c.hash)changed.push(k)}
 const prefKeys=Object.keys(after).filter(k=>k.startsWith(L.PREFIX)).map(k=>k.slice(L.PREFIX.length));
 L.record('ISO-01','Chaves reais plantadas (7) permanecem byte a byte iguais após fluxo completo no DEV',changed.length===0?'APROVADO':'REPROVADO',`alteradas=${changed.length} ${changed.join(',')}; chaves gravadas pelo app (prefixadas)=${prefKeys.join(',')}`);
 const leakKeys=Object.keys(after).filter(k=>!k.startsWith(L.PREFIX)&&!realKeys.includes(k));
 L.record('ISO-02','App não cria chaves novas fora do prefixo',leakKeys.length===0?'APROVADO':'REPROVADO',`chaves fora do prefixo e fora das sentinelas=${leakKeys.length}`);
 // o app NÃO lê as chaves reais: lançamento sentinela não aparece, paciente sentinela não aparece
 const sees=await p.evaluate(()=>({led:document.body.innerText.includes('SENTINELA-REAL-LANC'),pac:JSON.stringify(localStorage.getItem('ma-care-v2')||'').includes('SENTINELA-REAL'),lsLen:localStorage.length,keys:Array.from({length:localStorage.length},(_,i)=>localStorage.key(i))}));
 L.record('ISO-03','App não lê as chaves reais (sentinelas não aparecem na interface/estado)',(!sees.led&&!sees.pac)?'APROVADO':'REPROVADO',`sentinela visível=${sees.led}; care sentinela lida=${sees.pac}; localStorage.length (visão do app)=${sees.lsLen}`);
 // clear() / removeItem() / API
 const clr=await p.evaluate(()=>{localStorage.clear();return localStorage.length});
 const after2=await L.rawStore(p);
 let lost=realKeys.filter(k=>!after2[k]||after2[k].hash!==before[k].hash);
 L.record('ISO-04','localStorage.clear() / removeItem() dentro do DEV não apaga chaves reais',(lost.length===0&&clr===0)?'APROVADO':'REPROVADO',`chaves reais perdidas/alteradas=${lost.length}; visão do app após clear length=${clr}`);
 // limites conhecidos
 const gap=await p.evaluate(()=>{const f=document.createElement('iframe');document.body.append(f);const real=f.contentWindow.localStorage;const seen=real.length;f.remove();return {seen,sess:typeof sessionStorage,idb:typeof indexedDB}});
 L.record('ISO-05','Limite: isolamento é por prefixo na MESMA origem file:// (cota e acesso por iframe/console não isolados)','AMARELO',`um iframe about:blank enxerga ${gap.seen} chaves reais+prefixadas; sessionStorage/indexedDB não isolados (mas o código não os usa: 0 ocorrências)`);
 fs.writeFileSync('t1.json',JSON.stringify(L.results,null,1));
 await b.close();})().catch(e=>{console.log('ERR',e.stack);process.exit(1)});
