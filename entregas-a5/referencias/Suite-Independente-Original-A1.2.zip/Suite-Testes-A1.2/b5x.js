// B5: AJ-6 (livro grande / cópia manual) e AJ-7 (mensagem obsoleta) + desempenho
const B=require('./b_lib');const {L,R,fs}=B;
function mkRaw(target){const n=Math.ceil(target/125);let rows=B.mkRows(n);let s=JSON.stringify(rows);
  const extra=target-s.length; rows[n-1].description='d'.repeat(Math.max(0,'Lanc ficticio X'.length+extra));s=JSON.stringify(rows);
  // ajuste fino
  let guard=0;while(s.length!==target&&guard++<50){const d=target-s.length;rows[n-1].description=rows[n-1].description+(d>0?'d'.repeat(d):'');if(d<0)rows[n-1].description=rows[n-1].description.slice(0,d);s=JSON.stringify(rows);}
  return s}
const submitMs=(p,d,v)=>p.evaluate(([d,v])=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value=d;f.elements.amount.value=v;const t=performance.now();f.requestSubmit();return Math.round(performance.now()-t)},[d,v]);
const nScreen=p=>p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}));return document.querySelectorAll('#transactions select[data-row]').length});

(async()=>{const b=await L.browser();let r,p,k,m;
 // desempenho
 const R65=B.mkRows(6500);const rawP=JSON.stringify(R65);console.log('perf raw len',rawP.length);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':rawP}});p=r.page;
 const t1=await submitMs(p,'perf','1');const t2=await submitMs(p,'perf2','1');
 const bannerMs=await p.evaluate(()=>{const t=performance.now();for(let i=0;i<5;i++)ma62LedgerBanner();return Math.round((performance.now()-t)/5)});
 R('B-75','Desempenho: gravar 1 lançamento com ~6.500 linhas (abaixo do limite) e custo da faixa por chamada',t2<500&&bannerMs<300,`gravação ${t1}/${t2} ms; faixa ${bannerMs} ms/chamada; load ${r.loadMs} ms`,'AMARELO');
 await r.ctx.close();
 // tudo legado (validRow lança exceção por linha)
 const leg=B.mkRows(6500,{bank:'Itau'});
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(leg)}});p=r.page;
 const bm2=await p.evaluate(()=>{const t=performance.now();for(let i=0;i<3;i++)ma62LedgerBanner();return Math.round((performance.now()-t)/3)});
 const tg=await submitMs(p,'perf3','1');
 R('B-76','Desempenho: 6.500 registros todos "antigos" (validação lança exceção por linha) — faixa e gravação continuam fluidas',bm2<500&&tg<1000,`faixa ${bm2} ms/chamada; gravação ${tg} ms; load ${r.loadMs} ms`,'AMARELO');
 await r.ctx.close();
 fs.writeFileSync('r_b5x.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b5x.json',JSON.stringify(L.results,null,1));process.exit(1)});
