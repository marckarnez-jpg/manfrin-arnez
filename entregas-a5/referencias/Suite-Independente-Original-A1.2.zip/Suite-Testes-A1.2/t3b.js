const L=require('./lib');const fs=require('fs');
const row=(i,x={})=>({id:'Cora:T'+i,date:'2026-09-0'+i,bank:'Cora',description:'Lanc ficticio '+i,amount:1000*i,kind:'Receita',...x});
const read=(p,k)=>p.evaluate(k=>localStorage.getItem(k),k);
async function addRow(p,desc,val='50'){await p.evaluate(([d,v])=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value=d;f.elements.amount.value=v;f.requestSubmit()},[desc,val]);await p.waitForTimeout(600)}
(async()=>{const b=await L.browser();
 // ---- P1-0 (refeito: confirma que o salvamento realmente ocorreu)
 {const orig=JSON.stringify({version:2,settings:{monthly:777},materials:[{id:'m1',name:'Material ficticio'}],marker:'ACAD-FUTURA'});
  const r=await L.openDev(b,{seed:{'ma-academy-v55':orig}});const p=r.page;
  await p.evaluate(()=>{go('ma55-cost');const set=(i,v)=>{const e=document.getElementById(i);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))};set('m55-monthly','1000');set('m55-hours','100');set('m55-target','25');set('m55-minimum','10');set('m55-tax','0');document.getElementById('m55-config-save').click()});
  await p.waitForTimeout(700);
  const st=await read(p,'ma-academy-v55');const saved=st!==orig;const lost=saved&&!st.includes('ACAD-FUTURA');
  L.record('P1-0','Academia 5.5: dado de versão desconhecida preservado ao primeiro salvamento?',!saved?'NÃO TESTADO':lost?'REPROVADO':'APROVADO',`salvamento ocorreu=${saved}; marcador original ${lost?'SOBRESCRITO sem aviso nem cópia (VERMELHO)':'mantido'}; msg=${await p.evaluate(()=>document.getElementById('m55-status')?.textContent?.slice(0,60)||'')}`,{vermelho:lost});
  await r.ctx.close();}
 // ---- P0-2: backup em estado de erro de leitura
 {const r=await L.openDev(b,{seed:{'ma-care-v2':JSON.stringify({version:3,patients:[{id:'MARC',name:'PACIENTE-MARCADOR-FICTICIO'}],records:[],notes:[]})}});const p=r.page;
  const st0=await read(p,'ma-care-v2');
  const [dl]=await Promise.all([p.waitForEvent('download',{timeout:5000}).catch(()=>null),p.evaluate(()=>{go('backup');document.getElementById('backup-save').click()})]);
  const f='bk_p02.json';let j={};if(dl){await dl.saveAs(f);j=JSON.parse(fs.readFileSync(f,'utf8'));}
  const n=j.care?.patients?.length;const hasMarker=JSON.stringify(j).includes('PACIENTE-MARCADOR');
  const stAfter=await read(p,'ma-care-v2');
  L.record('P0-2','Backup com leitura do cadastro em erro: exporta os dados armazenados (e não o seed embutido)?',(hasMarker||!dl)?'APROVADO':'REPROVADO',`arquivo gerado=${!!dl}; `+`care armazenado tinha 1 paciente (versão desconhecida); backup baixado contém ${n} pacientes e marcador armazenado ${hasMarker?'presente':'AUSENTE'}; aviso na tela="${await p.evaluate(()=>document.getElementById('backup-message')?.textContent?.slice(0,80))}"; chave original intacta após exportar=${st0===stAfter} → ${hasMarker?'ok':'backup traz o seed embutido e dá falsa sensação de segurança (VERMELHO)'}`,{vermelho:!hasMarker});
  await r.ctx.close();}
 // ---- P1-7: restauração sem snapshot automático
 {const own=[row(1),row(2)];
  const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(own)}});const p=r.page;
  const keys0=await p.evaluate(()=>Object.keys(localStorage).sort().join(','));
  const bk={format:'manfrin-arnez-backup',version:2,care:{version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]},ledger:[row(5,{id:'Cora:R5',description:'Restaurado ficticio'})],rateSettings:{}};
  fs.writeFileSync('bk_t3_restore.json',JSON.stringify(bk));
  await p.evaluate(()=>go('backup'));
  const nav=p.waitForNavigation({timeout:20000}).catch(()=>null);
  await p.setInputFiles('#backup-load','bk_t3_restore.json');await nav;await p.waitForTimeout(1500);
  await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true,null,{timeout:120000}).catch(()=>{});
  const keys1=await p.evaluate(()=>Object.keys(localStorage).sort());
  const led=JSON.parse(await p.evaluate(()=>localStorage.getItem('ma-ledger-v1')||'[]')).map(x=>x.description);
  const snap=keys1.filter(k=>/snap|bak|backup|prev|undo/i.test(k));
  L.record('P1-7a','Restauração substitui os dados (comportamento funcional)',led.length===1&&led[0]==='Restaurado ficticio'?'APROVADO':'REPROVADO',`ledger após restaurar=[${led.join('; ')}]; chaves=${keys1.join(',')}`);
  L.record('P1-7b','Restauração cria cópia automática dos dados anteriores antes de substituir?',snap.length?'APROVADO':'REPROVADO',`chaves antes=${keys0}; depois=${keys1.join(',')}; chaves de cópia=${snap.length} → ${snap.length?'ok':'2 lançamentos anteriores sem possibilidade de desfazer (VERMELHO)'}`,{vermelho:!snap.length});
  await r.ctx.close();}
 fs.writeFileSync('t3.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('t3.json',JSON.stringify(L.results,null,1));process.exit(1)});
