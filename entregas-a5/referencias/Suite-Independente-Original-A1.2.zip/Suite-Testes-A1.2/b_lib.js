// Biblioteca A1.1 (reaproveita a1lib)
const H=require('./a1lib');const {L,fs}=H;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
// R: registra com severidade se reprovar. ok=true -> VERDE ; ok=false -> sev (AMARELO|VERMELHO) ; ok='NT' -> NÃO TESTADO
function R(id,titulo,ok,evid,failSev='AMARELO',extra={}){
  const resultado=ok==='NT'?'NÃO TESTADO':(ok?'APROVADO':'REPROVADO');
  const sev=ok==='NT'?'AMARELO':(ok?'VERDE':failSev);
  L.record(id,titulo,resultado,evid,{sev,...extra});}
async function tryDownload(p,fn,timeout=4000){let dl=null;try{[dl]=await Promise.all([p.waitForEvent('download',{timeout}),p.evaluate(fn)]);}catch(e){await p.evaluate(()=>0).catch(()=>0);}return dl}
async function saveDl(dl,file){if(!dl)return null;await dl.saveAs(file);return fs.readFileSync(file,'utf8')}
const bmsg=p=>p.evaluate(()=>document.getElementById('backup-message')?.textContent||'');
const alertInfo=p=>p.evaluate(()=>{const e=document.getElementById('ma62-ledger-alert');if(!e)return null;const r=e.getBoundingClientRect();const cs=getComputedStyle(e);
  const cx=Math.min(innerWidth-2,Math.max(2,r.left+r.width/2)),cy=Math.min(innerHeight-2,Math.max(2,r.top+Math.min(r.height/2,20)));const top=document.elementFromPoint(cx,cy);
  return {text:e.textContent.replace(/\s+/g,' ').slice(0,400),h:Math.round(r.height),top:Math.round(r.top),w:Math.round(r.width),shown:cs.display!=='none'&&cs.visibility!=='hidden'&&r.height>0,onTop:!!top&&(e===top||e.contains(top)),btns:[...e.querySelectorAll('button')].map(b=>b.textContent.trim())}});
const mkRows=(n,x={})=>Array.from({length:n},(_,i)=>({id:'Cora:B'+i,date:'2026-09-'+String(1+i%28).padStart(2,'0'),bank:'Cora',description:'Lanc ficticio '+i,amount:1000+i,kind:'Receita',...x}));
module.exports={...H,R,tryDownload,saveDl,bmsg,alertInfo,mkRows,wait};
