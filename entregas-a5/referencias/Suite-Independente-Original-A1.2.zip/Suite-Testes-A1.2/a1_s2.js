// S2: JSON truncado + objeto não-lista
const H=require('./a1lib');const {L,row,fs}=H;
(async()=>{const b=await L.browser();
 const RAW='[{"id":"Cora:X1","date":"2026-09-01","bank":"Cora","description":"Lanc ficticio X","amount":1000,"kind":"Receita"},{"id":"Cora:X2","date":';
 let r=await L.openDev(b,{seed:{'ma-ledger-v1':RAW}});let p=r.page;
 const k0=await H.appKeys(p);const bn=await H.banner(p);const n0=await H.shown(p);
 L.record('A1-20','JSON truncado: bloqueio, aviso e texto original preservado ao abrir',(k0['ma-ledger-v1']===RAW&&bn&&/BLOQUEADO|ilegível/i.test(bn.text+'')&&n0===0&&!('ma-ledger-v1-prev' in k0)&&H.qKeys(k0).length===0)?'APROVADO':'REPROVADO',`texto idêntico=${k0['ma-ledger-v1']===RAW}; aviso="${bn?.text?.slice(0,110)}"; prev/quarentena criados=${'ma-ledger-v1-prev' in k0}/${H.qKeys(k0).length}`);
 const m=await H.addRow(p,'tentativa sobre json quebrado');
 const k1=await H.appKeys(p);
 L.record('A1-21','JSON truncado: tentativa de novo lançamento é recusada, com mensagem, sem tocar no armazenamento',(k1['ma-ledger-v1']===RAW&&/BLOQUEAD/i.test(m)&&!('ma-ledger-v1-prev' in k1))?'APROVADO':'REPROVADO',`texto idêntico=${k1['ma-ledger-v1']===RAW}; mensagem="${m.slice(0,100)}"; linhas exibidas=${await H.shown(p)}`);
 // CSV import bloqueado
 fs.writeFileSync('csv_ok.csv','﻿id;data;banco;descricao;valor;categoria\ncsv1;2026-10-01;Cora;Importado ficticio;100,00;Receita\n');
 await p.evaluate(()=>go('ledger'));await p.setInputFiles('#csv','csv_ok.csv');await p.waitForTimeout(600);
 const k2=await H.appKeys(p);const m2=await H.msg(p);
 L.record('A1-22','JSON truncado: importação de CSV é bloqueada',(k2['ma-ledger-v1']===RAW&&await H.shown(p)===0)?'APROVADO':'REPROVADO',`texto idêntico=${k2['ma-ledger-v1']===RAW}; linhas exibidas=${await H.shown(p)}; mensagem="${m2.slice(0,100)}"`);
 // download bruto
 let dl=null;try{[dl]=await Promise.all([p.waitForEvent('download',{timeout:8000}),p.evaluate(()=>{go('ledger');[...document.querySelectorAll('#ma62-ledger-alert button')].find(b=>/bruta/i.test(b.textContent)).click()})])}catch(e){}
 let dtxt=null;if(dl){await dl.saveAs('raw_dl.json');dtxt=fs.readFileSync('raw_dl.json','utf8')}
 L.record('A1-23','JSON truncado: botão "Baixar cópia bruta" entrega o texto exato',dtxt===RAW?'APROVADO':'REPROVADO',`download ocorreu=${!!dl}; conteúdo idêntico byte a byte=${dtxt===RAW}; arquivo=${dl?.suggestedFilename()}`);
 // backup geral enquanto bloqueado
 let bdl=null;try{[bdl]=await Promise.all([p.waitForEvent('download',{timeout:8000}),p.evaluate(()=>{go('backup');document.getElementById('backup-save').click()})])}catch(e){}
 let bj=null;if(bdl){await bdl.saveAs('bk_blocked.json');bj=JSON.parse(fs.readFileSync('bk_blocked.json','utf8'))}
 const bmsg=await p.evaluate(()=>document.getElementById('backup-message')?.textContent?.slice(0,100));
 L.record('A1-24','Backup geral com o livro-caixa bloqueado/ilegível não pode parecer completo',(bj&&bj.ledger&&bj.ledger.length>0)?'APROVADO':'REPROVADO',`backup gerado=${!!bdl}; lançamentos no backup=${bj?.ledger?.length}; mensagem na tela="${bmsg}" → o backup sai com livro-caixa VAZIO e diz "Backup gerado" (o texto ilegível não vai junto)`,{vermelho:true});
 // outras telas
 const oth=await p.evaluate(()=>{const o={};for(const pg of ['dash','accounting','ma55-contador','ledger']){go(pg);const t=document.getElementById(pg)?.innerText||'';o[pg]=/bloquead|quarentena|ilegível|ATENÇÃO/i.test(t)}return o});
 L.record('A1-25','Telas que consomem o livro-caixa avisam que ele está bloqueado',Object.entries(oth).filter(([k])=>k!=='ledger').every(([,v])=>v)?'APROVADO':'REPROVADO',`menção a bloqueio por tela: ${JSON.stringify(oth)}; as demais telas mostram "Sem dados"/zeros sem alerta`,{amarelo:true});
 // recarga mantém bloqueio
 await p.reload();await H.reloadWait(p);const k3=await H.appKeys(p);const bn3=await H.banner(p);
 L.record('A1-26','Recarga: continua bloqueado, texto intacto, sem criar prev nem quarentena',(k3['ma-ledger-v1']===RAW&&bn3&&!('ma-ledger-v1-prev' in k3)&&H.qKeys(k3).length===0)?'APROVADO':'REPROVADO',`texto idêntico=${k3['ma-ledger-v1']===RAW}; aviso presente=${!!bn3}`);
 L.record('A1-27','Erros de console (JSON truncado)',r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length} ${r.errors.slice(0,2).join('|')}`);
 await r.ctx.close();
 // objeto no lugar de lista
 const OBJ='{"id":"Cora:O1","date":"2026-09-01","amount":5}';
 r=await H.L.openDev(b,{seed:{'ma-ledger-v1':OBJ}});p=r.page;
 const mm=await H.addRow(p,'tentativa sobre objeto');const ko=await H.appKeys(p);const bo=await H.banner(p);
 L.record('A1-28','Objeto no lugar de lista: bloqueado, texto preservado',(ko['ma-ledger-v1']===OBJ&&bo&&/BLOQUEAD/i.test(mm))?'APROVADO':'REPROVADO',`texto idêntico=${ko['ma-ledger-v1']===OBJ}; mensagem="${mm.slice(0,80)}"`);
 await r.ctx.close();
 // valor 'null' e texto vazio
 for(const [name,val] of [['JSON null','null'],['texto vazio','']]){
  r=await H.L.openDev(b,{seed:{'ma-ledger-v1':val}});p=r.page;const mm2=await H.addRow(p,'tentativa '+name);const kk=await H.appKeys(p);
  L.record('A1-29'+(name==='JSON null'?'a':'b'),`Armazenamento contendo ${name}: não é sobrescrito sem aviso`,kk['ma-ledger-v1']===val?'APROVADO':'REPROVADO',`texto idêntico=${kk['ma-ledger-v1']===val}; mensagem="${mm2.slice(0,80)}"`);
  await r.ctx.close();}
 fs.writeFileSync('r_s2.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s2.json',JSON.stringify(L.results,null,1));process.exit(1)});
