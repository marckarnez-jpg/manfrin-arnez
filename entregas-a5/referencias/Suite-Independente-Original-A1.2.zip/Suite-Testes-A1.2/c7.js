// C7: A1.2 — depois que as cópias por operação esgotam a cota, o cadastro/pagamentos continuam gravando?
const B=require('./b_lib');const {L,R,fs}=B;
async function chosePatient(p,name){
  await p.evaluate(()=>go('quick'));await p.fill('#quick-search',name);await p.waitForTimeout(600);
  const ok=await p.evaluate(()=>{const b=document.querySelector('#quick-results button, #quick-results [data-id], #quick-results li, #quick-results div');if(!b)return false;b.click();return true});
  await p.waitForTimeout(400);return ok}
const getCare=async p=>JSON.parse((await B.appKeys(p))['ma-care-v2']||'null');
const pay=async(p,svc)=>{await p.evaluate(s=>{const f=document.getElementById('payment-form');f.elements.date.value='2026-10-05';f.elements.amount.value='123.45';f.elements.service.value=s;f.elements.payment.value='Pix';f.requestSubmit()},svc);await p.waitForTimeout(800);return p.evaluate(()=>document.getElementById('payment-message').textContent)};
(async()=>{const b=await L.browser();
 const seed=JSON.stringify(B.mkRows(500));
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':seed}});const p=r.page;
 let ops=0,m='';
 for(;ops<150;ops++){m=await B.addRow(p,'op '+ops,'1');if(/bloqueada|Não foi possível/i.test(m))break}
 // espaço restante estimado: quantos caracteres ainda cabem
 const rest=await p.evaluate(()=>{let n=0;for(const size of [100000,10000,1000,100,10,1]){for(;;){try{localStorage.setItem('__probe'+n,'x'.repeat(size))}catch(e){break}n++}}let t=0;for(let i=0;i<n;i++){t+=localStorage.getItem('__probe'+i).length}for(let i=0;i<n;i++)localStorage.removeItem('__probe'+i);return t});
 // consumir o restante para simular a situação em que a cota acaba exatamente
 const c0=await getCare(p);const n0=c0.records.length;
 await chosePatient(p,'Paciente');
 let okPay=0,lastMsg='';
 for(let i=0;i<120;i++){const pm=await pay(p,'Servico ficticio C7-'+i);const c1=await getCare(p);if(c1&&c1.records.some(x=>x.service==='Servico ficticio C7-'+i)){okPay++;lastMsg=pm}else{lastMsg=pm;break}}
 const k=await B.appKeys(p);const snaps=Object.keys(k).filter(x=>x.includes('session-prev-')).length;
 R('C-82','AJ-14/15: ao esgotar a cota com cópias por operação ('+ops+' operações de livro), quantos pagamentos ainda cabem e o que acontece depois (efeito colateral da retenção sem limpeza)',false,`operações do livro até a recusa=${ops}; cópias acumuladas=${snaps}; caracteres livres após a recusa≈${rest}; pagamentos que ainda couberam=${okPay}; mensagem do primeiro pagamento recusado="${lastMsg.slice(0,170)}"`,'AMARELO',{info:true});
 const ai=await B.alertInfo(p);
 R('C-83','AJ-14: existe, dentro do app, forma de APAGAR cópias por operação antigas para liberar cota?',!!(ai&&ai.btns.some(x=>/apagar|excluir|limpar|remover|descartar/i.test(x))),`botões de cópia=${ai&&ai.btns.filter(x=>/cópia/i.test(x)).length}; botões distintos=${ai&&[...new Set(ai.btns)].join(' | ')}`,'AMARELO');
 await b.close();
})().catch(e=>{console.log('ERR',e.stack)}).then(()=>fs.writeFileSync('r_c7.json',JSON.stringify(L.results,null,1)));
