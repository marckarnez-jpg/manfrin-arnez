// C2: A1.2 — AJ-13 (aprovação externa), AJ-14 (-prev e cópias por operação), AJ-15 (sem limite 900k, cota real, falhas)
const B=require('./b_lib');const {L,R,fs}=B;
const SNAP='ma-ledger-v1-session-prev-';
const snapKeys=k=>Object.keys(k).filter(x=>x.startsWith(SNAP)).sort();
async function ctxWith(b,seed,hook){const ctx=await b.newContext({acceptDownloads:true,viewport:{width:1280,height:900}});const page=await ctx.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message.slice(0,150)));
 page.on('dialog',d=>d.accept());
 await page.addInitScript(({seed,PREFIX})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(seed))localStorage.setItem(PREFIX+k,v);}}catch(e){}
  if(window===window.top){
   const so=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){const s=String(k);
     if(window.__failLedger&&s.endsWith('ma-ledger-v1'))throw new DOMException('QuotaExceededError','QuotaExceededError');
     return so.call(this,k,v)};
   const go_=Storage.prototype.getItem;Storage.prototype.getItem=function(k){const v=go_.call(this,k);if(window.__corruptSnap&&String(k).includes('session-prev-')&&v!==null)return v+'X';return v};
  }
 },{seed,PREFIX:L.PREFIX});
 await page.goto(L.DEV,{timeout:240000});await page.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return {ctx,page,errors}}
const nScreen=p=>B.shown(p);
const bannerBtn=(p,re)=>p.evaluate(src=>{go('ledger');const b=[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>new RegExp(src,'i').test(x.textContent));if(!b)return false;b.click();return true},re.source);
(async()=>{const b=await L.browser();let r,p,k,m,ai,ks;
 const ok20=JSON.stringify(B.mkRows(20));
 // ---------- C-30 cópia por operação + -prev intacta (AJ-14, B-69) ----------
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok20,'ma-ledger-v1-prev':'PREV-ANTIGO-FICTICIO'}));
 await B.addRow(p,'op um','11');let k1=await B.appKeys(p);const after1=k1['ma-ledger-v1'];
 await B.addRow(p,'op dois','12');await B.addRow(p,'op tres','13');k=await B.appKeys(p);ks=snapKeys(k);
 const exactSeq=ks.length===3&&k[ks[0]]===ok20&&k[ks[1]]===after1&&JSON.parse(k[ks[2]]).length===22;
 R('C-30','AJ-14: cada operação cria uma cópia bruta nova com os bytes EXATOS do estado anterior (3 operações, 3 chaves)',exactSeq,`chaves=${ks.length}; 1ª==semente=${ks[0]&&k[ks[0]]===ok20}; 2ª==estado após op1=${ks[1]&&k[ks[1]]===after1}; 3ª tem 22 linhas=${ks[2]&&JSON.parse(k[ks[2]]).length===22}; exemplo de chave="${ks[0]}"`,'VERMELHO');
 R('B-69','AJ-14: -prev antiga permanece byte-idêntica após várias gravações e é rotulada como origem não comprovada',k['ma-ledger-v1-prev']==='PREV-ANTIGO-FICTICIO',`prev intacta=${k['ma-ledger-v1-prev']==='PREV-ANTIGO-FICTICIO'}`,'AMARELO');
 ai=await B.alertInfo(p);await p.evaluate(()=>go('ledger'));ai=await B.alertInfo(p);
 R('C-31','AJ-14: faixa informa -prev de sessão não comprovada e cópias locais por operação; permite baixar cada uma',!!ai&&/-prev.*não comprovad/i.test(ai.text)&&/cópia\(s\) local/i.test(ai.text)&&ai.btns.some(x=>/-prev/i.test(x)),`faixa="${ai&&ai.text.slice(0,300)}"; botões=${ai&&ai.btns.join(' | ')}`,'AMARELO');
 const sd=await B.tryDownload(p,()=>{go('ledger');const d=document.querySelector('#ma62-ledger-alert details');d.open=true;[...d.querySelectorAll('button')][0].click()},6000);const st=await B.saveDl(sd,'snap_c31.json');
 R('C-32','AJ-14: download de uma cópia por operação devolve exatamente o conteúdo guardado',st===k[ks[0]],`idêntico=${st===k[ks[0]]}; nome=${sd&&sd.suggestedFilename()}`,'AMARELO');
 const pd=await B.tryDownload(p,()=>{[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/-prev/i.test(x.textContent)).click()},6000);const pt=await B.saveDl(pd,'prev_c32.json');
 R('C-33','AJ-14: download da -prev devolve o conteúdo original byte-a-byte',pt==='PREV-ANTIGO-FICTICIO',`idêntico=${pt==='PREV-ANTIGO-FICTICIO'}`,'AMARELO');
 // nova sessão (reload): sessões antigas e atuais; -prev ainda intacta
 await p.reload();await B.reloadWait(p);await B.addRow(p,'nova sessao','14');k=await B.appKeys(p);ks=snapKeys(k);
 R('C-34','AJ-14: nova sessão não apaga cópias antigas (4 chaves) e a -prev continua intacta',ks.length===4&&k['ma-ledger-v1-prev']==='PREV-ANTIGO-FICTICIO',`chaves=${ks.length}; prev intacta=${k['ma-ledger-v1-prev']==='PREV-ANTIGO-FICTICIO'}`,'AMARELO');
 await r.close();

 // ---------- sem -prev: a chave não é criada ----------
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok20}));
 await B.addRow(p,'sem prev','11');k=await B.appKeys(p);
 R('C-35','AJ-14: sem -prev prévia, a chave -prev não é criada (nem recriada); proteção usa a chave por operação',!('ma-ledger-v1-prev' in k)&&snapKeys(k).length===1,`prev existe=${'ma-ledger-v1-prev' in k}; snapshots=${snapKeys(k).length}`,'AMARELO');
 await r.close();

 // ---------- AJ-15 / B-61 / A1-60: livro grande ----------
 const big=JSON.stringify(B.mkRows(9000));
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':big}));
 const bigLen=big.length;
 m=await B.addRow(p,'em livro grande','10');k=await B.appKeys(p);ks=snapKeys(k);
 const wrote=k['ma-ledger-v1']&&JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='em livro grande');
 R('B-61','AJ-15: livro com '+bigLen+' caracteres (>900.000) grava sem pedir cópia externa, com cópia local exata',!!wrote&&ks.length===1&&k[ks[0]]===big,`tamanho=${bigLen}; gravou=${!!wrote}; cópia local exata=${ks.length&&k[ks[0]]===big}; msg="${m.slice(0,100)}"`,'AMARELO');
 await r.close();

 // ---------- AJ-15: cota real, cópia local não cabe ----------
 const ok40=JSON.stringify(B.mkRows(40));
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok40}));
 await B.saturate(p);const n0=await nScreen(p);
 m=await B.addRow(p,'sem espaço','5');k=await B.appKeys(p);ai=await B.alertInfo(p);const n1=await nScreen(p);
 R('C-36','AJ-15: sem espaço para a cópia local — gravação recusada, livro byte-idêntico, tela coerente, botão de cópia externa',k['ma-ledger-v1']===ok40&&n0===n1&&/não foi possível|bloqueada/i.test(m)&&ai.btns.some(x=>/cópia externa/i.test(x)),`livro intacto=${k['ma-ledger-v1']===ok40}; linhas na tela ${n0}->${n1}; msg="${m.slice(0,150)}"; botões=${ai.btns.join(' | ')}`,'VERMELHO');
 // folga para o crescimento do livro, não para a cópia
 await B.freeSpace(p,500);
 m=await B.addRow(p,'ainda sem copia','5');k=await B.appKeys(p);
 R('C-37','AJ-15: com folga só para o crescimento (não para a cópia) a gravação continua recusada — não grava sem proteção',k['ma-ledger-v1']===ok40,`livro intacto=${k['ma-ledger-v1']===ok40}; msg="${m.slice(0,120)}"`,'VERMELHO');
 // cancelar confirmação externa
 r.removeAllListeners?.('dialog');p.removeAllListeners('dialog');p.on('dialog',d=>d.dismiss());
 let dl=await B.tryDownload(p,()=>{go('ledger');[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/confirmar/i.test(x.textContent)).click()});const ext=await B.saveDl(dl,'ext_c38.json');
 m=await B.addRow(p,'cancelado','5');k=await B.appKeys(p);
 R('C-38','AJ-13: a cópia externa baixada é exata; se o usuário cancela a confirmação, nada é liberado',ext===ok40&&k['ma-ledger-v1']===ok40,`cópia exata=${ext===ok40}; livro intacto=${k['ma-ledger-v1']===ok40}; msg="${m.slice(0,100)}"`,'VERMELHO');
 // aceitar
 p.removeAllListeners('dialog');p.on('dialog',d=>d.accept());
 await B.tryDownload(p,()=>{go('ledger');[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/confirmar/i.test(x.textContent)).click()});
 ai=await B.alertInfo(p);const apprText=ai.text;
 m=await B.addRow(p,'liberado','5');k=await B.appKeys(p);ai=await B.alertInfo(p);
 const wroteA=JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='liberado');
 R('C-39','AJ-13: após confirmação externa manual a gravação ocorre e o estado é rotulado "confirmada manualmente / não verificada pelo app"',wroteA&&/confirmada manualmente|externa/i.test(ai.text),`gravou=${wroteA}; faixa depois="${ai.text.slice(0,260)}"`,'AMARELO');
 R('B-67','AJ-13: após liberar e gravar, a faixa NÃO repete "Sem espaço para cópia local" nem o pedido já atendido',!/Sem espaço para cópia local|Não foi possível criar a cópia local/i.test(ai.text),`faixa="${ai.text.slice(0,260)}"`,'AMARELO');
 m=await B.addRow(p,'segunda sem copia','5');k=await B.appKeys(p);
 const wroteB=JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='segunda sem copia');
 R('C-40','AJ-13: a aprovação externa vale UMA operação; a segunda gravação sem espaço volta a ser recusada',!wroteB&&/não foi possível|bloqueada/i.test(m),`segunda gravou=${wroteB}; msg="${m.slice(0,140)}"`,'VERMELHO');
 await r.close();

 // ---------- AJ-13: verificação pelo conteúdo ----------
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok40}));
 await B.saturate(p);await B.freeSpace(p,500);await B.addRow(p,'tenta','5');
 await bannerBtn(p,/confirmar|cópia externa/);await p.waitForTimeout(300);
 fs.writeFileSync('ext_wrong.json',ok40.slice(0,-1)+' ]');
 await p.evaluate(()=>go('ledger'));
 await p.setInputFiles('#ma62-verify-ledger-file','ext_wrong.json').catch(e=>0);await p.waitForTimeout(500);m=await B.msg(p);
 k=await B.appKeys(p);
 R('C-41','AJ-13: arquivo externo errado é rejeitado na verificação (mensagem "NÃO verificada") e a gravação continua recusada',/NÃO verificada/i.test(m),`msg="${m.slice(0,140)}"`,'AMARELO');
 fs.writeFileSync('ext_ok.json',ok40);
 await p.setInputFiles('#ma62-verify-ledger-file','ext_ok.json').catch(e=>0);await p.waitForTimeout(500);
 m=await B.addRow(p,'verificado','5');k=await B.appKeys(p);ai=await B.alertInfo(p);
 const wroteV=JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='verificado');
 R('C-42','AJ-13: arquivo externo idêntico (verificado pelo conteúdo) libera uma operação e o estado é rotulado "verificada pelo conteúdo"',wroteV&&/verificad/i.test(ai.text),`gravou=${wroteV}; faixa="${ai.text.slice(0,240)}"`,'AMARELO');
 await r.close();

 // ---------- falha ao gravar o principal depois da cópia local ----------
 ({ctx:r,page:p}=await ctxWith(b,{'ma-ledger-v1':ok20}));
 await p.evaluate(()=>{window.__failLedger=true});const nA=await nScreen(p);
 m=await B.addRow(p,'falha principal','5');k=await B.appKeys(p);const nB=await nScreen(p);ai=await B.alertInfo(p);
 R('C-43','AJ-15: falha na gravação do livro principal — original intacto, tela restaurada, aviso e cópia de proteção guardada',k['ma-ledger-v1']===ok20&&nA===nB&&snapKeys(k).length===1&&/recusad|não foi possível/i.test(m+ai.text),`livro intacto=${k['ma-ledger-v1']===ok20}; tela ${nA}->${nB}; snapshots=${snapKeys(k).length}; msg="${m.slice(0,100)}"; faixa="${ai.text.slice(0,150)}"`,'VERMELHO');
 await p.evaluate(()=>{window.__failLedger=false});
 m=await B.addRow(p,'depois da falha','5');k=await B.appKeys(p);
 R('C-44','AJ-15: depois da falha, nova operação funciona normalmente',JSON.parse(k['ma-ledger-v1']).some(x=>x.description==='depois da falha'),`msg="${m.slice(0,80)}"; snapshots=${snapKeys(k).length}`,'AMARELO');
 // leitura de conferência da cópia diverge
 await p.evaluate(()=>{window.__corruptSnap=true});const before=(await B.appKeys(p))['ma-ledger-v1'];
 m=await B.addRow(p,'copia nao verifica','5');k=await B.appKeys(p);
 R('C-45','AJ-15: se a leitura de conferência da cópia local diverge, a gravação é recusada (livro intacto)',k['ma-ledger-v1']===before&&/não foi possível|bloqueada/i.test(m),`livro intacto=${k['ma-ledger-v1']===before}; msg="${m.slice(0,140)}"`,'VERMELHO');
 await r.close();

 // ---------- duas abas ----------
 {const ctx=await b.newContext({acceptDownloads:true});
  await ctx.addInitScript(({s,P})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(s))localStorage.setItem(P+k,v)}}catch(e){}},{s:{'ma-ledger-v1':ok20},P:L.PREFIX});
  const mk=async()=>{const pg=await ctx.newPage();pg.on('dialog',d=>d.accept());await pg.goto(L.DEV,{timeout:240000});await pg.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return pg};
  const A=await mk(),Bp=await mk();
  await B.addRow(Bp,'da aba B','77');const kb=(await B.appKeys(Bp))['ma-ledger-v1'];
  m=await B.addRow(A,'da aba A','88');k=await B.appKeys(A);
  R('C-46','AJ-15/concorrência: aba desatualizada não sobrescreve o livro gravado por outra aba',k['ma-ledger-v1']===kb&&!/da aba A/.test(k['ma-ledger-v1']),`livro = o da aba B=${k['ma-ledger-v1']===kb}; msg="${m.slice(0,160)}"`,'VERMELHO');
  await ctx.close();}
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c2.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c2.json',JSON.stringify(L.results,null,1)));
