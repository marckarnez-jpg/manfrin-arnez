// B7: reconferências pontuais (regex corrigido, faixa sticky, mensagem de sucesso)
const B=require('./b_lib');const {L,R,fs}=B;
(async()=>{const b=await L.browser();let r,p,k;
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(3)),'ma-ledger-v1-rejeitados-20260101000000':'qualquer'},realSeed:B.SENT()});p=r.page;
 const ai=await B.alertInfo(p);const raw=await L.rawStore(p,true);const SE=B.SENT();
 const sentOK=Object.keys(SE).every(kk=>raw[kk]&&raw[kk].text===SE[kk]);const nreal=Object.keys(raw).filter(kk=>!kk.startsWith(L.PREFIX)).length;
 const cnt=(ai.text.match(/(\d+) arquivo\(s\)/)||[])[1];
 R('B-58r','Isolamento (reconferência): varredura de quarentenas conta só a chave do sandbox; 6 sentinelas reais (inclusive quarentena real) intactas',sentOK&&cnt==='1'&&nreal===6,`arquivos contados=${cnt} (esperado 1); sentinelas intactas=${sentOK}; chaves reais=${nreal}`,'VERMELHO');
 await r.ctx.close();
 // sticky: o que cobre o topo da faixa?
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...B.mkRows(3),{foo:1}])}});p=r.page;
 await p.evaluate(()=>go('sim'));await p.evaluate(()=>window.scrollTo(0,700));await p.waitForTimeout(200);
 const st=await p.evaluate(()=>{const e=document.getElementById('ma62-ledger-alert');const rc=e.getBoundingClientRect();const cs=getComputedStyle(e);const ban=document.getElementById('ma-dev-banner')||[...document.querySelectorAll('body > *')].find(x=>/AMBIENTE DEV/.test(x.textContent)&&getComputedStyle(x).position==='fixed');
  const below=document.elementFromPoint(rc.left+rc.width/2,rc.top+rc.height-12);const topEl=document.elementFromPoint(rc.left+rc.width/2,rc.top+6);
  return {pos:cs.position,top:Math.round(rc.top),h:Math.round(rc.height),belowIsAlert:e.contains(below),topCoveredBy:topEl&&!e.contains(topEl)?(topEl.textContent||'').slice(0,40):null,devBarH:ban?Math.round(ban.getBoundingClientRect().height):null}});
 R('B-22r','AJ-2 (reconferência): faixa é sticky e permanece visível ao rolar; no DEV a barra vermelha de ambiente cobre as primeiras linhas',st.pos==='sticky'&&st.belowIsAlert,`position=${st.pos}; top=${st.top}px; altura=${st.h}px; parte inferior da faixa visível=${st.belowIsAlert}; topo coberto por="${st.topCoveredBy}"; barra DEV=${st.devBarH}px (existe só na cópia DEV)`,'AMARELO');
 await r.ctx.close();
 fs.writeFileSync('r_b7.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);process.exit(1)});
