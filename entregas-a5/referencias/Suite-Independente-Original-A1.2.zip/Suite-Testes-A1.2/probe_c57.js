const B=require('./b_lib');const {L,fs}=B;
(async()=>{const b=await L.browser();
 const S=JSON.stringify([...B.mkRows(3),{id:123,date:'2026-09-10',bank:'Cora',description:'id numerico',amount:5000,kind:'Receita'}]);
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':S}});const p=r.page;
 await p.evaluate(()=>go('backup'));await p.evaluate(()=>document.getElementById('backup-save').click());await p.waitForTimeout(500);
 const m=await B.bmsg(p);
 for(const pg of ['backup','ledger','accounting','dash']){await p.evaluate(x=>go(x),pg);const ai=await B.alertInfo(p);console.log(pg,'faixa=',ai?JSON.stringify({shown:ai.shown,btns:ai.btns,t:ai.text.slice(0,100)}):'AUSENTE');}
 console.log('msg',m.slice(0,200));
 const csv=await B.tryDownload(p,()=>{go('ledger');document.getElementById('export').click()},5000);console.log('csv export available',!!csv);
 await b.close();})();
