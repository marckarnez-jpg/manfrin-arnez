// B2: AJ-2 — faixa global em todas as telas
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
async function pages(p){return p.evaluate(()=>[...document.querySelectorAll('nav button')].map(x=>x.dataset.page))}
async function sweep(p,pgs,vw){const out={};for(const pg of pgs){await p.evaluate(x=>go(x),pg);await p.waitForTimeout(150);out[pg]=await B.alertInfo(p);}return out}
(async()=>{const b=await L.browser();let r,p,k;
 const states=[
  ['ilegível (JSON truncado)',{'ma-ledger-v1':'[{"id":"a","date":'},'bloq'],
  ['quarentena (linha ilegível) + válidas',{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}])},'quar'],
  ['registro legado (banco fora do padrão)',{'ma-ledger-v1':JSON.stringify([...ok3,{id:'Itau:1',date:'2026-09-09',bank:'Itau',description:'legado',amount:500,kind:'Receita'}])},'leg'],
  ['quarentena antiga (chave de outra sessão) e livro íntegro',{'ma-ledger-v1':JSON.stringify(ok3),'ma-ledger-v1-rejeitados-20260101000000':JSON.stringify({format:'ma62-dev-ledger-quarantine',version:1,originalKey:'ma-ledger-v1',rows:[{index:1,reason:'x',row:{foo:1}}]})},'qold'],
 ];
 let allPages=null;
 for(const [nome,seed,tag] of states){
  r=await L.openDev(b,{seed});p=r.page;const pgs=await pages(p);allPages=pgs;
  const sw=await sweep(p,pgs);
  // Início = página inicial do módulo ma56 (carregada ao abrir)
  const home=await p.evaluate(()=>{const h=document.getElementById('ma56-home');return h?{vis:!!h.offsetParent}:null});
  const miss=pgs.filter(x=>!(sw[x]&&sw[x].shown&&sw[x].onTop));
  R('B-20-'+tag,`AJ-2: faixa de aviso visível em TODAS as telas do menu — estado: ${nome}`,miss.length===0,`telas do menu (${pgs.length}): ${pgs.join(',')}; sem faixa visível em: [${miss.join(',')||'nenhuma'}]; altura=${sw[pgs[0]]&&sw[pgs[0]].h}px; texto="${(sw[pgs[0]]&&sw[pgs[0]].text||'').slice(0,200)}"`,'VERMELHO');
  if(tag==='bloq'){
   // telas que consomem o livro (dash, accounting) : zeros sem confusão?
   const consumers=await p.evaluate(()=>{const o={};for(const pg of ['dash','accounting','ledger']){go(pg);o[pg]=(document.getElementById(pg)?.innerText||'').replace(/\s+/g,' ').slice(0,160)}return o});
   console.log('consumidores',JSON.stringify(consumers));
   // mobile
   await p.setViewportSize({width:390,height:760});await p.evaluate(()=>go('dash'));await p.waitForTimeout(200);
   const mi=await B.alertInfo(p);await p.screenshot({path:'shot_bloq_mobile.png'});
   R('B-21','AJ-2: no celular (390x760) a faixa fixa não ocupa mais de 40% da altura da tela',mi&&mi.h<=0.4*760,`altura da faixa=${mi&&mi.h}px de 760 (${mi&&Math.round(100*mi.h/760)}%)`,'AMARELO');
   await p.setViewportSize({width:1280,height:900});
  }
  if(tag==='quar'){
   // faixa fixa (sticky) sobrepõe conteúdo ao rolar?
   await p.evaluate(()=>go('sim'));await p.evaluate(()=>window.scrollTo(0,600));await p.waitForTimeout(200);
   const st=await B.alertInfo(p);
   R('B-22','AJ-2: ao rolar a página a faixa permanece no topo (sticky) e visível',st&&st.top<=2&&st.onTop,`top após rolar=${st&&st.top}`,'AMARELO');
   await p.screenshot({path:'shot_quar_desktop.png'});
  }
  await r.ctx.close();
 }
 // sem risco: nenhuma faixa
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
 const sw0=await sweep(p,allPages);const any=Object.entries(sw0).filter(([,v])=>v).map(([k])=>k);
 R('B-23','Sem risco: livro íntegro não mostra faixa (sem falso alarme)',any.length===0,`telas com faixa: [${any.join(',')}]`,'AMARELO');
 // desaparece após resolver (excluir legado)? já coberto; aqui: aviso some após resolver quarentena? (não há como) -> registrado em B-07
 // exportações do contador / contabilidade carregam aviso?
 await r.ctx.close();
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}])}});p=r.page;
 const btns=await p.evaluate(()=>{const o=[];for(const pg of ['dash','accounting']){go(pg);document.querySelectorAll('#'+pg+' button').forEach(x=>o.push(pg+': '+x.textContent.trim().slice(0,50)))}
   const c=document.querySelectorAll('[id^=ma55]');return {btns:o.slice(0,40),ma55:[...c].map(x=>x.id).slice(0,20)}});
 console.log('botoes',JSON.stringify(btns));
 // Relatório do contador: procurar função/botão
 const rep=await p.evaluate(()=>{const cand=[...document.querySelectorAll('button')].filter(x=>/contador|relat[oó]rio|imprimir|exportar/i.test(x.textContent)).map(x=>({t:x.textContent.trim().slice(0,60),id:x.id,vis:!!x.offsetParent,page:x.closest('.page')?.id||x.closest('[id]')?.id}));return cand.slice(0,30)});
 console.log('candidatos relatório',JSON.stringify(rep));
 fs.writeFileSync('r_b2.json',JSON.stringify(L.results,null,1));await r.ctx.close();await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b2.json',JSON.stringify(L.results,null,1));process.exit(1)});
