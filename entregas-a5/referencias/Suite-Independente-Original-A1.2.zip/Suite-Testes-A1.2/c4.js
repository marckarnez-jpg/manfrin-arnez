// C4: A1.2 — restauração/mesclagem com legados e IDs numéricos, isolamento dos novos caminhos de escrita, módulos
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
const QKEY='ma-ledger-v1-rejeitados-20260101000000';
const QBODY=JSON.stringify({rows:[{foo:1}],createdAt:'2026-01-01T00:00:00Z'});
const care0={version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]};
const mkBk=(ledger)=>JSON.stringify({format:'manfrin-arnez-backup',version:2,createdAt:'2026-10-01T00:00:00Z',care:care0,ledger,rateSettings:{}});
const fullDlg=(r)=>{r.page.removeAllListeners('dialog');r.full=[];r.page.on('dialog',d=>{r.full.push(d.message());d.accept()})};
const reloadWait=p=>p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});
(async()=>{const b=await L.browser();let r,p,k,m,dl;
 // ---------- restauração estrita preserva dados quando recusa (IDs numéricos / legado) ----------
 for(const [id,lab,led] of [['C-90a','ID numérico',[...ok3,{id:77,date:'2026-09-20',bank:'Cora',description:'num',amount:100,kind:'Receita'}]],['C-90b','banco antigo',[...ok3,{id:'Itau:9',date:'2026-09-20',bank:'Itau',description:'leg',amount:100,kind:'Receita'}]]]){
   const seedL=JSON.stringify(B.mkRows(2));
   r=await L.openDev(b,{seed:{'ma-ledger-v1':seedL}});p=r.page;const before=await B.appKeys(p);
   fs.writeFileSync('bk_'+id+'.json',mkBk(led));
   await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_'+id+'.json');await p.waitForTimeout(3000);
   k=await B.appKeys(p);m=await B.bmsg(p);
   R(id,'Restaurar backup com '+lab+' (restaurador estrito, pendente A5): recusa sem alterar nenhum dado atual',k['ma-ledger-v1']===before['ma-ledger-v1']&&k['ma-care-v2']===before['ma-care-v2'],`livro intacto=${k['ma-ledger-v1']===before['ma-ledger-v1']}; cadastro intacto=${k['ma-care-v2']===before['ma-care-v2']}; msg="${m.slice(0,140)}"`,'VERMELHO');
   await r.ctx.close();}
 // restauração de backup no formato 6.1 (fixture)
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(2))}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_restore.json');
 for(let i=0;i<60;i++){await new Promise(x=>setTimeout(x,1000));try{const kk=await B.appKeys(p);if(JSON.parse(kk['ma-ledger-v1']).some(x=>x.description==='Restaurado ficticio'))break;}catch(e){}}
 await reloadWait(p);await p.waitForTimeout(1500);
 k=await B.appKeys(p);const lr=JSON.parse(k['ma-ledger-v1']);
 R('C-91','Backup no formato 6.1 (6 campos, v2) é restaurado normalmente pela dev.3',lr.length===1&&lr[0].description==='Restaurado ficticio',`ledger=${JSON.stringify(lr.map(x=>x.description))}`,'VERMELHO');
 await r.ctx.close();
 // mesclagem: confirmação e arquivo ANTES-MESCLAR
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(2)),[QKEY]:QBODY}});p=r.page;fullDlg(r);
 await p.evaluate(()=>go('accounting'));
 const dlp=p.waitForEvent('download',{timeout:15000}).catch(()=>null);
 await p.setInputFiles('#ma53-merge-file','bk_merge_a1.json');
 dl=await dlp;const snapT=dl?await B.saveDl(dl,'snap_c92.json'):null;await p.waitForTimeout(3500);
 k=await B.appKeys(p);const merged=JSON.parse(k['ma-ledger-v1']);
 R('C-92','Mesclagem: confirmação declara que a cópia ANTES-MESCLAR NÃO inclui quarentenas; arquivo é baixado com o nome novo e 6 campos',!!dl&&/ANTES-MESCLAR-PRINCIPAL-NAO-INCLUI-QUARENTENAS/.test(dl.suggestedFilename())&&/NÃO inclui quarentenas/i.test(r.full.join(' '))&&!!snapT&&Object.keys(JSON.parse(snapT)).join(',')==='format,version,createdAt,care,ledger,rateSettings',`nome=${dl&&dl.suggestedFilename()}; diálogo final="…${(r.full[0]||'').slice(-230)}"`,'AMARELO');
 R('C-93','Mesclagem: lançamentos do backup acrescentados ao livro sem apagar os atuais; quarentena existente intacta',merged.length===2+3&&k[QKEY]===QBODY,`linhas=${merged.length} (esperado 5); quarentena intacta=${k[QKEY]===QBODY}`,'AMARELO');
 R('C-94','Mesclagem (B-102): a cópia ANTES-MESCLAR contém o livro anterior legível mas NÃO a quarentena (omissão declarada)',!!snapT&&JSON.parse(snapT).ledger.length===2&&!/foo/.test(snapT),`linhas do livro na cópia=${snapT&&JSON.parse(snapT).ledger.length}; contém quarentena=${/"foo"/.test(snapT||'')}`,'AMARELO',{info:true});
 await r.ctx.close();

 // ---------- isolamento dos novos caminhos de escrita ----------
 const SENT=B.SENT();
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(5)),[QKEY]:QBODY,'ma-ledger-v1-prev':'PREV-FIC'},realSeed:SENT});p=r.page;
 const real0=await B.realKeys(p);
 await B.addRow(p,'iso 1','5');
 await p.evaluate(()=>{go('ledger');[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/Revisar e arquivar/i.test(x.textContent)).click()});await p.waitForTimeout(400);
 await p.reload();await reloadWait(p);
 await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},6000);
 await B.tryDownload(p,()=>{go('backup');document.getElementById('ma62-export-care-raw').click()},6000);
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_restore.json');
 for(let i=0;i<60;i++){await new Promise(x=>setTimeout(x,1000));try{const kk=await B.appKeys(p);if(JSON.parse(kk['ma-ledger-v1']).some(x=>x.description==='Restaurado ficticio'))break;}catch(e){}}
 await reloadWait(p);await p.waitForTimeout(1500);
 await p.evaluate(()=>{localStorage.clear()});
 const real1=await B.realKeys(p);const raw=await L.rawStore(p);
 const unprefixedNew=Object.keys(raw).filter(x=>!x.startsWith(L.PREFIX)&&!(x in SENT));
 R('C-95','Isolamento: adicionar, arquivar quarentena, backup, cópia bruta, restauração e localStorage.clear() não alteram nenhuma das 6 chaves reais sentinelas nem criam chaves fora do prefixo',JSON.stringify(real0)===JSON.stringify(real1)&&Object.keys(real1).length===6&&unprefixedNew.length===0,`chaves reais antes/depois iguais=${JSON.stringify(real0)===JSON.stringify(real1)}; n=${Object.keys(real1).length}; novas fora do prefixo=${unprefixedNew.length}`,'VERMELHO');
 await r.ctx.close();

 // ---------- navegação pelas 18 páginas sem erros ----------
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
 const pages=await p.evaluate(()=>[...document.querySelectorAll('section.page')].map(s=>s.id));
 const bad=[];
 for(const id of pages){await p.evaluate(i=>go(i),id);await p.waitForTimeout(150);const vis=await p.evaluate(i=>{const e=document.getElementById(i);return e&&!e.hidden},id);if(!vis)bad.push(id);}
 R('C-96','Navegação: todas as páginas abrem sem erro de execução',pages.length>=18&&bad.length===0&&r.errors.filter(x=>/pageerror/.test(x)).length===0,`páginas=${pages.length}; não abriram=[${bad}]; erros=${JSON.stringify(r.errors.slice(0,3))}`,'VERMELHO');
 await r.ctx.close();
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c4.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c4.json',JSON.stringify(L.results,null,1)));
