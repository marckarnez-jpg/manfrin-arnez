// B8: outras rotas de "backup" / exportação que passam por fora do botão guardado
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
(async()=>{const b=await L.browser();let r,p,k,dl;
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}])}});p=r.page;
 // 1) botão "Baixar backup deste arquivo" na Contabilidade
 dl=await B.tryDownload(p,()=>{go('accounting');document.getElementById('ma53-account-backup').click()},5000);
 const st=await p.evaluate(()=>({status:document.getElementById('ma53-recovery-status')?.textContent||'',visStatus:!!document.getElementById('ma53-recovery-status')?.offsetParent,backupMsg:document.getElementById('backup-message')?.textContent?.slice(0,60)||'',backupMsgVisible:!!document.getElementById('backup-message')?.offsetParent}));
 R('B-100','Botão "Baixar backup deste arquivo" (Contabilidade) com livro em quarentena: não pode afirmar que o backup foi solicitado se nada foi gerado',!dl&&!/solicitado/i.test(st.status),`arquivo gerado=${!!dl}; texto visível na Contabilidade="${st.status.slice(0,110)}" (visível=${st.visStatus}); mensagem de recusa fica em #backup-message="${st.backupMsg}" (visível nesta tela=${st.backupMsgVisible})`,'VERMELHO');
 // 2) botão de cabeçalho "Exportar dados"
 const hdr=await p.evaluate(()=>[...document.querySelectorAll('button,a')].filter(x=>/Exportar dados/i.test(x.textContent)).map(x=>({id:x.id,txt:x.textContent.trim(),vis:!!x.offsetParent,parent:x.parentElement?.id||x.parentElement?.className||''})));
 console.log('exportar dados',JSON.stringify(hdr));
 // 3) exportar CSV do livro-caixa com quarentena (inclui só linhas válidas) - registra se avisa
 await p.evaluate(()=>go('ledger'));
 dl=await B.tryDownload(p,()=>document.getElementById('export').click(),5000);const csv=await B.saveDl(dl,'exp_b101.csv');
 R('B-101','Exportação CSV do livro-caixa com quarentena: o arquivo contém só as linhas válidas; há aviso na tela de que há linhas fora?',!!csv&&/quarentena|rejeitada/i.test(await B.msg(p)),`linhas CSV=${csv&&csv.trim().split('\n').length}; mensagem="${(await B.msg(p)).slice(0,100)}"; faixa global visível=${!!(await B.alertInfo(p))}`,'AMARELO');
 await r.ctx.close();
 // 4) snapshot ANTES-MESCLAR com quarentena: depois de gravar e recarregar as linhas ruins já não estão no livro principal
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:'RUIM-FICTICIA'}])}});p=r.page;
 await B.addRow(p,'grava e tira a ruim do principal','5');await p.reload();await B.reloadWait(p);
 await p.evaluate(()=>go('accounting'));
 const [dl2]=await Promise.all([p.waitForEvent('download',{timeout:60000}).catch(()=>null),p.setInputFiles('#ma53-merge-file','bk_merge.json').then(()=>p.waitForTimeout(1500))]);
 let snap=null;if(dl2){await dl2.saveAs('snap_b102.json');snap=JSON.parse(fs.readFileSync('snap_b102.json','utf8'))}
 k=await B.appKeys(p);const q=B.qKeys(k);
 const hasBad=snap&&JSON.stringify(snap.ledger).includes('RUIM-FICTICIA');
 R('B-102','Mesclagem: o arquivo automático "ANTES-MESCLAR" inclui as linhas em quarentena ou avisa que elas ficaram de fora',!!snap&&(hasBad||/quarentena/i.test(await p.evaluate(()=>document.getElementById('ma53-recovery-status')?.textContent||document.body.innerText.slice(0,0)))),`snapshot gerado=${!!snap}; contém linha em quarentena=${!!hasBad}; lançamentos no snapshot=${snap&&snap.ledger.length}; chaves de quarentena=${q.length}`,'AMARELO');
 await r.ctx.close();
 // 5) botão "Abrir Conciliação" da faixa
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}])}});p=r.page;
 await p.evaluate(()=>{go('dash');[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/Abrir Concilia/i.test(x.textContent)).click()});await p.waitForTimeout(300);
 const vis=await p.evaluate(()=>({ledger:!document.getElementById('ledger').hidden,dash:!document.getElementById('dash').hidden,navActive:document.querySelector('nav button.active')?.dataset.page}));
 R('B-103','Faixa: botão "Abrir Conciliação" leva à tela do livro-caixa',vis.ledger&&!vis.dash,`ledger visível=${vis.ledger}; dash visível=${vis.dash}; item de menu ativo=${vis.navActive}`,'AMARELO');
 await r.ctx.close();
 fs.writeFileSync('r_b8.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b8.json',JSON.stringify(L.results,null,1));process.exit(1)});
