// C3: A1.2 — AJ-16 (IDs numéricos, totais), AJ-17 (correção explícita campo a campo), B-09 B-31 B-32 B-37 e desempenho
const B=require('./b_lib');const {L,R,fs}=B;
const base=B.mkRows(3);
const NUM={id:123,date:'2026-09-10',bank:'Cora',description:'id numerico',amount:5000,kind:'Receita'};
const STR={id:'123',date:'2026-09-11',bank:'Sicredi',description:'id texto',amount:700,kind:'Receita'};
const DESP={id:'D1',date:'2026-09-12',bank:'Cora',description:'despesa',amount:-2000,kind:'Despesa'};
const ITAU={id:'Itau:1',date:'2026-09-13',bank:'Itau',description:'banco antigo',amount:500,kind:'Receita'};
const DOIS={id:'Z1',date:'2026-09-14',bank:'Nubank',description:'dois campos',amount:700,kind:'Pix'};
const SINAL={id:'S1',date:'2026-09-15',bank:'Cora',description:'sinal errado',amount:-300,kind:'Receita'};
const FLT={id:'F1',date:'2026-09-16',bank:'Cora',description:'valor quebrado',amount:10.5,kind:'Receita'};
const bk=p=>B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},8000);
const open=(p)=>p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
const rowIdx=(p,desc)=>p.evaluate(d=>{const tr=[...document.querySelectorAll('#transactions tr')].find(t=>t.textContent.includes(d));return tr?Number(tr.querySelector('[data-delete]').dataset.delete):-1},desc);
const metrics=p=>p.evaluate(()=>[...document.querySelectorAll('#ledger-metrics article')].map(a=>a.querySelector('small').textContent+'='+a.querySelector('strong').textContent));
// executa a correção pelo diálogo; devolve {msg, dialogs}
async function edit(p,desc,field,value,{accept=true}={}){
  await open(p);const idx=await rowIdx(p,desc);const dlg=[];
  p.removeAllListeners('dialog');p.on('dialog',d=>{dlg.push(d.message());accept?d.accept():d.dismiss()});
  await p.evaluate(i=>document.querySelector(`#transactions [data-edit-legacy="${i}"]`).click(),idx);
  await p.waitForSelector('#ma62-edit-legacy',{timeout:5000}).catch(()=>0);
  await p.selectOption('#ma62-edit-field',field);await p.fill('#ma62-edit-value',String(value));
  await p.click('#ma62-edit-legacy button[type=submit]');await p.waitForTimeout(500);
  const open_=await p.evaluate(()=>!!document.getElementById('ma62-edit-legacy'));
  const emsg=await p.evaluate(()=>document.getElementById('ma62-edit-message')?.textContent||'');
  const lmsg=await B.msg(p);
  if(open_)await p.evaluate(()=>document.getElementById('ma62-edit-legacy')?.close());
  return {dlg,open:open_,emsg,lmsg};
}
const led=async p=>JSON.parse((await B.appKeys(p))['ma-ledger-v1']);
(async()=>{const b=await L.browser();let r,p,k,m,dl,e;
 // ---------- B-31 / B-32 / C-50 ----------
 const SEED1=JSON.stringify([...base,NUM,STR,DESP]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEED1}});p=r.page;
 const shownN=await B.shown(p);k=await B.appKeys(p);const q=B.qKeys(k);
 R('B-31','AJ-16: ID numérico finito fica na lista (sem quarentena indevida) e o livro é byte-idêntico',shownN===6&&q.length===0&&k['ma-ledger-v1']===SEED1,`linhas exibidas=${shownN}/6; quarentenas=${q.length}; livro byte-idêntico=${k['ma-ledger-v1']===SEED1}`,'AMARELO');
 const mt=await metrics(p);
 // base: 3 receitas (1000+2000+3000=6000) + NUM 5000 + STR 700 = 11700 -> R$ 117,00 ; despesa 2000 -> R$ 20,00
 const txt=mt.join(' | ').replace(/ /g,' ');
 R('B-32','AJ-16: totais incluem as linhas de ID numérico (receitas R$ 117,00; despesas R$ 20,00 sobre os valores originais)',/Receitas classificadas=R\$\s?117,00/.test(txt)&&/Despesas operacionais=R\$\s?20,00/.test(txt),`métricas="${txt}"`,'AMARELO');
 // delete por posição: NUM (123) vs STR ("123")
 p.removeAllListeners('dialog');let dd=[];p.on('dialog',d=>{dd.push(d.message());d.dismiss()});
 let iN=await rowIdx(p,'id numerico');await p.evaluate(i=>document.querySelector(`#transactions [data-delete="${i}"]`).click(),iN);await p.waitForTimeout(400);
 k=await B.appKeys(p);
 R('C-51','AJ-16: excluir com confirmação CANCELADA não altera o livro (byte-idêntico)',k['ma-ledger-v1']===SEED1&&dd.length===1,`livro idêntico=${k['ma-ledger-v1']===SEED1}; diálogo="${(dd[0]||'').slice(0,100)}"`,'VERMELHO');
 p.removeAllListeners('dialog');p.on('dialog',d=>d.accept());
 iN=await rowIdx(p,'id numerico');await p.evaluate(i=>document.querySelector(`#transactions [data-delete="${i}"]`).click(),iN);await p.waitForTimeout(500);
 let L1=await led(p);
 R('C-52','AJ-16: excluir a linha de id 123 (numérico) remove SÓ ela; a linha "123" (texto) permanece com tipo string',L1.length===5&&!L1.some(x=>x.id===123)&&L1.some(x=>x.id==='123'&&typeof x.id==='string'),`linhas=${L1.length}; ids=${JSON.stringify(L1.map(x=>x.id))}`,'VERMELHO');
 await r.ctx.close();
 // excluir a de texto, manter a numérica
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEED1}});p=r.page;
 await open(p);iN=await rowIdx(p,'id texto');await p.evaluate(i=>document.querySelector(`#transactions [data-delete="${i}"]`).click(),iN);await p.waitForTimeout(500);L1=await led(p);
 R('C-53','AJ-16: excluir a linha "123" (texto) remove SÓ ela; a numérica 123 permanece com tipo number',L1.length===5&&L1.some(x=>x.id===123&&typeof x.id==='number')&&!L1.some(x=>x.id==='123'),`ids=${JSON.stringify(L1.map(x=>x.id))}`,'VERMELHO');
 // categoria da numérica
 await open(p);iN=await rowIdx(p,'id numerico');
 await p.evaluate(i=>{const s=document.querySelector(`#transactions select[data-row="${i}"]`);s.value='A classificar';s.dispatchEvent(new Event('change',{bubbles:true}))},iN);await p.waitForTimeout(500);L1=await led(p);
 const nr=L1.find(x=>x.description==='id numerico');
 R('C-54','AJ-16: alterar categoria de linha de ID numérico preserva o tipo do ID e o valor',nr&&nr.id===123&&typeof nr.id==='number'&&nr.kind==='A classificar'&&nr.amount===5000,`linha=${JSON.stringify(nr)}`,'AMARELO');
 // CSV export com id numérico
 const cd=await B.tryDownload(p,()=>{go('ledger');document.getElementById('export').click()},6000);const ct=await B.saveDl(cd,'exp_c55.csv');
 R('C-55','AJ-16: exportação CSV funciona com ID numérico (sem exceção) e inclui a linha',!!ct&&/123/.test(ct)&&!r.errors.some(x=>/pageerror/.test(x)),`csv=${ct&&ct.split('\n').length} linhas; erros de página=${r.errors.filter(x=>/pageerror/.test(x)).length}`,'AMARELO');
 // importar CSV sobre livro com id numérico
 await p.setInputFiles('#csv','csv_ok.csv');await p.waitForTimeout(800);L1=await led(p);
 R('C-56','AJ-16: importar CSV acrescenta linhas sem converter o ID numérico existente',L1.some(x=>x.id===123&&typeof x.id==='number')&&L1.length>5,`linhas=${L1.length}; numérico preservado=${L1.some(x=>x.id===123&&typeof x.id==='number')}; msg="${(await B.msg(p)).slice(0,100)}"`,'AMARELO');
 await r.ctx.close();
 // backup com id numérico
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEED1}});p=r.page;
 dl=await bk(p);m=await B.bmsg(p);
 const rd=await B.tryDownload(p,()=>{go('ledger');[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/original bruto/i.test(x.textContent)).click()},6000);const rt=await B.saveDl(rd,'raw_c57.json');
 R('C-57','AJ-16: backup com ID numérico é recusado EXPLICITAMENTE e o livro bruto exato pode ser baixado',!dl&&/ID numérico/i.test(m)&&rt===SEED1,`download backup=${!!dl}; msg="${m.slice(0,170)}"; bruto idêntico=${rt===SEED1}`,'AMARELO');
 await r.ctx.close();
 // ids inválidos -> quarentena
 const BADID=[{id:null,date:'2026-09-01',bank:'Cora',description:'id nulo',amount:100,kind:'Receita'},{id:{x:1},date:'2026-09-02',bank:'Cora',description:'id objeto',amount:100,kind:'Receita'},{id:'',date:'2026-09-03',bank:'Cora',description:'id vazio',amount:100,kind:'Receita'},{id:NaN,date:'2026-09-04',bank:'Cora',description:'id nan',amount:100,kind:'Receita'}];
 const SEEDB=JSON.stringify([...base,...BADID]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEEDB}});p=r.page;
 k=await B.appKeys(p);const qb=B.qKeys(k);const n=await B.shown(p);
 R('C-58','AJ-16: IDs inválidos (null, objeto, vazio) vão à quarentena; livro original preservado; válidas visíveis',qb.length>=1&&n===3&&k['ma-ledger-v1']===SEEDB,`quarentenas=${qb.length}; exibidas=${n}; livro idêntico=${k['ma-ledger-v1']===SEEDB}`,'AMARELO');
 await r.ctx.close();

 // ---------- AJ-17 B-09: banco antigo ----------
 const SEEDI=JSON.stringify([...base,ITAU]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEEDI}});p=r.page;
 dl=await bk(p);m=await B.bmsg(p);
 R('C-60','AJ-17: com banco antigo ("Itau") o backup é recusado (comportamento declarado)',!dl&&/RECUSAD/i.test(m),`download=${!!dl}; msg="${m.slice(0,130)}"`,'AMARELO');
 await open(p);const warn=await p.evaluate(()=>[...document.querySelectorAll('#transactions small')].map(s=>s.textContent).filter(t=>/antigo/i.test(t)).join(' | '));
 R('C-61','AJ-17: a linha antiga mostra QUAL campo está inconsistente (não só "conferir campos")',/banco/i.test(warn),`aviso na linha="${warn.slice(0,160)}"`,'AMARELO');
 e=await edit(p,'banco antigo','bank','Cora');L1=await led(p);const it=L1.find(x=>x.description==='banco antigo');
 R('B-09','AJ-17: banco antigo é corrigido explicitamente SEM excluir o lançamento; id, valor, data, descrição e categoria intactos',!!it&&it.bank==='Cora'&&it.id==='Itau:1'&&it.amount===500&&it.date==='2026-09-13'&&it.kind==='Receita'&&L1.length===4,`linha=${JSON.stringify(it)}; total=${L1.length}; msg="${e.lmsg.slice(0,100)}"`,'AMARELO');
 dl=await bk(p);
 R('C-62','AJ-17: depois de corrigir o banco o backup principal é liberado (sem precisar excluir dado)',!!dl,`download=${!!dl}; msg="${(await B.bmsg(p)).slice(0,120)}"`,'AMARELO');
 await r.ctx.close();

 // ---------- B-37: dois campos inconsistentes ----------
 const SEEDZ=JSON.stringify([...base,DOIS]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEEDZ}});p=r.page;
 e=await edit(p,'dois campos','kind','Receita');L1=await led(p);let z=L1.find(x=>x.description==='dois campos');
 R('B-37','AJ-17: categoria de legado com OUTRO campo inválido (banco) é corrigível isoladamente; banco, valor e demais campos intactos',!!z&&z.kind==='Receita'&&z.bank==='Nubank'&&z.amount===700&&z.id==='Z1'&&z.date==='2026-09-14',`linha=${JSON.stringify(z)}; diálogo="${(e.dlg[0]||'').slice(0,120)}"; msg="${e.lmsg.slice(0,140)}"`,'AMARELO');
 R('C-63','AJ-17: mudança de categoria pede confirmação e informa impacto nos totais',e.dlg.length>=1&&/categoria/i.test(e.dlg[0])&&/totais/i.test(e.dlg[0]),`diálogo="${(e.dlg[0]||'').slice(0,200)}"`,'AMARELO');
 dl=await bk(p);
 R('C-64','AJ-17: com o banco ainda inválido o backup continua recusado (não destrava indevidamente)',!dl,`download=${!!dl}`,'AMARELO');
 e=await edit(p,'dois campos','bank','Sicredi');L1=await led(p);z=L1.find(x=>x.description==='dois campos');dl=await bk(p);
 R('C-65','AJ-17: corrigido o segundo campo, o registro sai da lista de legados e o backup é liberado',z.bank==='Sicredi'&&!!dl,`linha=${JSON.stringify(z)}; backup=${!!dl}`,'AMARELO');
 await r.ctx.close();

 // ---------- valor / data / descrição / sinal ----------
 const SEEDF=JSON.stringify([...base,FLT,SINAL]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':SEEDF}});p=r.page;
 let before=(await B.appKeys(p))['ma-ledger-v1'];
 e=await edit(p,'valor quebrado','amount','1050',{accept:false});k=await B.appKeys(p);
 R('C-66','AJ-17: alteração monetária mostra "antes → depois" em centavos e, se CANCELADA, o livro fica byte-idêntico',k['ma-ledger-v1']===before&&e.dlg.length>=1&&/10\.5.*1050/.test(e.dlg[0]),`diálogo="${(e.dlg[0]||'').slice(0,200)}"; livro idêntico=${k['ma-ledger-v1']===before}; msg="${(e.emsg||e.lmsg).slice(0,100)}"`,'VERMELHO');
 for(const [lab,val] of [['vírgula decimal','10,5'],['zero','0'],['vazio',''],['texto','abc'],['decimal','10.5'],['negativo em receita','-500']]){
   if(val===''){continue}
   e=await edit(p,'valor quebrado','amount',val);k=await B.appKeys(p);
   R('C-67-'+lab.replace(/\s/g,'_'),'AJ-17: valor inválido ('+lab+') é recusado sem alterar o livro',k['ma-ledger-v1']===before,`entrada="${val}"; livro idêntico=${k['ma-ledger-v1']===before}; msg="${(e.emsg||e.lmsg).slice(0,120)}"`,'VERMELHO');}
 e=await edit(p,'valor quebrado','amount','1050');L1=await led(p);let f=L1.find(x=>x.description==='valor quebrado');
 R('C-68','AJ-17: valor corrigido (aceito) altera só o amount; os outros campos e as outras linhas ficam idênticos',f&&f.amount===1050&&f.id==='F1'&&f.date==='2026-09-16'&&JSON.stringify(L1.filter(x=>x.id!=='F1'))===JSON.stringify(JSON.parse(before).filter(x=>x.id!=='F1')),`linha=${JSON.stringify(f)}`,'AMARELO');
 // data inválida / válida
 before=(await B.appKeys(p))['ma-ledger-v1'];
 e=await edit(p,'valor quebrado','date','2026-02-30');k=await B.appKeys(p);
 R('C-69','AJ-17: data inexistente (2026-02-30) é recusada, livro intacto',k['ma-ledger-v1']===before,`msg="${(e.emsg||e.lmsg).slice(0,120)}"`,'AMARELO');
 e=await edit(p,'valor quebrado','description','   ');k=await B.appKeys(p);
 R('C-70','AJ-17: descrição em branco é recusada, livro intacto',k['ma-ledger-v1']===before,`msg="${(e.emsg||e.lmsg).slice(0,120)}"`,'AMARELO');
 // sinal
 e=await edit(p,'sinal errado','amount','-100');k=await B.appKeys(p);
 R('C-71','AJ-17: Receita com valor negativo — outro valor ainda negativo é recusado com mensagem de sinal',k['ma-ledger-v1']===before&&/positiva|sinal|negativ/i.test(e.emsg+e.lmsg),`msg="${(e.emsg||e.lmsg).slice(0,160)}"`,'AMARELO');
 e=await edit(p,'sinal errado','kind','Despesa');L1=await led(p);const sg=L1.find(x=>x.description==='sinal errado');
 R('C-72','AJ-17: categoria Despesa para valor negativo corrige o sinal sem alterar o valor',sg&&sg.kind==='Despesa'&&sg.amount===-300,`linha=${JSON.stringify(sg)}`,'AMARELO');
 dl=await bk(p);
 R('C-73','AJ-17: após corrigir todas as linhas legadas o backup é liberado',!!dl,`download=${!!dl}; msg="${(await B.bmsg(p)).slice(0,100)}"`,'AMARELO');
 await r.ctx.close();

 // ---------- desempenho com 12.000 linhas ----------
 const big=JSON.stringify(B.mkRows(12000));
 r=await L.openDev(b,{seed:{'ma-ledger-v1':big}});p=r.page;
 const t0=Date.now();await open(p);const tR=Date.now()-t0;
 const t1=Date.now();m=await B.addRow(p,'em 12000','10');const tW=Date.now()-t1;k=await B.appKeys(p);
 R('C-80','AJ-15/16: 12.000 linhas — abertura do livro e gravação de 1 lançamento em tempo aceitável',tR<4000&&tW<4000&&JSON.parse(k['ma-ledger-v1']).length===12001,`abrir=${tR} ms; gravar=${tW} ms (inclui render); load=${r.loadMs} ms; linhas=${JSON.parse(k['ma-ledger-v1']).length}`,'AMARELO');
 await r.ctx.close();
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c3.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c3.json',JSON.stringify(L.results,null,1)));
