// S7: download das linhas rejeitadas; injeção de falhas (quarentena não grava; leitura lança exceção)
const H=require('./a1lib');const {L,row,fs}=H;
async function ctxWith(b,seed,hook){const ctx=await b.newContext({acceptDownloads:true,viewport:{width:1280,height:900}});const page=await ctx.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message.slice(0,150)));page.on('dialog',d=>d.accept());
 await page.addInitScript(({seed,PREFIX,hook})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(seed))localStorage.setItem(PREFIX+k,v);}}catch(e){}
  if(hook==='quarantine-fail'){const o=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(String(k).includes('rejeitados'))throw new DOMException('QuotaExceededError','QuotaExceededError');return o.call(this,k,v)}}
  if(hook==='read-throws'&&window===window.top){const g=Storage.prototype.getItem;let n=0;Storage.prototype.getItem=function(k){if(String(k).endsWith('ma-ledger-v1')&&n++===0)throw new Error('SecurityError simulado');return g.call(this,k)}}
 },{seed,PREFIX:L.PREFIX,hook});
 await page.goto(L.DEV,{timeout:240000});await page.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return {ctx,page,errors}}
(async()=>{const b=await L.browser();
 const bad={id:'Cora:BAD',date:'2026-09-09',bank:'Cora',description:'<img src=x onerror="window.__x=1">',kind:'Receita'};
 const RAW=JSON.stringify([row(1),bad,row(2)]);
 // leitura lança exceção
 {const {ctx,page:p,errors}=await ctxWith(b,{'ma-ledger-v1':RAW},'read-throws');
  const bn=await H.banner(p);const m=await H.addRow(p,'tentativa leitura falhou');const k=await H.appKeys(p);
  L.record('A1-72','Exceção ao ler o armazenamento (acesso negado): bloqueia gravações e preserva o conteúdo',(k['ma-ledger-v1']===RAW&&bn&&/BLOQUEADO/.test(bn.text))?'APROVADO':'REPROVADO',`texto idêntico=${k['ma-ledger-v1']===RAW}; aviso="${bn?.text?.slice(0,100)}"; mensagem="${m.slice(0,70)}"; erros=${errors.length}`);
  await ctx.close();}
 fs.writeFileSync('r_s7b.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s7b.json',JSON.stringify(L.results,null,1));process.exit(1)});
