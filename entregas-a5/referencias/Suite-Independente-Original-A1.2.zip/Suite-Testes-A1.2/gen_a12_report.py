import json,re,sys
from collections import Counter
OUT=sys.argv[1] if len(sys.argv)>1 else 'Auditoria-Independente-A1.2-6.2-dev.3.md'
M=json.load(open('a12_matrix.json'))
c=Counter(r[3] for r in M);s=Counter(r[4] for r in M);n=len(M)
ID={r[1]:r for r in M}
def esc(t,k=330):
    t=str(t).replace('|','\\|').replace('\n',' ')
    t=re.sub(r'[\u26d4\u26a0\ufe0f\U0001F300-\U0001FAFF]\s?','',t)
    return t if len(t)<=k else t[:k-1]+'…'
def sg(i):return ID[i][4] if i in ID else '?'
def rs(i):return ID[i][3] if i in ID else '?'
TIT={'A':'A. Integridade e escopo da entrega (verificações estáticas e de documento)',
'B':'B. AJ-11 — Backup, recusa na tela acionada e verificação do arquivo',
'C':'C. AJ-12 — Quarentena revisada/arquivada, cópia bruta do cadastro, mesclagem',
'D':'D. AJ-13 — Aprovação externa de uso único',
'E':'E. AJ-14 — Chave -prev intacta e cópia por operação',
'F':'F. AJ-15 — Sem limite de 900.000, cota real, falhas, duas abas, desempenho',
'G':'G. AJ-16 — IDs numéricos, totais e linhas antigas preservadas',
'H':'H. AJ-17 — Correção explícita campo a campo',
'I':'I. Achados novos da A1.2',
'J':'J. Restauração, mesclagem, formatos, compatibilidade com a 6.1 DEV, pagamentos e evoluções',
'K':'K. Isolamento e demais módulos (Central Sanitária, Academia, Laboratório, simulador, 18 telas)',
'L':'L. Regressão herdada: faixa global e quarentena',
'M':'M. Regressão herdada: suíte A1 da dev.1',
'N':'N. Defeitos pré-existentes, fora do escopo da A1.2'}
def table(g):
    out=['| ID | Verificação | Resultado | Sinal | Evidência |','|---|---|---|---|---|']
    for r in M:
        if r[0]==g:out.append(f'| {r[1]} | {esc(r[2],200)} | {r[3]} | **{r[4]}** | {esc(r[5])} |')
    return '\n'.join(out)
def cnt(g):
    rs_=[r for r in M if r[0]==g];return len(rs_),sum(1 for r in rs_ if r[3]=='APROVADO')
new_tests=n-8
red=[r for r in M if r[4]=='VERMELHO']
md=f"""# Auditoria independente — A1.2 (6.2 DEV.3)
**Dashboard Manfrin Arnez · versão 6.2-dev.3 · A1.2 (DEV, dados fictícios) · 11/10/2026**
Autor: Claude (auditor independente) · Destinatários: Dr. Marck Arnez e Codex/ChatGPT (coordenação)

> **Veredito: A1.2 APROVADA COM RESSALVAS. A etapa A1 pode ser encerrada e a A5 pode ser iniciada, desde que você autorize e que os três achados novos (N-1, N-2, N-3, todos AMARELO) entrem como itens de entrada da A5.** Os sete ajustes pedidos (AJ-11 a AJ-17) foram corrigidos e comprovados em Chromium real aberto por `file://`. Os dez cenários críticos (B-06, B-07, B-09, B-31, B-32, B-37, B-67, B-69, B-79 e B-100) passaram. Nenhum VERMELHO novo foi introduzido; os {s['VERMELHO']} VERMELHOS que restam são os mesmos defeitos pré-existentes que o Codex declarou como fora do escopo e que pertencem à A5 (e um à A2/A3). Nenhum dado foi perdido em nenhum cenário, inclusive nos de cota esgotada e de falha injetada.

---

## 0. Resumo

Matriz desta auditoria: **{n} verificações — {c['APROVADO']} APROVADO, {c['REPROVADO']} REPROVADO, {c['NÃO TESTADO']} NÃO TESTADO.** Sinais: **{s['VERDE']} VERDE, {s['AMARELO']} AMARELO, {s['VERMELHO']} VERMELHO.** Os REPROVADOS não são regressões: são 3 achados novos da A1.2 (N-1, N-2, N-3), 2 limitações já declaradas (A5) e pendências pré-existentes. Dos {s['VERMELHO']} VERMELHOS, nenhum é novo: A1-48, P1-0, P1-7b e BKP-02 já constavam nas rodadas anteriores.

| O que você pediu | Resultado | Sinal |
|---|---|---|
| AJ-11 — botões de backup informam a recusa na tela acionada; "solicitado" distinto de "verificado" | Corrigido e comprovado (B-100 e C-01 a C-11) | **VERDE** |
| AJ-12 — quarentena pode ser revisada/arquivada; backup não fica bloqueado para sempre; cópia bruta do cadastro | Corrigido e comprovado (B-06, B-07, B-79, C-09 a C-21) | **VERDE** |
| AJ-13 — aprovação externa vinculada ao estado, de uso único, com estado próprio | Corrigido e comprovado (C-38 a C-42b, B-67) | **VERDE** |
| AJ-14 — `-prev` nunca sobrescrita; cópia bruta nova por operação | Corrigido e comprovado (C-30 a C-35, B-69); ver N-1 | **VERDE** (com N-1) |
| AJ-15 — fim do limite de 900.000; proteção real; falhas sem perda | Corrigido e comprovado (B-61, C-36 a C-46) | **VERDE** |
| AJ-16 — IDs numéricos lidos sem conversão; totais; exclusão por posição | Corrigido e comprovado (B-31, B-32, C-51 a C-58, b3 de 12 variantes); ver N-2 | **VERDE** (com N-2) |
| AJ-17 — correção explícita, campo a campo, com confirmação monetária | Corrigido e comprovado (B-09, B-37, C-60 a C-73) | **VERDE** |
| Preservação de dados e isolamento | Chaves reais sentinelas intactas em todos os novos caminhos de escrita (C-95) | **VERDE** |
| Compatibilidade com registros antigos, backups e 6.1 | 6.1 DEV lê e grava sobre os dados da dev.3 e restaura seus backups (B-90, B-91, B-91b); 6 campos do formato v2 preservados | **VERDE** |
| Demais módulos | 18 telas, Central Sanitária (8 frentes / 42 subtópicos), Academia, Laboratório, Exocad, simulador, pagamentos, evoluções, contabilidade: sem regressão | **VERDE** |
| Achados novos | N-1 retenção sem limpeza; N-2 livro só com ID numérico sem botão do bruto; N-3 faixa permanente após a primeira gravação | **AMARELO** |

---

## 1. Confirmação independente da declaração do Codex (97 aprovadas, 0 reprovadas, 3 pendências)

**Confirmado, com duas qualificações.**

1. **O documento confere.** `resultados.json` tem 100 verificações: 97 APROVADO, 0 REPROVADO e 3 PENDENTE, exatamente como o Codex e você informaram. As três pendências são A5-RESTAURACAO-LEGADOS, 6.1-NAVEGADOR-IDA-E-VOLTA e A5-RESTAURACAO-FIEL-E-COMPLETA; todas são fora do escopo da A1.2 e já estavam declaradas. O hash do HTML bate com `SHA256SUMS.txt`, com o relatório e com o `resultados.json`. (Verificações estáticas.)
2. **A substância confere.** Repeti os critérios em `file://`, que é como você abre o HTML, e todos os dez cenários que o Codex marcou como aprovados (B-06, B-07, B-09, B-31, B-32, B-37, B-67, B-69, B-79, B-100) passaram também comigo, com fixtures e scripts meus, sem usar nada do pacote de testes dele. **Não executei os scripts do Codex** (`testes_a1_2.py`, `gerar_dev3.py`): li-os como dados. A reprodutibilidade do HTML eu confirmei de outro modo: apliquei o `.diff` entregue sobre uma cópia da dev.2 com `patch` e o resultado ficou byte a byte idêntico à dev.3 (mesmo SHA-256). Logo, não existe mudança fora do diff que li inteiro.
3. **Qualificação 1: a contagem 97 é inflada.** Contei no `resultados.json`: 29 das 97 aprovações são verificações auxiliares repetidas ao fim de cada cenário (11 CONSOLE-n, 11 ISOLAMENTO-n e 7 BACKUP-RECUSADO-n). Sobram 68 verificações de conteúdo. (Numa mensagem de andamento eu havia dito "cerca de 26"; o número correto é 29.) Isso não é um defeito, mas o "97" não deve ser lido como 97 comportamentos diferentes.
4. **Qualificação 2: o ambiente do Codex bloqueou `file://`.** Ele testou por HTTP loopback e declarou isso. Como o HTML é aberto por `file://`, repeti tudo assim; não encontrei nenhuma diferença de comportamento causada pelo transporte.
5. **Onde divergi do relatório do Codex** (sempre em detalhe, nunca no núcleo): (a) o relatório afirma que, com ID numérico, "a cópia BRUTA permanece disponível"; isso só é verdade se a faixa global estiver visível, o que não acontece quando o único problema é o ID numérico (N-2); (b) o relatório admite que a retenção de cópias "consome cota" mas não a quantifica; medi: 63 operações com 500 linhas, 21 com 1.500 (N-1); (c) o relatório não menciona que a faixa de atenção passa a ser permanente a partir da primeira gravação (N-3).

---

## 2. Os testes críticos que você pediu, repetidos

| Teste | Descrição | Resultado | Sinal |
|---|---|---|---|
| AJ-11 | Recusa aparece na tela acionada; solicitado ≠ verificado | {rs('B-100')} | **{sg('B-100')}** |
| AJ-12 | Quarentena revisável; cópia bruta do cadastro | {rs('B-07')} | **{sg('B-07')}** |
| AJ-13 | Aprovação externa de uso único e estados distintos | {rs('C-40')} | **{sg('C-40')}** |
| AJ-14 | `-prev` intacta; cópia por operação com os bytes exatos | {rs('C-30')} | **{sg('C-30')}** |
| AJ-15 | Sem limite de 900.000; cota real; falha do principal sem perda | {rs('B-61')} | **{sg('B-61')}** |
| AJ-16 | ID numérico preservado, totais corretos, exclusão por posição | {rs('C-52')} | **{sg('C-52')}** |
| AJ-17 | Correção campo a campo, centavos antes/depois, cancelar preserva | {rs('C-66')} | **{sg('C-66')}** |
| B-06 | Backup não fica bloqueado para sempre | {rs('B-06')} | **{sg('B-06')}** |
| B-07 | Existe saída dentro do app para a quarentena | {rs('B-07')} | **{sg('B-07')}** |
| B-09 | Banco antigo corrigido sem excluir o lançamento | {rs('B-09')} | **{sg('B-09')}** |
| B-31 | ID numérico fica visível, sem quarentena indevida | {rs('B-31')} | **{sg('B-31')}** |
| B-32 | Totais incluem a linha de ID numérico (igual à 6.1 DEV para as 12 variantes) | {rs('B-32')} | **{sg('B-32')}** |
| B-37 | Categoria corrigível com outro campo inválido | {rs('B-37')} | **{sg('B-37')}** |
| B-61 | Livro de 1.077.781 caracteres grava, com cópia local exata | {rs('B-61')} | **{sg('B-61')}** |
| B-67 | Faixa não repete "sem espaço" depois de liberar e gravar | {rs('B-67')} | **{sg('B-67')}** |
| B-69 | `-prev` antiga intacta e rotulada | {rs('B-69')} | **{sg('B-69')}** |
| B-79 | Depois de restaurar backup limpo, quarentena e revisão ficam e o backup volta a funcionar | {rs('B-79')} | **{sg('B-79')}** |
| B-100 | Contabilidade: recusa sem download e sem anunciar sucesso | {rs('B-100')} | **{sg('B-100')}** |
| B-102 | Cópia ANTES-MESCLAR declara que omite quarentenas | {rs('B-102')} | **{sg('B-102')}** |
| B-119 | Restaurar backup antigo com banco fora do padrão | {rs('B-119')} | **{sg('B-119')}** |

Notas honestas sobre o que "passou" significa:

- **B-79** foi aprovado na forma que o Codex redefiniu (quarentena **revisada** permanece e não impede o backup). O cenário literal original (quarentena **não** revisada, depois restaurar) continua bloqueado por desenho: o usuário precisa arquivar a quarentena. Isso é coerente com AJ-12, mas é uma condição.
- **B-102** passa porque agora há aviso na confirmação da mesclagem; a omissão das quarentenas no arquivo ANTES-MESCLAR continua, declarada, e as quarentenas permanecem intactas no armazenamento (C-93).
- **B-119** continua AMARELO porque a restauração de backups com bancos fora do padrão ou ID numérico segue recusada. A recusa é segura (C-90a e C-90b: nada é alterado), e o Codex declarou isso como pendência da A5.

---

## 3. Achados novos da A1.2 (nenhum causa perda de dados)

### N-1 · AMARELO · A retenção de uma cópia completa por operação, sem limpeza, esgota a cota
O Codex implementou corretamente a regra "uma cópia bruta antes de cada operação, nunca apagar". O efeito, medido no Chromium real (cota de cerca de 5,2 milhões de caracteres, já com a base DEV embutida de 1,2 milhão):

- Livro de **500 linhas** (58.781 caracteres): **63 operações** até a primeira recusa por cota.
- Livro de **1.500 linhas** (177.781 caracteres): **21 operações**.
- Depois disso, toda gravação do livro é recusada ("não foi possível proteger a operação") e só continua com baixar e confirmar uma cópia externa **a cada operação** (AJ-13, uso único).
- A cota é compartilhada com pacientes, pagamentos e evoluções: no meu cenário, depois da recusa ainda couberam 82 pagamentos; em seguida os pagamentos também foram recusados ("libere espaço no navegador"), sem corromper nada.
- **Não existe, dentro do app, botão para apagar cópias antigas** (C-83). O único alívio é limpar dados do navegador, o que apagaria tudo e é exatamente o que não pode acontecer.

Evidência: C-81-500, C-81-1500, C-82, C-83. Classifico AMARELO porque nenhum dado é perdido e o app recusa com clareza; mas é **bloqueante para uso clínico real** (uma clínica que lance alguns itens por dia chega à cota em poucas semanas). **Ajuste sugerido (não implementado):** (a) botão "Apagar cópias antigas por operação" com lista, tamanho, confirmação explícita e regra de manter as K mais recentes e qualquer cópia ainda não baixada; (b) indicador de uso de armazenamento na faixa; (c) nunca remover quarentenas nem revisões. Pontos do código: `persist()`, linhas 313-345 (criação da cópia, 320-337); `ma62ReadSnapshots`, linha 192; montagem da lista de cópias em `ma62LedgerBanner`, a partir da linha 208.

### N-2 · AMARELO · Livro só com ID numérico: backup recusado, mas sem botão do livro bruto
Se o livro tem apenas linhas válidas, incluindo uma com ID numérico, `ma62RequestBackup` recusa o backup principal (linha 534, "ID numérico preservado no livro; ... Use a cópia BRUTA"). Porém `ma62LedgerBanner` só aparece quando há risco (linha 214) e o ID numérico não conta como risco; portanto **não há faixa e não há botão "Baixar original bruto"**. Confirmei com sonda isolada: as quatro telas testadas ficam sem faixa. O CSV continua exportável, e a restauração recusa com segurança, mas a instrução na mensagem manda para um recurso que não existe nesse estado. Além disso o backup recusado impede também a cópia **restaurável** de pacientes, pagamentos e evoluções (resta a cópia BRUTA do cadastro, que existe). Evidência: C-57.
**Ajuste sugerido:** incluir `rows.some(r=>typeof r.id!=='string')` na condição `hasRisk` da linha 214, ou colocar um botão "Baixar livro-caixa bruto" na própria página Backup, ao lado do botão do cadastro (linha 67).

### N-3 · AMARELO · A faixa de atenção fica permanente depois da primeira gravação
Com o livro 100% íntegro, nada aparece. Depois do primeiro lançamento a faixa "ATENÇÃO — REVISÃO DO LIVRO-CAIXA" surge em todas as telas e permanece depois de recarregar, sem como dispensá-la, porque a existência de qualquer cópia por operação conta como risco (linha 214: `previous!==null||snapshots.length`). Isso contradiz o espírito de B-23 (sem falso alarme) e cria alarme permanente: o usuário aprende a ignorar a faixa, inclusive quando ela anunciar uma quarentena de verdade. Evidência: N-3 (sonda em `file://`).
**Ajuste sugerido:** na linha 214, tirar `previous`, `snapshots.length` e `ma62Protection` da condição que acende a faixa global; mostrar esses itens apenas como nota discreta na página do livro-caixa. Manter a faixa para bloqueio, linhas rejeitadas, quarentena ativa, legado e falha de proteção.

### Observações menores (VERDE com nota)
- No diálogo de correção, a mensagem sai com ponto duplicado ("Campos inconsistentes: banco.."). Cosmético; linha 388 (a mensagem de `ma62LegacyIssue` já termina em ponto e o texto acrescenta outro).
- O arquivamento da quarentena pede uma única confirmação; o texto avisa que o backup principal passa a omiti-la e que é preciso baixá-la antes. A revisão guarda o corpo original dentro da própria revisão (para detectar alteração posterior), o que duplica o espaço dessa quarentena. Aceitável, mas entra na conta de N-1.

---

## 4. Preservação de dados, compatibilidade, backups e demais módulos

- **Preservação:** em todos os cenários de recusa (sem espaço, falha injetada no livro principal, leitura de conferência divergente, arquivo externo errado, aba desatualizada, restauração recusada), o livro permaneceu **byte a byte idêntico** ao semeado e a tela voltou ao estado gravado. O app nunca alterou quarentenas nem a `-prev`, nem depois de restaurar um backup (B-79). Quando eu mesmo adulterei uma quarentena já revisada, o risco foi reativado e o backup voltou a ser recusado (C-18).
- **Isolamento:** adicionar lançamento, arquivar quarentena, backup, cópia bruta, restauração e `localStorage.clear()` não alteraram nenhuma das 6 chaves reais sentinelas nem criaram chave fora do prefixo (C-95).
- **Compatibilidade com registros antigos:** 12 variantes de linhas antigas continuam visíveis (12 de 12, sem quarentena indevida) e os totais são iguais aos da 6.1 DEV para as mesmas linhas, agora **incluindo** o ID numérico. Linhas realmente ilegíveis (10 variantes) vão à quarentena. HTML malicioso em campos antigos não executa em nenhuma das 18 telas (XSS 0).
- **Backups:** o backup principal mantém exatamente os 6 campos do formato v2; é restaurável nesta mesma versão (C-04) e na **6.1 DEV** (B-91 e B-91b, incluindo o arquivo "QUARENTENAS-SEPARADAS"). A 6.1 DEV também lê e grava sobre um livro com legado e ID numérico sem apagar nenhuma das chaves novas (B-90). Resolve, no nível da 6.1 DEV, a pendência "6.1-NAVEGADOR-IDA-E-VOLTA" do Codex; a 6.1 original (2e9567df...) continua sem teste direto porque nunca me foi entregue (INT-38).
- **Restaurador estrito:** backups com ID numérico ou banco antigo são recusados sem alterar nada (C-90a, C-90b). É a pendência declarada da A5.
- **Módulos:** 18 telas abrem sem erro; Central Sanitária mantém 8 frentes e 42 subtópicos (13 de 13 testes); Academia, Laboratório, Exocad, simulador, pagamentos, evoluções (biblioteca de modelos), contabilidade e CSV contábil funcionam como antes; pagamento novo convive com os restaurados (B-122).
- **Desempenho:** com 12.000 linhas, gravar um lançamento leva 1,24 s (dev.2: 1,17 s) e a carga da página, 13 s (P0-4, inalterado). Sem regressão relevante.

---

## 5. O que parecia regressão e não era

Quando reexecutei a suíte da auditoria anterior contra a dev.3, alguns itens mudaram de cor. Investiguei cada um:

- **A1-05, A1-07, A1-10, A1-31, A1-47 e A1-60** exigiam que a `-prev` fosse criada ou trocada e que o limite de 900.000 existisse. A A1.2 mudou isso de propósito (AJ-14 e AJ-15). Os critérios são obsoletos, foram excluídos da contagem e a função equivalente é coberta por C-30 a C-35 e B-61.
- **A1-46** (linha inválida vinda da mesclagem vai à quarentena): falhou por temporização do meu roteiro, que lia antes de a página recarregar. Uma sonda corrigida em `file://` mostrou 4 linhas exibidas, 1 quarentena ativa e a faixa visível. Não é regressão.
- **B-32** do meu roteiro novo esperava R$ 117,00 por erro de conta meu (os valores de apoio somam 30,03); o app mostrou R$ 87,03, que é o correto.
- **B-57, B-58, B-11-a/b, B-77** falharam apenas por expressões regulares que procuravam o texto antigo ("BLOQUEADO", "1 arquivo(s)"); a substância foi verificada.
- **A1-45 e A1-48** continuam REPROVADOS como antes: são A4 e A5, respectivamente, e não foram tocados.

---

## 6. Pode encerrar a A1 e iniciar a A5?

**Resposta: sim, A1 pode ser encerrada como APROVADA COM RESSALVAS, e a A5 (Proteção de Backup e Restauração) pode ser iniciada quando você autorizar.** Não iniciei a A5 nem fiz qualquer correção.

Condições que recomendo:

1. **N-1, N-2 e N-3 entram como itens de entrada da A5** (ou, se você preferir fechar a A1 sem pendências, numa A1.3 mínima só com os três ajustes). N-2 e N-3 são ajustes pequenos; N-1 é uma decisão de política de retenção que dialoga com o desenho do backup da A5 (as cópias por operação passam a fazer parte do backup? por quanto tempo?).
2. **Não liberar para uso com dados reais enquanto N-1 estiver aberto.** Em uso real a cota seria atingida em semanas e o único alívio disponível hoje é arriscado.
3. Os {s['VERMELHO']} VERMELHOS pré-existentes seguem como escopo da A5 (P1-7b, A1-48, BKP-02) e da A2/A3 (P1-0). Isso é o que a A5 deve atacar primeiro, junto com a restauração de IDs numéricos e bancos antigos, a restauração fiel (B-123, que reinjeta 4 registros fictícios) e a proteção antes de restaurar.

Sugestão de autorização em uma linha: "autorizo a A5, com N-1, N-2 e N-3 como critérios de entrada", ou "autorizo uma A1.3 mínima para N-1, N-2 e N-3 e, depois, a A5".

---

## 7. Erros do meu método, corrigidos antes de registrar

- **Execução em diretório errado.** Uma cadeia de comandos minha foi iniciada fora da pasta de trabalho, e uma das duas frentes de testes rodou no lugar errado; ela não gravou resultados. Apaguei os arquivos soltos que deixou e conferi pelas datas que nenhum resultado da auditoria anterior foi sobrescrito.
- **`pkill` derrubou meu próprio shell** (código 144) e interrompeu uma sequência de suítes; refiz as que ficaram sem resultado (b9, b10, b12, b13, b14).
- **Biblioteca sem a função `rawStore`** nos roteiros c4 e c5: corrigido e reexecutado.
- **C-41 e C-42:** meu roteiro clicava no botão de confirmação antes de testar o arquivo errado, o que liberava a operação. Refeito como c2b; os resultados do c2 foram descartados.
- **B-32, C-80 e C-82:** erro de conta no primeiro; sobrecarga do meu auxiliar no segundo (medida correta em C-80b); no terceiro, a primeira versão reduzia o espaço livre a 200 caracteres, o que era artificial; refiz contando pagamentos reais.
- **C-91 e C-92:** corrida entre recarga e leitura e mensagens de diálogo truncadas pelo meu próprio auxiliar. Corrigidos.
- **Roteiros antigos que dependiam do ID como seletor** (`data-delete`, `data-row`): agora os botões usam a posição da linha; adaptei três roteiros (b1x, b3x, b5x) e descartei os critérios obsoletos listados acima.
- **t3.json copiado da rodada anterior** continha resultados antigos; reexecutei o roteiro (t3b) contra a dev.3 antes de usá-lo.
- Nenhum arquivo recebido foi alterado; o HTML da dev.3 ficou em cópia somente leitura. Nenhum dado real foi usado; só Chromium isolado e dados fictícios.

---

## Apêndice. Matriz completa

Contagem por grupo (aprovados / total): """+', '.join(f"{g}: {cnt(g)[1]}/{cnt(g)[0]}" for g in TIT)+"""

"""
for g in TIT:
    md+=f"\n### {TIT[g]}\n\n{table(g)}\n"
md+="""
---

## Arquivos de teste

`Suite-Testes-A1.2-Livro-Caixa.zip` contém os roteiros Playwright novos (`c1` a `c8`, `b1x`, `b3x`, `b5x`, `b6x`), as bibliotecas, os roteiros herdados que reexecutei, as sondas, os geradores da matriz e deste relatório, a matriz em JSON e um LEIA-ME. As fixtures são fictícias e pequenas; os backups gerados durante os testes (que podem conter dados fictícios do DEV) não estão incluídos. Para reproduzir: `DEV_FILE=<html> node cN.js` com `NODE_PATH` apontando para o Playwright; rodar no máximo duas frentes em paralelo.
"""
open(OUT,'w',encoding='utf-8').write(md)
print(len(md),'chars',OUT)
