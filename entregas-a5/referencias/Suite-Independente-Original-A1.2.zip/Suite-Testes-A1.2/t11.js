const L=require('./lib');
(async()=>{const b=await L.browser();const r=await L.openDev(b,{});const p=r.page;
 const info=await p.evaluate(async()=>{go('ma55-academy');const bt=[...document.querySelectorAll('#ma55-academy button')].find(x=>x.textContent.includes('Oficina visual'));bt.click();await new Promise(r=>setTimeout(r,300));
  const cards=document.querySelectorAll('#ma59-cards [data-piece]');cards[0]?.click();await new Promise(r=>setTimeout(r,400));
  const divs=document.querySelectorAll('div#ma59-docs');const btns=[...document.querySelectorAll('.ma59-docs button')].map(b=>b.dataset.doc+'|'+b.textContent.trim().slice(0,40));
  return {divs:divs.length,btns,workshopVisible:!document.getElementById('ma59-workshop').hidden}});
 console.log(JSON.stringify(info));
 const exo=p.locator('.ma59-docs button[data-doc="exocad"]');
 if(await exo.count()){const [pop]=await Promise.all([Promise.race([p.waitForEvent('popup',{timeout:6000}).then(x=>'popup:'+x.url().slice(0,40)),p.waitForEvent('download',{timeout:6000}).then(x=>'download:'+x.suggestedFilename())]).catch(e=>'nenhum evento'),exo.click()]);console.log('click exocad ->',pop)}
 await b.close();})();
