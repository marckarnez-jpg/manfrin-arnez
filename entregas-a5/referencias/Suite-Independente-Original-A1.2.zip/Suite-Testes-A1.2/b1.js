// B1: AJ-1 — backup geral
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
(async()=>{const b=await L.browser();let r,p,k;
 // B-01 íntegro
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),'ma-installment-rates-v1':JSON.stringify({5:3.1,10:5.2})}});p=r.page;
 let dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},8000);let t=await B.saveDl(dl,'bk_b01.json');let j=t&&JSON.parse(t);
 const ks=j?Object.keys(j).join(','):'';
 R('B-01','Backup com livro-caixa íntegro: gera arquivo v2 com os mesmos campos da 6.1',!!j&&j.format==='manfrin-arnez-backup'&&j.version===2&&ks==='format,version,createdAt,care,ledger,rateSettings'&&JSON.stringify(j.ledger)===JSON.stringify(ok3)&&j.rateSettings&&j.rateSettings['5']===3.1,`download=${!!dl}; campos=[${ks}]; lançamentos idênticos=${j&&JSON.stringify(j.ledger)===JSON.stringify(ok3)}; taxas=${j&&JSON.stringify(j.rateSettings)}; pacientes no backup=${j&&j.care&&j.care.patients&&j.care.patients.length}; msg="${(await B.bmsg(p)).slice(0,120)}"`,'VERMELHO');
 const careLen=j&&j.care.patients.length;
 // restauração do backup gerado em contexto novo
 await r.ctx.close();
 r=await L.openDev(b,{seed:{}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_b01.json');
 await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1500);
 k=await B.appKeys(p);const led=k['ma-ledger-v1']?JSON.parse(k['ma-ledger-v1']):null;
 R('B-02','Backup gerado na dev.2 é restaurável (ida e volta, só dados fictícios)',!!led&&JSON.stringify(led)===JSON.stringify(ok3)&&k['ma-installment-rates-v1']!==undefined,`lançamentos restaurados idênticos=${led&&JSON.stringify(led)===JSON.stringify(ok3)}; taxas=${k['ma-installment-rates-v1']}; msg="${(await B.bmsg(p)).slice(0,100)}"`,'VERMELHO');
 await r.ctx.close();
 // B-03 JSON truncado
 const RAW='[{"id":"Cora:X1","date":"2026-09-01","bank":"Cora","description":"x","amount":1000,"kind":"Receita"},{"id":"Cora:X2","date":';
 r=await L.openDev(b,{seed:{'ma-ledger-v1':RAW}});p=r.page;
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});k=await B.appKeys(p);let m=await B.bmsg(p);
 R('B-03','AJ-1: livro-caixa ilegível — o backup geral NÃO é gerado e o aviso é claro (antes saía com 0 lançamentos)',!dl&&/BLOQUEAD/i.test(m)&&k['ma-ledger-v1']===RAW,`arquivo gerado=${!!dl}; texto do livro intacto=${k['ma-ledger-v1']===RAW}; msg="${m.slice(0,230)}"`,'VERMELHO');
 const ai=await B.alertInfo(p);
 R('B-04','AJ-1: com livro ilegível o painel oferece a cópia bruta e ela é exata',await (async()=>{const d=await B.tryDownload(p,()=>{[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/original bruto/i.test(x.textContent)).click()});const tx=await B.saveDl(d,'raw_b04.json');return tx===RAW})(),`botões do aviso=${ai&&ai.btns.join(' | ')}`,'VERMELHO');
 await r.ctx.close();
 // B-05 quarentena (linha ilegível) + válidas
 const Q=JSON.stringify([...ok3,{foo:1}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':Q}});p=r.page;
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(p);
 R('B-05','AJ-1: livro com linha em quarentena — backup recusado com explicação',!dl&&/BLOQUEADO/i.test(m),`arquivo gerado=${!!dl}; msg="${m.slice(0,200)}"`,'VERMELHO');
 // grava algo, recarrega, tenta de novo
 await B.addRow(p,'novo normal','10');await p.reload();await B.reloadWait(p);
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(p);
 R('B-06','Bloqueio PERMANENTE: depois de gravar e recarregar, o backup continua recusado enquanto existir a chave de quarentena; não há botão para dispensá-la',!dl,`arquivo gerado=${!!dl}; msg="${m.slice(0,160)}". O app não oferece descartar/arquivar quarentena, então o backup do cadastro de pacientes fica indisponível por tempo indeterminado`,'VERMELHO',{lockout:true});
 const bt=await p.evaluate(()=>[...document.querySelectorAll('#ma62-ledger-alert button,#ma62-ledger-alert summary')].map(x=>x.textContent.trim()));
 R('B-07','Existe alguma saída dentro do app (descartar / marcar como revisada a quarentena)?',bt.some(x=>/descartar|arquivar|excluir|remover|revisad/i.test(x)),`controles no aviso: ${bt.join(' | ')}`,'AMARELO');
 await r.ctx.close();
 // B-08 registro legado (banco fora do padrão)
 const LEG=JSON.stringify([...ok3,{id:'Itau:1',date:'2026-09-09',bank:'Itau',description:'legado',amount:500,kind:'Receita'}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':LEG}});p=r.page;
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(p);
 R('B-08','AJ-1/AJ-3: registro legado (banco "Itau") — backup recusado (comportamento declarado)',!dl&&/BLOQUEADO/i.test(m),`arquivo=${!!dl}; msg="${m.slice(0,120)}"`,'AMARELO');
 // saída: excluir o registro legado pela UI
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 await p.evaluate(()=>{const b=[...document.querySelectorAll('#transactions [data-delete]')].find(x=>x.dataset.delete==='Itau:1');b.click()});await p.waitForTimeout(500);
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},6000);
 R('B-09','Para desbloquear o backup com registro legado, a única saída é EXCLUIR o lançamento (perda de dado financeiro para poder fazer backup)',!!dl,`após excluir o legado, backup gerado=${!!dl}. Alternativa de corrigir o banco pelo app: não existe (só categoria é editável)`,'AMARELO',{info:true});
 await r.ctx.close();
 // B-10 legado só na categoria: corrigir pela UI destrava?
 const LEG2=JSON.stringify([...ok3,{id:'Cora:Z',date:'2026-09-09',bank:'Cora',description:'categoria antiga',amount:700,kind:'Pix'}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':LEG2}});p=r.page;
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 const sel=await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row="Cora:Z"]');if(!s)return null;s.value='Receita';s.dispatchEvent(new Event('change',{bubbles:true}));return true});await p.waitForTimeout(500);
 k=await B.appKeys(p);const z=JSON.parse(k['ma-ledger-v1']).find(x=>x.id==='Cora:Z');
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},6000);
 R('B-10','Legado com categoria inválida: corrigir a categoria pela tela remove a marcação e libera o backup',!!z&&z.kind==='Receita'&&!!dl,`select encontrado=${!!sel}; kind gravado=${z&&z.kind}; backup após corrigir=${!!dl}; msg="${(await B.bmsg(p)).slice(0,100)}"`,'AMARELO');
 await r.ctx.close();
 // B-11 cadastro ilegível (readError)
 for(const [nm,val] of [['JSON inválido','{bad json'],['versão desconhecida','{"version":99,"patients":[{"id":"P1"}],"records":[],"notes":[]}']]){
  r=await L.openDev(b,{seed:{'ma-care-v2':val,'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
  dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(p);k=await B.appKeys(p);
  R('B-11-'+(nm[0]==='J'?'a':'b'),`Cadastro com ${nm}: backup geral não finge conter os pacientes; dado armazenado intacto`,!dl&&/BLOQUEADO/i.test(m)&&k['ma-care-v2']===val,`arquivo=${!!dl}; cadastro intacto=${k['ma-care-v2']===val}; msg="${m.slice(0,150)}"`,'VERMELHO');
  await r.ctx.close();}
 // B-12 duas abas (memória desatualizada)
 const ctx=await b.newContext({acceptDownloads:true});
 await ctx.addInitScript(({s,P})=>{try{if(!sessionStorage.getItem('__seeded')){sessionStorage.setItem('__seeded','1');for(const [k,v] of Object.entries(s))localStorage.setItem(P+k,v)}}catch(e){}},{s:{'ma-ledger-v1':JSON.stringify(ok3)},P:L.PREFIX});
 const mk=async()=>{const pg=await ctx.newPage();pg.on('dialog',d=>d.accept());await pg.goto(L.DEV,{timeout:240000});await pg.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return pg};
 const A=await mk(),Bp=await mk();
 await B.addRow(Bp,'da aba B','77');
 dl=await B.tryDownload(A,()=>{go('backup');document.getElementById('backup-save').click()});m=await B.bmsg(A);
 R('B-12','Duas abas: backup na aba desatualizada é recusado (não exporta lista antiga)',!dl&&/outra aba|recarregue/i.test(m),`arquivo=${!!dl}; msg="${m.slice(0,160)}"`,'AMARELO');
 await ctx.close();
 fs.writeFileSync('r_b1.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b1.json',JSON.stringify(L.results,null,1));process.exit(1)});
