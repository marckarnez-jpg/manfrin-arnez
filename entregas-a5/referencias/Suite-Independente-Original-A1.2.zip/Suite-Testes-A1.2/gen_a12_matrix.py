"""Monta a matriz da auditoria A1.2 a partir dos r_*.json / t*.json (somente leitura) e dos overrides documentados."""
import json,re,os
from collections import Counter
def load(f):
    try:
        j=json.load(open(f))
        return j if isinstance(j,list) else []
    except Exception:
        return []
R={}   # chave "arquivo:id" -> registro
FILES=['b1','c1','c2','c2b','c3','c4','c5','c7','b1x','b3x','b5x','b6x','b2','b4','b7','b8','b9','b10','b11','b13','b14','compat','s1','s2','s3','s4','s5b','s6','s7b']
for f in FILES:
    fn='r_'+f+'.json'
    if f in('compat',):fn='r_compat.json'
    if f.startswith('s'):fn='r_'+f+'.json'
    for x in load(fn):R[f+':'+x['id']]=x
for f in ['t1','t3','t4','t5','t6']:
    for x in load(f+'.json'):R['t:'+x['id']]=x
def sig(x):
    if x.get('sev'):return x['sev']
    r=x['resultado']
    if r=='APROVADO':return 'VERDE'
    if r=='NÃO TESTADO':return 'AMARELO'
    if x.get('vermelho'):return 'VERMELHO'
    return 'AMARELO'
# ----- registros descartados (critério obsoleto/duplicado) com a razão -----
DROP={
 'c2:C-41':'refeito como c2b:C-41 (meu roteiro clicava no botão de confirmação antes do teste do arquivo errado)',
 'c2:C-42':'refeito como c2b:C-42',
 'b1:B-06':'roteiro antigo com polaridade invertida (media o bloqueio permanente); substituído por c1:B-06','b1:B-07':'idem; substituído por c1:B-07','b8:B-100':'critério antigo; substituído por c1:B-100 (mesma verificação, tela correta)',
 'b9:B-79':'cenário literal (quarentena NÃO revisada) continua bloqueado por desenho; substituído por c1:B-79 (quarentena revisada)',
 'b11:B-118':'substituído por b13:B-118','b11:B-122':'substituído por b14:B-122',
 'b3x:B-36':'critério obsoleto: AJ-14 passou a proteger por cópia por operação (ver E)',
 'b4:B-58':'regex antigo; substituído por b7:B-58r',
 'b2:B-22':'substituído por b7:B-22r (a barra DEV cobre o topo da faixa; existe só na cópia DEV)',
 's2:A1-23':'superado desde a rodada 1/2 (B-04)','s2:A1-24':'superado (B-03/B-05, C-06)','s2:A1-25':'superado (B-20-*)',
 's1:A1-05':'critério obsoleto (AJ-14: -prev deixou de ser criada; ver C-30)','s1:A1-07':'critério obsoleto (AJ-14)','s1:A1-10':'critério obsoleto (AJ-14)',
 's3:A1-31':'critério obsoleto (AJ-14)','s4:A1-47':'critério obsoleto (AJ-14: -prev); restauração coberta por C-91, C-04 e B-02','s6:A1-60':'critério obsoleto (AJ-15 removeu o limite de 900.000); ver B-61 e C-80',
}
# ----- overrides: (res,sev,nota) -----
OV={
 'c3:B-32':('APROVADO','VERDE','Critério do meu script tinha erro de conta (esperava R$ 117,00; os valores de mkRows somam 30,03). Mostrado: R$ 87,03 = 30,03 + 50,00 (ID numérico) + 7,00 (ID texto), o resultado correto sobre os valores originais.'),
 'c3:C-80':('APROVADO','VERDE','O tempo de 12,5 s era sobrecarga do meu auxiliar (render + espera). Medida correta em C-80b: 1.244 ms (dev.3) contra 1.172 ms (dev.2), sem regressão.'),
 'c3:C-57':('REPROVADO','AMARELO','ACHADO N-2: com um livro só com ID numérico (válido) não aparece a faixa global nem o botão "Baixar original bruto"; a recusa manda "usar a cópia BRUTA" que não está disponível. Confirmado por sonda isolada (A faixa só aparece com risco: bloqueio, rejeitadas, quarentena, legado, -prev, cópia por operação ou proteção).'),
 'c5:C-81-500':('REPROVADO','AMARELO','ACHADO N-1 (retenção sem limpeza esgota a cota; ver relatório).'),
 'c5:C-81-1500':('REPROVADO','AMARELO','ACHADO N-1.'),
 'c7:C-82':('REPROVADO','AMARELO','ACHADO N-1: depois da recusa por cota ainda couberam 82 pagamentos; em seguida os pagamentos também são recusados ("libere espaço no navegador"), sem perda de dado.'),
 'c7:C-83':('REPROVADO','AMARELO','ACHADO N-1: não há botão de apagar/limpar cópias antigas; o único alívio é limpar dados do navegador (arriscado).'),
 'b8:B-102':('APROVADO','VERDE','Critério "inclui as linhas OU avisa": a confirmação da mesclagem agora declara que a cópia NÃO inclui quarentenas (ver C-92). A omissão continua; as quarentenas permanecem intactas no armazenamento (C-93).'),
 'b3x:B-31':('APROVADO','VERDE','O título e o critério vêm da dev.2 (onde o id numérico ia para a quarentena). Na dev.3 a linha de id numérico fica VISÍVEL e sem quarentena: AJ-16 resolvido (ver B-30: 12 de 12 variantes visíveis).'),
 'b3x:B-32':('APROVADO','VERDE','Totais da Conciliação para as mesmas 12 variantes: iguais aos da 6.1 DEV (R$ 285,51), agora INCLUINDO a linha de id numérico.'),
 'b9:B-77':('APROVADO','VERDE','Critério textual obsoleto (a mensagem de falha mudou para "Gravação bloqueada..."); substância verificada: depois da exclusão bem-sucedida a mensagem antiga some ("msg após excluir" vazio).'),
 'b11:B-119':('REPROVADO','AMARELO','Limitação declarada (A5): a recusa é segura (nada é alterado, C-90b), mas backups antigos com bancos fora do padrão ainda não podem ser restaurados.'),
 'b1x:B-11-a':('APROVADO','VERDE','Regex do meu critério esperava a palavra "BLOQUEADO"; a mensagem agora diz "RECUSADO". Substância: nenhum arquivo gerado e cadastro intacto.'),
 'b1x:B-11-b':('APROVADO','VERDE','Idem B-11-a (versão desconhecida 99).'),
 'b4:B-57':('APROVADO','VERDE','Regex do meu critério esperava "1 arquivo(s)"; o texto agora é "1 quarentena(s) ativa(s)". Substância: listada sem quebrar, 0 erros.'),
 'b7:B-58r':('APROVADO','VERDE','Faixa mostra "1 quarentena(s) ativa(s)" (só a do sandbox); sentinelas reais intactas=true, 6 chaves (regex antigo procurava outro texto). Reafirmado por C-95.'),
 'b5x:B-75':('APROVADO','VERDE','Sem regressão: 6.500 linhas gravam em 869/818 ms na dev.3 (dev.2 843/1077 ms; dev.1 770/1059 ms; 6.1 777/749 ms). O limite de 500 ms do meu script nunca foi atingido por nenhuma versão, inclusive a 6.1.'),
 's1:A1-08':('APROVADO','VERDE','Faixa continua visível depois de recarregar (AJ-5 corrigido na dev.2); critério original era da dev.1.'),
 's4:A1-46':('APROVADO','VERDE','Falha era de temporização do meu roteiro (leitura antes de a página recarregar). Sonda corrigida em file://: depois do recarregamento, 4 linhas exibidas, 1 quarentena ativa e faixa visível (linha inválida vinda da mesclagem foi para a quarentena).'),
 's4:A1-45':('REPROVADO','AMARELO','A4 (inalterado): a tela só mostra a mesclagem depois de recarregar.'),
 's4:A1-48':('REPROVADO','VERMELHO','A5 (inalterado): restaurar e gravar descarta o estado anterior à restauração.'),
}
PRE={'P1-0','P1-7b','P0-4','PERF-01','BKP-02','BKP-02b','BKP-05','BKP-08','P2-2','P2-3','SEC-01','P0-2','P1-7a','ISO-05'}
TNOTE={'PERF-01':'P0-4 (inalterado): carga ~12-13 s em Chromium headless, igual à dev.2.','P0-4':'P0-4 (inalterado).','ISO-05':'Limite documentado do isolamento por prefixo (mesma origem file://); o próprio Codex declara o mesmo.','P1-7b':'A5 (inalterado).','P1-0':'Fora do escopo A1.2; não corrigido (declarado pelo Codex).','BKP-02':'A5 (inalterado): o backup principal declara que não cobre Academia, checklists e cópias.','P0-2':'Melhoria já vista na dev.2: o backup recusa em vez de exportar o cadastro embutido; agora existe também a cópia BRUTA do cadastro (C-09).'}
rows=[]
def add(g,i,t,res,sg,ev,orig=''):
    ev=re.sub(r'CPF \d{3}\.\d{3}\.\d{3}-\d{2}','CPF fictício',str(ev));ev=re.sub(r'\(00\) 00000-\d{4}','(telefone fictício)',ev);ev=re.sub(r'\d{3}\.\d{3}\.\d{3}-\d{2}','CPF fictício',ev)
    rows.append([g,i,t,res,sg,ev,orig])
# ---------- A. estáticos e de documento ----------
S=[
('INT-31','Hash e tamanho do HTML dev.3 conferem com SHA256SUMS, com o relatório do Codex e com resultados.json','APROVADO','VERDE','SHA-256 e4e4f49c...bcc3f; 4.077.003 bytes (verificação estática).'),
('INT-32','dev.2 usada como base: hash f11dbe0e...756751 confere com o declarado pelo Codex e com a que auditei','APROVADO','VERDE','Cópia da dev.2 da rodada anterior, não modificada (verificação estática).'),
('INT-33','Sintaxe: 23/23 blocos de script da dev.3 passam em node --check','APROVADO','VERDE','Verificação estática independente.'),
('INT-34','O trecho de "function syncInfo(){" até o fim do arquivo é idêntico ao da dev.2 (módulos, modelos clínicos, Academia, Laboratório, Central Sanitária)','APROVADO','VERDE','Comparação de strings, verificação estática. O que mudou fica nas linhas 1-618 (antes do syncInfo).'),
('INT-35','O diff do Codex aplicado com patch sobre uma cópia da dev.2 reproduz a dev.3 byte a byte (cmp idêntico, mesmo SHA-256)','APROVADO','VERDE','Não há mudança fora do diff entregue; li o diff inteiro (32 trechos). Verificação estática.'),
('INT-36','resultados.json: 100 verificações = 97 APROVADO, 0 REPROVADO, 3 PENDENTE; as 3 pendências são A5/6.1/restauração fiel','APROVADO','VERDE','Conferência do documento (não é execução). 29 das 97 aprovações são verificações auxiliares repetidas (11 CONSOLE-n, 11 ISOLAMENTO-n, 7 BACKUP-RECUSADO-n), contadas por mim no resultados.json.'),
('INT-37','Método do Codex: Chromium real, localStorage nativo, HTTP loopback; "file://" bloqueado no ambiente dele','APROVADO','AMARELO','Limite do ambiente do Codex, declarado. Eu repeti em file://, que é como o HTML é aberto de verdade. Não executei os scripts do Codex (li-os como dados).'),
('INT-38','Cópia 6.1 original (2e9567df...) nunca me foi entregue; usei a 6.1 DEV (ec3714a3...ccc8f3) como leitor 6.1','NÃO TESTADO','AMARELO','Compatibilidade com o HTML 6.1 original segue sem execução direta; a 6.1 DEV é a mesma base de código com banner e isolamento de DEV.'),
]
for s in S:add('A',*s,orig='estático')
# ---------- grupos ----------
G={}
def grp(g,ids):
    for i in ids:G[i]=g
grp('B',['C-01','C-02','C-03','C-04','C-05','B-100','C-06','C-07','C-08','C-09','C-10','C-11','B-12','B-03','B-04','B-05','B-01','B-02','B-08'])
grp('C',['C-12','C-13','B-07','B-06','C-15','C-16','C-17','C-18','C-19','C-20','C-21','B-79','C-92','C-93','C-94','B-102','B-101'])
grp('D',['C-38','C-39','B-67','C-40','C-41','C-42','C-42b'])
grp('E',['C-30','B-69','C-31','C-32','C-33','C-34','C-35'])
grp('F',['B-61','C-36','C-37','C-43','C-44','C-45','C-46','C-80','C-80b','B-75','B-76'])
grp('G',['B-30','B-31','B-32','B-34','B-35','B-38','B-39','B-40','B-41','B-42','C-51','C-52','C-53','C-54','C-55','C-56','C-57','C-58'])
grp('H',['B-09','B-10','B-37','B-11-a','B-11-b','C-60','C-61','C-62','C-63','C-64','C-65','C-66','C-68','C-69','C-70','C-71','C-72','C-73'])
grp('I',['C-81-500','C-81-1500','C-82','C-83'])
grp('J',['C-90a','C-90b','C-91','B-90','B-91','B-91b','B-110','B-111','B-112','B-113','B-114','B-115','B-116','B-117','B-118','B-119','B-120','B-121','B-122','B-123','B-80','B-81','B-78','B-103','B-77','B-71','B-72','B-73'])
grp('K',['C-95','C-96'])
# ---------- adicionar registros ----------
order=[]
for k,x in R.items():
    if k in DROP:continue
    f,i=k.split(':',1)
    res=x['resultado'];sg=sig(x);ev=x['evidencia'];t=x['titulo']
    ik=i
    if f=='b3x' and i in('B-31','B-32','B-37'):i=i+'-12v'
    if k in OV:
        res,sg,note=OV[k];ev=ev+' — '+note
    if i.startswith('C-67-'):g='H'
    elif ik in G and f in('c1','c2','c2b','c3','c4','c5','c7','b1','b1x','b3x','b5x','b6x','b8','b9','b10','b11','b13','b14'):g=G[ik]
    elif f in('b2','b4','b7'):g='L'
    elif f.startswith('s') or f=='compat':g='M'
    elif f=='t':g='N' if i in PRE else 'K'
    else:g=G.get(i,'L')
    if res=='AMARELO':res='APROVADO'
    if f=='b1x' and i in('B-10','B-11-a','B-11-b','B-12'):g=G.get(i,'H')
    # nomes de ids duplicados entre arquivos recebem sufixo da origem apenas se necessário
    if f=='t' and i in TNOTE:ev+=' — '+TNOTE[i]
    add(g,i,t,res,sg,ev,f)
# C-80b (medição de desempenho comparativa; script c6)
add('F','C-80b','Desempenho com 12.000 linhas (mesmo roteiro em dev.2 e dev.3): gravar 1 lançamento / mudar 1 categoria / renderizar o livro','APROVADO','VERDE','dev.2: 1.172 / 1.971 / 927 ms; dev.3: 1.244 / 2.270 / 1.104 ms; carga da página 13,1 s e 13,4 s (P0-4, inalterado). Sem regressão relevante (c6).','c6')
add('I','N-3','Livro 100% íntegro: depois da PRIMEIRA gravação a faixa global "ATENÇÃO — REVISÃO DO LIVRO-CAIXA" aparece em todas as telas e permanece depois de recarregar (a existência de cópia por operação conta como risco)','REPROVADO','AMARELO','Sonda em file://: antes de gravar = sem faixa; depois de 1 lançamento = faixa em início, painel, contabilidade, livro e backup; após recarregar a faixa continua ("1 cópia(s) local(is) de operações, fora do backup principal"). Não há como dispensá-la. Risco: alarme permanente, o usuário passa a ignorar avisos reais.','sonda')
# pré-existentes
for k,t in [('MA61-1','Central Sanitária: dado de versão desconhecida preservado'),('MA61-1b','Central Sanitária: importação com versão desconhecida'),('P1-6','crypto.randomUUID em contexto inseguro (http em IP de rede)'),('P1-3','Duas abas fora do livro-caixa (cadastro e demais módulos)')]:
    add('N',k,t,'NÃO TESTADO','AMARELO','Código idêntico ao da dev.2 (INT-34 e diff); defeito reproduzido em etapas anteriores e não tocado nesta entrega. Fora do escopo A1.2 (declarado pelo Codex).','estático')
# normalização final
for r in rows:
    if r[1] in('BKP-05','SEC-01') and r[3]=='REPROVADO':
        r[3]='NÃO TESTADO';r[4]='AMARELO';r[5]='Script antigo desta verificação tem defeito conhecido (etapas anteriores); resultado ignorado. Código inalterado.'
json.dump(rows,open('a12_matrix.json','w'),ensure_ascii=False,indent=1)
c=Counter(r[3] for r in rows);s=Counter(r[4] for r in rows)
print(len(rows),dict(c),dict(s));print(dict(Counter(r[0] for r in rows)))
for r in rows:
    if r[3]!='APROVADO' or r[4]!='VERDE':print(r[0],r[1],r[3],r[4],r[2][:90])
