// S6: desempenho de leitura e dobro de espaço pela cópia prev
const H=require('./a1lib');const {L,row,fs}=H;
const big=n=>{const a=[];for(let i=0;i<n;i++){const d=String(1+(i%28)).padStart(2,'0');a.push({id:'Cora:B'+i,date:'2026-0'+(1+(i%9))+'-'+d,bank:i%2?'Cora':'Sicredi',description:'Lancamento ficticio numero '+i,amount:(i%2?1:-1)*(100+i),kind:i%2?'Receita':'Despesa'})}return a};
(async()=>{const b=await L.browser();
 for(const n of [12000,17000]){
  const RAW=JSON.stringify(big(n));
  const r=await L.openDev(b,{seed:{'ma-ledger-v1':RAW}});const p=r.page;
  const t=await p.evaluate(()=>{const raw=localStorage.getItem('ma-ledger-v1');const t0=performance.now();const l=JSON.parse(raw);let ok=0;for(const x of l){try{validRow(x);ok++}catch(e){}}return {ms:Math.round(performance.now()-t0),ok,len:raw.length}});
  const m=await H.addRow(p,'sob volume grande');
  const k=await H.appKeys(p);const main=JSON.parse(k['ma-ledger-v1']);
  const wrote=main.length===n+1;const intact=k['ma-ledger-v1']===RAW||wrote;
  L.record('A1-6'+(n===12000?'0':'1'),`Volume: ${n} lançamentos (${t.len} caracteres): leitura, validação e gravação com cópia prev`,
   (n===12000?(wrote&&k['ma-ledger-v1-prev']===RAW):(intact))?'APROVADO':'REPROVADO',
   `validação em memória de ${n} linhas=${t.ms} ms (${t.ok} válidas); carga total da página=${r.loadMs} ms; novo lançamento gravado=${wrote}; prev presente=${'ma-ledger-v1-prev' in k}; mensagem="${m.slice(0,100)}"; ${n===17000?'o dobro de espaço da cópia prev somado ao cadastro estoura a cota: a gravação foi recusada sem perder dados='+(!wrote&&k['ma-ledger-v1']===RAW):''}`,{amarelo:n===17000&&!wrote});
  await r.ctx.close();}
 fs.writeFileSync('r_s6.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s6.json',JSON.stringify(L.results,null,1));process.exit(1)});
