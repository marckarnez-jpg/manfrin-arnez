// C1: A1.2 — AJ-11 (backup/recusa/verificação) e AJ-12 (quarentena revisada/arquivada), B-06 B-07 B-79 B-100
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
const QKEY='ma-ledger-v1-rejeitados-20260101000000';
const QBODY=JSON.stringify({rows:[{foo:1,x:'LINHA-FICTICIA-REJEITADA'}],createdAt:'2026-01-01T00:00:00Z'});
const REV='ma-ledger-v1-quarantine-review:';
const bk=p=>B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},8000);
const acct=p=>B.tryDownload(p,()=>{document.getElementById('ma53-account-backup').click()},8000);
const stat=p=>p.evaluate(()=>document.getElementById('ma53-recovery-status')?.textContent||'');
const archiveBtn=p=>p.evaluate(()=>{go('ledger');const b=[...document.querySelectorAll('#ma62-ledger-alert button')].find(x=>/Revisar e arquivar/i.test(x.textContent));if(!b)return false;b.click();return true});
(async()=>{const b=await L.browser();let r,p,k,dl,t,j,m;
 // ---------- C-01 backup íntegro + ida e volta ----------
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),'ma-installment-rates-v1':JSON.stringify({5:3.1})}});p=r.page;
 dl=await bk(p);t=await B.saveDl(dl,'bk_c01.json');j=t&&JSON.parse(t);m=await B.bmsg(p);
 const nm=dl&&dl.suggestedFilename();
 const ks=j?Object.keys(j).join(','):'';
 R('C-01','AJ-11: backup principal íntegro — v2 com exatamente os 6 campos 6.1, lançamentos idênticos, mensagem diz "solicitado/não verificado"',!!j&&j.version===2&&j.format==='manfrin-arnez-backup'&&ks==='format,version,createdAt,care,ledger,rateSettings'&&JSON.stringify(j.ledger)===JSON.stringify(ok3)&&/NÃO verificado/i.test(m),`arquivo=${nm}; campos=[${ks}]; ledger idêntico=${j&&JSON.stringify(j.ledger)===JSON.stringify(ok3)}; msg="${m.slice(0,170)}"`,'VERMELHO');
 // verificação do arquivo
 await p.setInputFiles('#ma62-verify-backup','bk_c01.json');await p.waitForTimeout(600);let vm=await B.bmsg(p);
 R('C-02','AJ-11: "Verificar arquivo baixado" aceita o arquivo idêntico ao último gerado',/VERIFICADO/.test(vm)&&!/NÃO VERIFICADO/.test(vm),`msg="${vm.slice(0,160)}"`,'AMARELO');
 fs.writeFileSync('c02_wrong.json',t.replace('"ledger"','"ledger" '));
 await p.setInputFiles('#ma62-verify-backup','c02_wrong.json');await p.waitForTimeout(600);vm=await B.bmsg(p);
 R('C-03','AJ-11: arquivo ligeiramente diferente (1 espaço) é rejeitado na verificação',/NÃO VERIFICADO/.test(vm),`msg="${vm.slice(0,160)}"`,'AMARELO');
 await r.ctx.close();
 // restauração do backup gerado
 r=await L.openDev(b,{seed:{}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_c01.json');
 await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1500);
 k=await B.appKeys(p);const led=k['ma-ledger-v1']?JSON.parse(k['ma-ledger-v1']):null;
 R('C-04','Backup principal da dev.3 é restaurável (ida e volta) e as taxas voltam',!!led&&JSON.stringify(led)===JSON.stringify(ok3)&&k['ma-installment-rates-v1']!==undefined,`ledger idêntico=${led&&JSON.stringify(led)===JSON.stringify(ok3)}; taxas=${k['ma-installment-rates-v1']}`,'VERMELHO');
 await r.ctx.close();
 // verificação sem pedir backup antes
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#ma62-verify-backup','bk_c01.json');await p.waitForTimeout(600);vm=await B.bmsg(p);
 R('C-05','AJ-11: verificar sem ter solicitado backup nesta sessão não declara sucesso',/NÃO VERIFICADO/.test(vm),`msg="${vm.slice(0,140)}"`,'AMARELO');
 await r.ctx.close();

 // ---------- B-100 / AJ-11: botão da Contabilidade ----------
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),[QKEY]:QBODY}});p=r.page;
 await p.evaluate(()=>go('accounting'));
 const has=await p.evaluate(()=>!!document.getElementById('ma53-account-backup'));
 dl=await acct(p);m=await stat(p);
 R('B-100','AJ-11: Contabilidade com quarentena ativa — nenhum download e a tela da Contabilidade NÃO diz que o backup foi solicitado',has&&!dl&&/RECUSAD/i.test(m)&&!/Backup deste arquivo solicitado/i.test(m),`botão presente=${has}; download=${!!dl}; status contabilidade="${m.slice(0,200)}"`,'VERMELHO');
 dl=await bk(p);m=await B.bmsg(p);
 R('C-06','AJ-11: página Backup com quarentena ativa — recusa sem download',!dl&&/RECUSAD/i.test(m),`download=${!!dl}; msg="${m.slice(0,160)}"`,'VERMELHO');
 await r.ctx.close();
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3)}});p=r.page;
 await p.evaluate(()=>go('accounting'));dl=await acct(p);m=await stat(p);t=await B.saveDl(dl,'bk_c07.json');
 R('C-07','AJ-11: Contabilidade com livro íntegro — download efetivo e status "solicitado/não verificado"',!!dl&&!!t&&/SOLICITADO/i.test(m)&&/NÃO verificado/i.test(m)&&JSON.parse(t).version===2,`download=${!!dl}; arquivo=${dl&&dl.suggestedFilename()}; status="${m.slice(0,170)}"`,'AMARELO');
 await r.ctx.close();

 // ---------- cadastro ilegível ----------
 const BADCARE='{bad json "FICTICIO"';
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),'ma-care-v2':BADCARE}});p=r.page;
 k=await B.appKeys(p);const careNow=k['ma-care-v2'];
 dl=await bk(p);m=await B.bmsg(p);const dl2=await acct(p);const m2=await stat(p);
 R('C-08','Cadastro ilegível: backup principal recusado nas duas rotas (sem arquivo substitutivo)',!dl&&!dl2&&/RECUSAD/i.test(m)&&/RECUSAD/i.test(m2),`pág.Backup="${m.slice(0,110)}"; Contab="${m2.slice(0,110)}"; downloads=${!!dl}/${!!dl2}`,'VERMELHO');
 let rawDl=await B.tryDownload(p,()=>{go('backup');document.getElementById('ma62-export-care-raw').click()},6000);const rawT=await B.saveDl(rawDl,'raw_c09.json');
 k=await B.appKeys(p);
 R('C-09','AJ-12b: cópia BRUTA do cadastro ilegível é exata (bytes) e o cadastro não foi alterado',rawT===careNow&&k['ma-care-v2']===careNow&&/BRUTO-NAO-RESTAURAR/.test(rawDl?rawDl.suggestedFilename():''),`bytes idênticos=${rawT===careNow}; nome=${rawDl&&rawDl.suggestedFilename()}; chave intacta=${k['ma-care-v2']===careNow}`,'VERMELHO');
 const rawDl2=await B.tryDownload(p,()=>{document.getElementById('ma62-account-care-raw').click()},6000);const rawT2=await B.saveDl(rawDl2,'raw_c09b.json');
 R('C-10','AJ-12b: o botão da Contabilidade também baixa a cópia BRUTA exata',rawT2===careNow,`bytes idênticos=${rawT2===careNow}`,'AMARELO');
 await r.ctx.close();
 // cópia bruta com cadastro íntegro / cadastro ausente
 r=await L.openDev(b,{seed:{}});p=r.page;
 k=await B.appKeys(p);const careAbsent=!('ma-care-v2' in k);
 await p.evaluate(()=>{localStorage.removeItem('ma-care-v2')});
 rawDl=await B.tryDownload(p,()=>{go('backup');document.getElementById('ma62-export-care-raw').click()},4000);const mm=await p.evaluate(()=>document.getElementById('ma62-care-raw-message').textContent);
 R('C-11','AJ-12b: sem chave de cadastro persistida a cópia bruta é recusada (não inventa dados)',!rawDl&&/recusada/i.test(mm),`download=${!!rawDl}; msg="${mm.slice(0,140)}"`,'AMARELO');
 await r.ctx.close();

 // ---------- AJ-12 quarentena ----------
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),[QKEY]:QBODY}});p=r.page;
 let ai=await B.alertInfo(p);await p.evaluate(()=>go('ledger'));ai=await B.alertInfo(p);
 R('C-12','AJ-12: quarentena aparece como ATIVA com botão "Revisar e arquivar (sem recuperar)" e download',!!ai&&/ATIVA/i.test(ai.text)&&ai.btns.some(x=>/Revisar e arquivar/i.test(x))&&ai.btns.some(x=>/^Baixar/i.test(x)),`faixa="${ai&&ai.text.slice(0,250)}"; botões=${ai&&ai.btns.join(' | ')}`,'AMARELO');
 // cancelar o diálogo: nada muda
 r.page.removeAllListeners('dialog');let dlgMsg='';r.page.on('dialog',d=>{dlgMsg=d.message();d.dismiss()});
 await archiveBtn(p);await p.waitForTimeout(500);k=await B.appKeys(p);
 R('C-13','AJ-12: cancelar o diálogo de arquivamento não cria revisão nem altera a quarentena',k[QKEY]===QBODY&&!(REV+QKEY in k),`quarentena intacta=${k[QKEY]===QBODY}; revisão criada=${(REV+QKEY) in k}; diálogo="${dlgMsg.slice(0,120)}"`,'VERMELHO');
 // aceitar
 r.page.removeAllListeners('dialog');r.page.on('dialog',d=>d.accept());
 await archiveBtn(p);await p.waitForTimeout(600);k=await B.appKeys(p);ai=await B.alertInfo(p);
 const rev=k[REV+QKEY]?JSON.parse(k[REV+QKEY]):null;
 R('B-07','AJ-12: existe saída dentro do app — arquivar quarentena como revisada; chave original byte-idêntica',k[QKEY]===QBODY&&!!rev&&rev.originalBody===QBODY&&rev.acknowledged===true,`quarentena intacta=${k[QKEY]===QBODY}; revisão=${rev?Object.keys(rev).join(','):'—'}; faixa="${ai&&ai.text.slice(0,220)}"`,'VERMELHO');
 await p.reload();await B.reloadWait(p);
 dl=await bk(p);t=await B.saveDl(dl,'bk_c14.json');m=await B.bmsg(p);j=t&&JSON.parse(t);
 R('B-06','Backup deixa de ficar bloqueado para sempre: após arquivar + recarregar, o backup principal é gerado, nomeado "QUARENTENAS-SEPARADAS", com aviso de omissão',!!dl&&/QUARENTENAS-SEPARADAS/.test(dl.suggestedFilename())&&/OMITIDA/i.test(m)&&j&&JSON.stringify(j.ledger)===JSON.stringify(ok3),`arquivo=${dl&&dl.suggestedFilename()}; msg="${m.slice(0,230)}"; ledger igual=${j&&JSON.stringify(j.ledger)===JSON.stringify(ok3)}`,'AMARELO');
 R('C-15','AJ-12: o backup principal com quarentena arquivada NÃO contém as linhas da quarentena (omissão declarada) e mantém os 6 campos',!!t&&!/LINHA-FICTICIA-REJEITADA/.test(t)&&Object.keys(j).join(',')==='format,version,createdAt,care,ledger,rateSettings',`contém quarentena=${/LINHA-FICTICIA-REJEITADA/.test(t||'')}; campos=${j&&Object.keys(j).join(',')}`,'AMARELO');
 // quarentena arquivada ainda baixável e exata
 const qd=await B.tryDownload(p,()=>{go('ledger');const x=[...document.querySelectorAll('#ma62-ledger-alert button')].find(y=>/^Baixar$/i.test(y.textContent.trim()));x.click()},6000);const qt=await B.saveDl(qd,'q_c16.json');
 ai=await B.alertInfo(p);
 R('C-16','AJ-12: quarentena arquivada continua listada como ARQUIVADA, baixável e idêntica ao original',qt===QBODY&&/ARQUIVADA/i.test(ai.text),`download exato=${qt===QBODY}; faixa="${ai.text.slice(0,200)}"`,'AMARELO');
 // Acct button com arquivada
 dl=await acct(p);m=await stat(p);
 R('C-17','AJ-12/AJ-11: Contabilidade com quarentena arquivada gera backup e o status declara omissão',!!dl&&/OMITIDA|arquivada/i.test(m),`download=${!!dl}; status="${m.slice(0,200)}"`,'AMARELO');
 // adulterar a quarentena depois do arquivamento
 await p.evaluate(([k,v])=>localStorage.setItem(k,v),[QKEY,QBODY.replace('FICTICIA','FICTICIA-ALTERADA')]);
 await p.reload();await B.reloadWait(p);dl=await bk(p);m=await B.bmsg(p);ai=await B.alertInfo(p);
 R('C-18','AJ-12: quarentena alterada depois de revisada reativa o risco (backup recusado, estado ATIVA)',!dl&&/RECUSAD/i.test(m)&&/ATIVA/i.test(ai.text),`download=${!!dl}; msg="${m.slice(0,100)}"; faixa="${ai.text.slice(0,160)}"`,'VERMELHO');
 await r.ctx.close();

 // linhas atualmente rejeitadas continuam bloqueando mesmo com quarentena antiga arquivada
 const withBad=JSON.stringify([...ok3,{foo:2,x:'LINHA-NOVA-RUIM'}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':withBad,[QKEY]:QBODY}});p=r.page;
 await archiveBtn(p);await p.waitForTimeout(400);await p.reload();await B.reloadWait(p);
 dl=await bk(p);m=await B.bmsg(p);k=await B.appKeys(p);const qk=Object.keys(k).filter(x=>x.startsWith('ma-ledger-v1-rejeitados-'));
 R('C-19','AJ-12: linha rejeitada recente (nova quarentena) continua bloqueando o backup; arquivar a antiga não libera',!dl&&/RECUSAD/i.test(m)&&qk.length>=2,`download=${!!dl}; quarentenas=${qk.length}; msg="${m.slice(0,120)}"`,'VERMELHO');
 await r.ctx.close();

 // quarentena de conteúdo não-JSON arquivada
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),[QKEY]:'TEXTO LIVRE {{ FICTICIO'}});p=r.page;
 await archiveBtn(p);await p.waitForTimeout(500);k=await B.appKeys(p);
 R('C-20','AJ-12: quarentena de conteúdo não reconhecido também pode ser revisada, sem alterar bytes',k[QKEY]==='TEXTO LIVRE {{ FICTICIO'&&(REV+QKEY) in k,`bytes iguais=${k[QKEY]==='TEXTO LIVRE {{ FICTICIO'}; revisão=${(REV+QKEY) in k}`,'AMARELO');
 await r.ctx.close();

 // arquivar sem espaço
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),[QKEY]:QBODY}});p=r.page;
 await B.saturate(p);await archiveBtn(p);await p.waitForTimeout(500);k=await B.appKeys(p);ai=await B.alertInfo(p);
 R('C-21','AJ-12: arquivar sem espaço — recusa explícita, quarentena intacta, risco continua ativo',k[QKEY]===QBODY&&!((REV+QKEY) in k)&&/recusado/i.test(ai.text),`faixa="${ai.text.slice(0,200)}"`,'AMARELO');
 await r.ctx.close();

 // B-79: restaurar backup limpo preserva quarentena arquivada e revisão; backup volta a funcionar
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),[QKEY]:QBODY}});p=r.page;
 await archiveBtn(p);await p.waitForTimeout(500);
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_c01.json');
 await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1800);
 k=await B.appKeys(p);const stillQ=k[QKEY]===QBODY,stillRev=(REV+QKEY) in k;
 dl=await bk(p);m=await B.bmsg(p);
 R('B-79','Após restaurar um backup limpo, quarentena e revisão arquivadas permanecem e o backup principal funciona de novo',stillQ&&stillRev&&!!dl,`quarentena=${stillQ}; revisão=${stillRev}; backup=${!!dl}; msg="${m.slice(0,140)}"`,'VERMELHO');
 await r.ctx.close();
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c1.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c1.json',JSON.stringify(L.results,null,1)));
