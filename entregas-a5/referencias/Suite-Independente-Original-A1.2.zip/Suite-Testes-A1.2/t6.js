// T6: compatibilidade de backups, P2-x, cota saturada, contexto inseguro
const L=require('./lib');const fs=require('fs');const {spawn}=require('child_process');
const read=(p,k)=>p.evaluate(k=>localStorage.getItem(k),k);
const row=(i,x={})=>({id:'Cora:T'+i,date:'2026-09-0'+i,bank:'Cora',description:'Lanc ficticio '+i,amount:1000*i,kind:'Receita',...x});
const san={version:1,states:{'docs-visa':'bad'},evidence:{},notes:{},responsible:{},due:{},updated:{}};
const acad={version:1,settings:{monthly:111,hours:22,target:25,minimum:10,tax:0,rates:{}},materials:[],equipment:[],sessions:[],customPops:[],checks:{},training:[]};
const reload=async p=>{await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:120000})};
async function restore(p,file){await p.evaluate(()=>go('backup'));const nav=p.waitForNavigation({timeout:30000}).catch(()=>null);await p.setInputFiles('#backup-load',file);await Promise.race([nav,p.waitForTimeout(3000)]);await reload(p);}
const hashes=async p=>{const r=await L.rawStore(p);const o={};for(const k in r)o[k.replace(L.PREFIX,'')]=r[k].hash;return o};
(async()=>{const b=await L.browser();
 // A: formato do backup geral
 {const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([row(1),row(2)]),'ma-academy-v55':JSON.stringify(acad),'ma61-sanitary-checklist-v1':JSON.stringify(san),'ma56-project-checklist-v1':JSON.stringify({version:1,states:{},updated:{}})}});const p=r.page;
  const [dl]=await Promise.all([p.waitForEvent('download'),p.evaluate(()=>{go('backup');document.getElementById('backup-save').click()})]);
  await dl.saveAs('bk_main.json');const j=JSON.parse(fs.readFileSync('bk_main.json','utf8'));
  const top=Object.keys(j);const hasExtra=['academy','sanitary','checklist56','ma56','ma61'].filter(k=>top.includes(k));
  L.record('BKP-01','Backup geral: formato manfrin-arnez-backup v2 com care, ledger e rateSettings',(j.format==='manfrin-arnez-backup'&&j.version===2&&j.care?.version===2&&Array.isArray(j.ledger)&&j.ledger.length===2&&'rateSettings' in j)?'APROVADO':'REPROVADO',`campos de topo=[${top.join(', ')}]; pacientes=${j.care?.patients?.length}; lançamentos=${j.ledger?.length}; arquivo=${dl.suggestedFilename()}`);
  L.record('BKP-02','Backup geral cobre TODOS os conjuntos de dados (Academia, checklist 5.6, Central Sanitária)?',hasExtra.length?'APROVADO':'REPROVADO',`o backup geral NÃO contém Academia/checklist 5.6/Central Sanitária mesmo existindo no armazenamento (campos extras presentes: ${hasExtra.length}) → restaurar o backup geral sozinho não recupera 3 dos 5 conjuntos; exigem backups separados (VERMELHO se o usuário confiar só no geral)`,{vermelho:!hasExtra.length});
  L.record('BKP-02b','Backup geral inclui as flags do app 6.1 (Banner de ambiente, versão do app)?','AMARELO',`campos meta/appVersion ausentes=${!('meta' in j)&&!('appVersion' in j)} → restauração não sabe a procedência do arquivo`);
  await r.ctx.close();}
 // B: restore com campos extras desconhecidos + chaves não tocadas
 {const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([row(1)]),'ma-academy-v55':JSON.stringify(acad),'ma61-sanitary-checklist-v1':JSON.stringify(san)}});const p=r.page;
  const h0=await hashes(p);
  const bk=JSON.parse(fs.readFileSync('bk_restore.json','utf8'));bk.academy={version:1,settings:{monthly:9999}};bk.sanitary={version:1,states:{'docs-visa':'ok'}};bk.meta={appVersion:'6.2-teste',createdBy:'t'};bk.extraUnknown=[1,2,3];
  fs.writeFileSync('bk_extra.json',JSON.stringify(bk));
  await restore(p,'bk_extra.json');
  const h1=await hashes(p);const led=JSON.parse((await read(p,'ma-ledger-v1'))||'[]').map(x=>x.description);
  const same=h0['ma-academy-v55']===h1['ma-academy-v55']&&h0['ma61-sanitary-checklist-v1']===h1['ma61-sanitary-checklist-v1'];
  L.record('BKP-03','Backup com campos extras desconhecidos (academy, sanitary, meta) é aceito e os extras são ignorados sem apagar nada',(led.length===1&&led[0]==='Restaurado ficticio'&&same)?'APROVADO':'REPROVADO',`ledger restaurado=[${led.join(';')}]; Academia e Sanitário intactos (hash)=${same}; erros de console=${r.errors.length}; diálogos=${r.dialogs.map(d=>d.slice(0,50)).join(' | ')}`);
  await r.ctx.close();}
 // C: mesclagem idempotente
 {const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([row(1)])}});const p=r.page;
  await p.setInputFiles('#ma53-merge-file','bk_merge.json');await p.waitForTimeout(2500);
  const n1=JSON.parse(await read(p,'ma-ledger-v1')).length;const care1=JSON.parse(await read(p,'ma-care-v2')).patients.length;
  await p.reload();await reload(p);
  await p.setInputFiles('#ma53-merge-file','bk_merge.json');await p.waitForTimeout(2500);
  const st=JSON.parse(await read(p,'ma-ledger-v1'));const care2=JSON.parse(await read(p,'ma-care-v2')).patients.length;
  const ids=new Set(st.map(x=>x.id));
  L.record('BKP-04','Mesclar o mesmo backup duas vezes não duplica lançamentos nem pacientes',(st.length===n1&&ids.size===st.length&&care2===care1)?'APROVADO':'REPROVADO',`lançamentos após 1ª=${n1}, após 2ª=${st.length} (ids únicos=${ids.size}); pacientes ${care1}→${care2}`);
  await r.ctx.close();}
 // D: restaurações inválidas
 {const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([row(1)])}});const p=r.page;
  const base=JSON.parse(fs.readFileSync('bk_restore.json','utf8'));
  const cases=[['versão 3',{...base,version:3}],['formato errado',{...base,format:'x'}],['sem care',{format:base.format,version:2,ledger:base.ledger}],['ledger não-array',{...base,ledger:'oops'}],['care v1',{...base,care:{...base.care,version:1}}]];
  const h0=await hashes(p);const res=[];
  for(const [n,pl] of cases){fs.writeFileSync('bk_bad.json',JSON.stringify(pl));await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_bad.json');await p.waitForTimeout(1200);const h=await hashes(p);res.push(n+':'+(JSON.stringify(h)===JSON.stringify(h0)?'rejeitado':'ALTEROU'))}
  L.record('BKP-05','Restauração rejeita backups inválidos sem alterar o armazenamento',res.every(x=>x.endsWith('rejeitado'))?'APROVADO':'REPROVADO',res.join('; '));
  await r.ctx.close();}
 // E: Academia ida-e-volta
 {const r=await L.openDev(b,{seed:{'ma-academy-v55':JSON.stringify(acad)}});const p=r.page;
  await p.evaluate(()=>go('ma55-cost'));
  const [dl]=await Promise.all([p.waitForEvent('download'),p.click('#m55-export')]);await dl.saveAs('acad_export.json');const ex=JSON.parse(fs.readFileSync('acad_export.json','utf8'));
  await p.evaluate(()=>{const set=(i,v)=>{const e=document.getElementById(i);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('m55-monthly','5');set('m55-hours','5');set('m55-target','25');set('m55-minimum','10');set('m55-tax','0');document.getElementById('m55-config-save').click()});await p.waitForTimeout(500);
  const mid=JSON.parse(await read(p,'ma-academy-v55')).settings.monthly;
  await p.setInputFiles('#m55-import','acad_export.json');await p.waitForTimeout(800);
  const end=JSON.parse(await read(p,'ma-academy-v55'));
  L.record('BKP-06','Backup da Academia (5.5): ida e volta',(ex.format==='manfrin-arnez-academy-backup'&&end.settings.monthly===111&&mid===5)?'APROVADO':'REPROVADO',`formato=${ex.format}; mensal original=111 → alterado=${mid} → após importar=${end.settings.monthly}`);
  fs.writeFileSync('acad_bad.json',JSON.stringify({format:'manfrin-arnez-academy-backup',data:{version:9}}));const bef=await read(p,'ma-academy-v55');await p.setInputFiles('#m55-import','acad_bad.json');await p.waitForTimeout(500);
  L.record('BKP-06b','Importação da Academia rejeita arquivo inválido sem alterar dados',(await read(p,'ma-academy-v55'))===bef?'APROVADO':'REPROVADO','versão 9 / arrays ausentes');
  await r.ctx.close();}
 // F: checklist 5.6 ida-e-volta
 {const r=await L.openDev(b);const p=r.page;
  try{await p.evaluate(()=>go('ma56-project'));
   const info=await p.evaluate(()=>{const s=document.querySelector('#ma56-tasks select');return s?{n:document.querySelectorAll('#ma56-tasks select').length,val:s.value,opts:[...s.options].map(o=>o.value)}:null});
   if(!info)throw Error('sem select');
   const flip=(i)=>p.evaluate(i=>{const ss=document.querySelectorAll('#ma56-tasks select');const s=ss[i];const o=[...s.options].map(o=>o.value);s.value=o[(o.indexOf(s.value)+1)%o.length];s.dispatchEvent(new Event('change',{bubbles:true}));return s.value},i);
   await flip(0);await p.waitForTimeout(300);const st1=await read(p,'ma56-project-checklist-v1');
   const [dl]=await Promise.all([p.waitForEvent('download'),p.click('#ma56-export')]);await dl.saveAs('ck56.json');const ex=JSON.parse(fs.readFileSync('ck56.json','utf8'));
   await flip(1);await flip(0);await p.waitForTimeout(300);
   await p.setInputFiles('#ma56-import','ck56.json');await p.waitForTimeout(800);
   const st2=JSON.parse(await read(p,'ma56-project-checklist-v1'));
   const keep=JSON.stringify(st2.states)===JSON.stringify(JSON.parse(st1).states);
   L.record('BKP-07','Checklist 5.6 (Central de Desenvolvimento): ida e volta',(ex.format==='manfrin-arnez-ma56-checklist'&&keep)?'APROVADO':'REPROVADO',`formato=${ex.format}; ${info.n} itens; estados iguais após importar=${keep}`);
  }catch(e){L.record('BKP-07','Checklist 5.6: ida e volta','NÃO TESTADO','falha de automação: '+e.message.slice(0,100))}
  // export-only
  const [d2]=await Promise.all([p.waitForEvent('download'),p.evaluate(()=>{go('ma55-academy');const bt=[...document.querySelectorAll('#ma55-academy button')].find(x=>x.textContent.includes('Estúdio visual'));bt?.click();document.getElementById('ma58-export').click()})]).catch(()=>[null]);
  if(d2){await d2.saveAs('ma58.json');const e2=JSON.parse(fs.readFileSync('ma58.json','utf8'));L.record('BKP-08','Estúdio de maquiagem 5.8: exporta, mas não existe importação correspondente','AMARELO',`formato exportado=${e2.format||Object.keys(e2).join(',')}; sem leitor no código (ver BKP-09)`)}
  else L.record('BKP-08','Estúdio de maquiagem 5.8: exportação','NÃO TESTADO','botão não acionou download');
  await r.ctx.close();}
 // H: CSV com fórmula + exclusão sem confirmação
 {const r=await L.openDev(b);const p=r.page;
  await p.evaluate(()=>{go('ledger');const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value='=HYPERLINK("http://exemplo.invalido","x")';f.elements.amount.value='10';f.requestSubmit()});await p.waitForTimeout(500);
  const [dl]=await Promise.all([p.waitForEvent('download'),p.evaluate(()=>document.getElementById('export').click())]);await dl.saveAs('csv_inj.csv');const csv=fs.readFileSync('csv_inj.csv','utf8');
  const line=csv.split('\n').find(l=>l.includes('HYPERLINK'))||'';
  const cellStart=/;"?=HYPERLINK/.test(line)||/;=HYPERLINK/.test(line);
  L.record('P2-2','CSV exportado neutraliza fórmulas (injeção de planilha)',cellStart?'REPROVADO':'APROVADO',`célula da descrição começa com "=": ${cellStart}`,{amarelo:cellStart});
  const n0=r.dialogs.length;
  const delInfo=await p.evaluate(()=>{go('ledger');document.getElementById('month').value='';document.getElementById('month').dispatchEvent(new Event('input'));const btn=[...document.querySelectorAll('#transactions button')].find(x=>/exclu|remov|apag|×|✕|delete/i.test(x.textContent+x.getAttribute('aria-label')+x.title));if(!btn)return {found:false};btn.click();return {found:true,left:JSON.parse(localStorage.getItem('ma-ledger-v1')||'[]').length}});
  await p.waitForTimeout(400);
  L.record('P2-3','Excluir lançamento exige confirmação',!delInfo.found?'NÃO TESTADO':(r.dialogs.length>n0?'APROVADO':'REPROVADO'),`botão de exclusão encontrado=${delInfo.found}; diálogos de confirmação=${r.dialogs.length-n0}; lançamentos restantes=${delInfo.left}`,{amarelo:delInfo.found&&r.dialogs.length===n0});
  await r.ctx.close();}
 // I: cota saturada
 {const r=await L.openDev(b);const p=r.page;
  const q=await p.evaluate(()=>{let n=0;for(const size of [200000,50000,5000,500,50,5,1]){for(;;){try{localStorage.setItem('__fill'+(n++),'x'.repeat(size))}catch(e){n--;break}}}
   return n});
  const before=await p.evaluate(()=>JSON.parse(localStorage.getItem('ma-care-v2')).patients.length);
  await p.evaluate(()=>{document.getElementById('new-patient')||0;go('patients');document.getElementById('new-patient').click();const f=document.getElementById('patient-form');f.elements.name.value='Paciente sob cota cheia';f.requestSubmit()});await p.waitForTimeout(800);
  const after=await p.evaluate(()=>({n:JSON.parse(localStorage.getItem('ma-care-v2')).patients.length,saved:localStorage.getItem('ma-care-v2').includes('Paciente sob cota cheia')}));
  const ui=await p.evaluate(()=>document.body.innerText.match(/[^.\n]*(falha|erro|espaço|cota|não foi possível)[^.\n]*/i)?.[0]?.slice(0,160)||'(nenhuma mensagem de erro visível)');
  L.record('QUOTA-01','Cota saturada: cadastro de paciente falha e o usuário é avisado?',after.saved?'NÃO TESTADO':(/\(nenhuma/.test(ui)?'REPROVADO':'APROVADO'),`armazenamento saturado com ${q} blocos de preenchimento; paciente gravado=${after.saved}; mensagem na tela="${ui}"; dado anterior preservado (${before}→${after.n} pacientes)`,{amarelo:/\(nenhuma/.test(ui)&&!after.saved});
  await r.ctx.close();}
 // J: contexto inseguro (http em IP não-loopback)
 {const ip=require('os').networkInterfaces();let addr=null;for(const k in ip)for(const a of ip[k])if(a.family==='IPv4'&&!a.internal)addr=a.address;
  if(!addr){L.record('SEC-01','crypto.randomUUID em http não-loopback','NÃO TESTADO','sem IP não-loopback no ambiente')}
  else{const srv=spawn('python3',['-m','http.server','8766','--bind','0.0.0.0'],{cwd:require('path').resolve(__dirname,'..'),stdio:'ignore'});await new Promise(r=>setTimeout(r,1200));
   try{const ctx=await b.newContext();const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message.slice(0,120)));p.on('dialog',d=>d.accept());
    await p.goto(`http://${addr}:8766/dev.html`,{timeout:120000});await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true,null,{timeout:120000}).catch(()=>{});await p.waitForTimeout(3000);
    const s=await p.evaluate(()=>({secure:isSecureContext,uuid:typeof crypto.randomUUID,ready:!!document.querySelector('#ma56-home')}));
    L.record('SEC-01','Aberto por http em IP de rede (contexto inseguro): crypto.randomUUID disponível?',s.uuid==='function'?'APROVADO':'REPROVADO',`isSecureContext=${s.secure}; typeof crypto.randomUUID=${s.uuid}; app inicializou=${s.ready}; erros=${errs.length} ${errs.slice(0,2).join('|')}`,{amarelo:s.uuid!=='function'});
    await ctx.close();}catch(e){L.record('SEC-01','crypto.randomUUID em http não-loopback','NÃO TESTADO',e.message.slice(0,100))}
   srv.kill();}}
 fs.writeFileSync('t6.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('t6.json',JSON.stringify(L.results,null,1));process.exit(1)});
