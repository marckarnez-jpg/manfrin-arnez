// B11: pagamentos, evoluções, contabilidade, backups antigos, independência cadastro x livro-caixa
const B=require('./b_lib');const {L,R,fs}=B;
const care=()=>B_get('ma-care-v2');
async function chosePatient(p,searchId,resultsId,name){
  await p.evaluate(x=>go(x),searchId==='quick-search'?'quick':'notes');
  await p.fill('#'+searchId,name);await p.waitForTimeout(600);
  const ok=await p.evaluate(rid=>{const b=document.querySelector('#'+rid+' button, #'+rid+' [data-id], #'+rid+' li, #'+rid+' div');if(!b)return false;b.click();return true},resultsId);
  await p.waitForTimeout(400);return ok}
const getCare=async p=>JSON.parse((await B.appKeys(p))['ma-care-v2']||'null');
(async()=>{const b=await L.browser();let r,p,k,c0,c1;
 // --- pagamento + contabilidade + evolução com livro íntegro
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(3))}});p=r.page;
 c0=await getCare(p);const n0=c0?c0.records.length:null;
 const sel=await chosePatient(p,'quick-search','quick-results','Paciente');
 const chosen=await p.evaluate(()=>document.getElementById('chosen-patient').textContent.slice(0,80));
 await p.evaluate(()=>{const f=document.getElementById('payment-form');f.elements.date.value='2026-10-05';f.elements.amount.value='123.45';f.elements.service.value='Servico ficticio B11';f.elements.payment.value='Pix';f.requestSubmit()});await p.waitForTimeout(700);
 c1=await getCare(p);const pm=await p.evaluate(()=>document.getElementById('payment-message').textContent);
 const rec=c1&&c1.records.find(x=>x.service==='Servico ficticio B11');
 R('B-110','Pagamentos: registrar pagamento de paciente fictício grava no cadastro',!!rec&&c1.records.length===n0+1,`paciente escolhido="${chosen}"; registros ${n0}→${c1&&c1.records.length}; valor gravado=${rec&&(rec.amount)}; msg="${pm.slice(0,70)}"`,'VERMELHO');
 // contabilidade
 const acc=await p.evaluate(()=>{go('accounting');const m=document.getElementById('account-month');m.value='2026-10';m.dispatchEvent(new Event('input',{bubbles:true}));m.dispatchEvent(new Event('change',{bubbles:true}));return document.getElementById('accounting').innerText.includes('Servico ficticio B11')});await p.waitForTimeout(400);
 const accTxt=await p.evaluate(()=>document.getElementById('accounting').innerText.includes('Servico ficticio B11'));
 let dl=await B.tryDownload(p,()=>document.getElementById('account-export').click(),6000);const csv=await B.saveDl(dl,'acc_b111.csv');
 R('B-111','Contabilidade: o pagamento aparece no mês e o CSV exportado o contém',accTxt&&!!csv&&/Servico ficticio B11/.test(csv),`na tela=${accTxt}; CSV=${!!csv}; contém=${csv&&/Servico ficticio B11/.test(csv)}; linhas CSV=${csv&&csv.trim().split('\n').length}`,'VERMELHO');
 // persistência após recarregar
 await p.reload();await B.reloadWait(p);c1=await getCare(p);
 R('B-112','Pagamento persiste após recarregar',!!c1.records.find(x=>x.service==='Servico ficticio B11'),`registros=${c1.records.length}`,'VERMELHO');
 // evoluções: na tela só existe a biblioteca de modelos (o rascunho por paciente fica oculto em #legacy-notes-preserved)
 const tm=await p.evaluate(()=>{go('notes');const g=document.getElementById('template-group'),st=document.getElementById('template-stage'),t=document.getElementById('template-text');const out=[];
   for(const o of [...g.options]){g.value=o.value;g.dispatchEvent(new Event('change',{bubbles:true}));out.push({g:o.textContent.trim().slice(0,20),stages:st.options.length,len:t.value.length})}
   return {out,hiddenForm:!!document.getElementById('legacy-notes-preserved')?.hidden,copyBtn:!!document.getElementById('template-copy')}});
 R('B-113','Evoluções: biblioteca de modelos (canal, coroa, implante, placa) carrega texto para todas as opções; o rascunho por paciente segue preservado e oculto',tm.out.length>=4&&tm.out.every(x=>x.len>50&&x.stages>0)&&tm.copyBtn,`grupos=${tm.out.map(x=>x.g+':'+x.stages+' etapas/'+x.len+' car.').join('; ')}; rascunho por paciente oculto=${tm.hiddenForm}`,'VERMELHO');
 // backup depois (livro íntegro) contém registros e evolução
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},8000);const bt=await B.saveDl(dl,'bk_b114.json');const bj=bt&&JSON.parse(bt);
 R('B-114','Backup geral com livro íntegro inclui o pagamento novo',!!bj&&bj.care.records.some(x=>x.service==='Servico ficticio B11'),`pagamentos no backup=${bj&&bj.care.records.length}; evoluções=${bj&&bj.care.notes.length}`,'VERMELHO');
 R('B-115','Console sem erros (pagamentos, contabilidade, evoluções)',r.errors.length===0,`erros=${r.errors.length} ${r.errors.slice(0,2).join('|')}`,'AMARELO');
 await r.ctx.close();
 // --- cadastro independente do livro-caixa bloqueado
 const RAW='[{"id":"Cora:X1","date":';
 r=await L.openDev(b,{seed:{'ma-ledger-v1':RAW}});p=r.page;c0=await getCare(p);
 await chosePatient(p,'quick-search','quick-results','Paciente');
 await p.evaluate(()=>{const f=document.getElementById('payment-form');f.elements.date.value='2026-10-06';f.elements.amount.value='50';f.elements.service.value='Pagto com livro bloqueado';f.requestSubmit()});await p.waitForTimeout(700);
 c1=await getCare(p);k=await B.appKeys(p);
 R('B-116','Livro-caixa bloqueado NÃO impede registrar pagamento no cadastro; texto do livro segue intacto',c1.records.length===c0.records.length+1&&k['ma-ledger-v1']===RAW,`registros ${c0.records.length}→${c1.records.length}; livro intacto=${k['ma-ledger-v1']===RAW}`,'VERMELHO');
 const tm2=await p.evaluate(()=>{go('notes');return document.getElementById('template-text').value.length});
 R('B-117','Livro-caixa bloqueado não afeta a biblioteca de modelos de evolução',tm2>50,`texto do modelo=${tm2} caracteres`,'AMARELO');
 await r.ctx.close();
 // --- backups antigos: formato 6.1 com pagamentos e evolução (ida e volta)
 const base=JSON.parse(fs.readFileSync('bk_b114.json','utf8'));
 const old61={format:'manfrin-arnez-backup',version:2,care:{version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[{id:'r1',patientId:'pz',date:'2026-09-02',month:'2026-09',amount:20000,service:'Antigo A',payment:'Pix'}],notes:[{id:'n1',patientId:'pz',date:'2026-09-02',tooth:'',text:'Evolucao antiga ficticia'}]},ledger:[B.mkRows(2)[0]],rateSettings:{}};
 // reaproveita o formato real dos registros a partir do backup gerado pela própria dev.2
 const sampleRec=base.care.records.find(x=>x.service==='Servico ficticio B11');
 const pid=base.care.patients[0].id;
 old61.care.patients=[base.care.patients[0]];old61.care.records=[{...sampleRec,id:'rA',patientId:pid,service:'Antigo A'}];old61.care.notes=[{id:'nA',patientId:pid,date:'2026-09-02',tooth:'',text:'Evolucao antiga ficticia',done:false}];
 fs.writeFileSync('bk_old61.json',JSON.stringify(old61));
 r=await L.openDev(b,{seed:{}});p=r.page;
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_old61.json');
 await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1500);
 c1=await getCare(p);k=await B.appKeys(p);
 R('B-118','Backup no formato 6.1 (cadastro, pagamento, evolução, livro) restaura corretamente na dev.2',c1&&c1.patients.length===1&&c1.records.length===1&&c1.notes.length===1&&JSON.parse(k['ma-ledger-v1']).length===1,`pacientes=${c1&&c1.patients.length}; pagamentos=${c1&&c1.records.length}; evoluções=${c1&&c1.notes.length}; lançamentos=${JSON.parse(k['ma-ledger-v1']||'[]').length}`,'VERMELHO');
 await chosePatient(p,'quick-search','quick-results','Paciente');
 await p.evaluate(()=>{const f=document.getElementById('payment-form');f.elements.date.value='2026-10-07';f.elements.amount.value='10';f.elements.service.value='Pos restauracao';f.requestSubmit()});await p.waitForTimeout(700);
 dl=await B.tryDownload(p,()=>{go('backup');document.getElementById('backup-save').click()},8000);const b3=await B.saveDl(dl,'bk_b122.json');const j3=b3&&JSON.parse(b3);
 R('B-122','Depois de restaurar, novo pagamento convive com pagamento e evolução antigos; o backup seguinte leva os três',!!j3&&j3.care.records.length===2&&j3.care.notes.length===1&&j3.care.notes[0].text==='Evolucao antiga ficticia',`pagamentos=${j3&&j3.care.records.length}; evoluções=${j3&&j3.care.notes.length}`,'VERMELHO');
 await r.ctx.close();
 // --- backup antigo com registro legado: restauração e mesclagem
 const oldLeg={...old61,ledger:[B.mkRows(2)[0],{id:'Itau:9',date:'2026-09-09',bank:'Itau',description:'legado de backup antigo',amount:500,kind:'Receita'}]};
 fs.writeFileSync('bk_old_legacy.json',JSON.stringify(oldLeg));
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(1))}});p=r.page;const before=(await B.appKeys(p))['ma-ledger-v1'];
 await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load','bk_old_legacy.json');await p.waitForTimeout(1500);
 const mr=await B.bmsg(p);k=await B.appKeys(p);
 R('B-119','Backup antigo com um registro legado (banco "Itau"): a restauração é RECUSADA sem alterar nada (limitação que o A5 precisa tratar)',k['ma-ledger-v1']===before&&/inválid/i.test(mr),`msg="${mr.slice(0,80)}"; livro intacto=${k['ma-ledger-v1']===before}. Consequência: os registros que a leitura nova preserva e a 6.1 exportava não podem ser restaurados por backup`,'AMARELO');
 // mesclagem aceita
 await p.evaluate(()=>go('accounting'));
 const [dlm]=await Promise.all([p.waitForEvent('download',{timeout:30000}).catch(()=>null),p.setInputFiles('#ma53-merge-file','bk_old_legacy.json').then(()=>p.waitForTimeout(1500))]);
 k=await B.appKeys(p);const led=JSON.parse(k['ma-ledger-v1']);
 R('B-120','Mesclagem do mesmo backup antigo: os dados entram (incluindo o legado), mas a tela só atualiza ao recarregar (A4)',led.some(x=>x.id==='Itau:9'),`lançamentos no armazenamento=${led.length}; legado entrou=${led.some(x=>x.id==='Itau:9')}; snapshot ANTES-MESCLAR baixado=${!!dlm}`,'AMARELO',{info:true});
 await p.reload();await B.reloadWait(p);
 const sh=await B.shown(p);const ai=await B.alertInfo(p);
 R('B-121','Após recarregar, o legado mesclado aparece marcado e a faixa avisa',sh===led.length&&!!ai&&/antigos fora do padrão/.test(ai.text),`linhas=${sh}/${led.length}; faixa="${ai&&ai.text.slice(0,120)}"`,'AMARELO');
 await r.ctx.close();
 fs.writeFileSync('r_b11.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b11.json',JSON.stringify(L.results,null,1));process.exit(1)});
