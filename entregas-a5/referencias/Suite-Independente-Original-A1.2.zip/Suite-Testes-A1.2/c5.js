// C5: A1.2 — acúmulo de cópias por operação até esgotar a cota real (AJ-14/15): quantas operações cabem e o que acontece depois
const B=require('./b_lib');const {L,R,fs}=B;
(async()=>{const b=await L.browser();
 for(const N of [500,1500]){
 const seed=JSON.stringify(B.mkRows(N));
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':seed}});const p=r.page;
 const total=async()=>{const raw=await L.rawStore(p);let t=0;for(const k in raw)t+=raw[k].len+k.length;return t};
 const t0=await total();let ops=0,m='',first=null;
 for(;ops<150;ops++){m=await B.addRow(p,'op '+ops,'1');if(/bloqueada|Não foi possível/i.test(m)){first=ops;break}}
 const t1=await total();const k=await B.appKeys(p);const sn=Object.keys(k).filter(x=>x.includes('session-prev-')).length;
 const ai=await B.alertInfo(p);
 R('C-81-'+N,'AJ-14/15: ledger de '+N+' linhas ('+seed.length+' caracteres) — operações consecutivas até a primeira recusa por cota',first!==null,`operações gravadas antes da recusa=${first===null?'>150 (sem recusa)':first}; cópias por operação acumuladas=${sn}; armazenamento usado ${t0} -> ${t1} caracteres; msg="${m.slice(0,130)}"; botões da faixa=${ai&&ai.btns.join(' | ')}; existe controle para APAGAR cópias antigas=${!!(ai&&ai.btns.some(x=>/apagar|excluir|limpar|remover/i.test(x)))}`,'AMARELO',{info:true});
 await r.ctx.close();}
 await b.close();
})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_c5.json',JSON.stringify(L.results,null,1));process.exit(1)}).then(()=>fs.writeFileSync('r_c5.json',JSON.stringify(L.results,null,1)));
