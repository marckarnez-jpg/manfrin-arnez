// B3: AJ-3 — registros antigos. Roda contra DEV_FILE (dev.2) e, com TAG=old, contra a 6.1 DEV para comparar.
const B=require('./b_lib');const {L,R,fs}=B;const TAG=process.env.TAG||'new';
const row=(i,x={})=>({id:'Cora:T'+i,date:'2026-09-0'+i,bank:'Cora',description:'Lanc ficticio '+i,amount:1000*i,kind:'Receita',...x});
const cases=[
 ['válida',row(1)],['banco fora de Cora/Sicredi',row(2,{id:'X:2',bank:'Outro'})],['valor zero',row(3,{id:'X:3',amount:0})],
 ['valor fracionário',row(4,{id:'X:4',amount:1050.5})],['categoria desconhecida',row(5,{id:'X:5',kind:'Pix'})],['descrição vazia',row(6,{id:'X:6',description:''})],
 ['data inexistente 30/02',row(7,{id:'X:7',date:'2026-02-30'})],['data com barras',row(8,{id:'X:8',date:'2026/09/08'})],['receita negativa',row(9,{id:'X:9',amount:-500})],
 ['id numérico',row(1,{id:12345})],['sem categoria',(()=>{const x=row(2,{id:'X:11'});delete x.kind;return x})()],['campo extra',row(3,{id:'X:12',nota:'campo extra'})]];
(async()=>{const b=await L.browser();let r,p,k;
 const raw=JSON.stringify(cases.map(c=>c[1]));
 r=await L.openDev(b,{seed:{'ma-ledger-v1':raw}});p=r.page;
 const snap=await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}));
   return {rows:document.querySelectorAll('#transactions tr').length,sel:document.querySelectorAll('#transactions select[data-row]').length,metrics:document.getElementById('ledger-metrics').innerText.replace(/\s+/g,' '),
   marks:(document.getElementById('transactions').innerText.match(/Registro antigo/g)||[]).length,ids:[...document.querySelectorAll('#transactions select[data-row]')].map(s=>s.dataset.row)}});
 const dash=await p.evaluate(()=>{go('dash');return document.getElementById('dash').innerText.replace(/\s+/g,' ').slice(0,500)});
 k=await B.appKeys(p);const qk=B.qKeys(k);
 fs.writeFileSync('b3_'+TAG+'.json',JSON.stringify({snap,dash,q:qk.length,qrows:qk.length?JSON.parse(k[qk[0]]).rows.map(x=>x.index):[]},null,1));
 console.log(TAG,JSON.stringify(snap),'\nquarentenas',qk.length);
 if(TAG!=='new'){await r.ctx.close();await b.close();return}
 const old=fs.existsSync('b3_old.json')?JSON.parse(fs.readFileSync('b3_old.json')):null;
 const qIdx=new Set(JSON.parse(k[qk[0]]||'{"rows":[]}').rows.map(x=>x.index));
 const strictBad=cases.filter(([n])=>n!=='válida'&&n!=='campo extra'&&n!=='id numérico');
 R('B-30','AJ-3: linhas legíveis pela 6.1 permanecem visíveis (11 de 12 variantes; só linha ilegível vai para quarentena)',snap.sel>=11,`visíveis=${snap.sel} de ${cases.length}; quarentena=${qIdx.size?[...qIdx].join(','):'nenhuma'}`,'AMARELO');
 R('B-31','AJ-3: id NUMÉRICO (a 6.1 exibia) agora vai para quarentena e sai dos totais',!qIdx.has(10),`linha 10 (id numérico) ${qIdx.has(10)?'em QUARENTENA':'visível'}. Critério novo exige id em texto; a 6.1 aceitava qualquer id "verdadeiro"`,'AMARELO');
 if(old){R('B-32','AJ-3: totais da Conciliação iguais aos da 6.1 para o mesmo livro (quando a linha é aceita)',old.snap.metrics===snap.metrics,`6.1: "${old.snap.metrics.slice(0,140)}"  |  dev.2: "${snap.metrics.slice(0,140)}"; linhas 6.1=${old.snap.sel} dev.2=${snap.sel}`,'AMARELO');
  R('B-33','AJ-3: texto da Visão financeira igual ao da 6.1 (fora a faixa)',old.dash.replace(/.*Visão financeira/,'')===snap&&0||true,`(informativo) 6.1 vs dev.2 diferem=${old.dash!==dash}`,'AMARELO',{info:true});}
 // marcações = linhas que falham validRow estrito dentre as visíveis
 R('B-34','AJ-3: cada linha fora do padrão atual recebe a marca "Registro antigo: conferir campos"',snap.marks>=9,`marcas=${snap.marks}; esperado ≥9 (banco, zero, fração, categoria, descrição vazia, data 30/02, data barras, receita negativa, sem categoria)`,'AMARELO');
 // preservação byte a byte ao regravar
 await B.addRow(p,'após legados','10');k=await B.appKeys(p);const after=JSON.parse(k['ma-ledger-v1']);
 const orig=cases.map(c=>c[1]).filter((_,i)=>qIdx.has(i+1)===false);
 const same=orig.every(o=>after.some(a=>JSON.stringify(a)===JSON.stringify(o)));
 R('B-35','AJ-3: ao gravar um lançamento novo os registros antigos continuam idênticos em storage (campo a campo)',same,`antigos preservados idênticos=${same}; linhas gravadas=${after.length}; msg="${await B.msg(p)}"`,'VERMELHO');
 // prev idêntico ao original
 R('B-36','AJ-3: cópia -prev é o texto original, byte a byte',k['ma-ledger-v1-prev']===raw,`prev idêntico=${k['ma-ledger-v1-prev']===raw}`,'VERMELHO');
 // novo lançamento continua estrito
 const strictMsg=await B.addRow(p,'abc','0');
 // categoria em legado com banco inválido
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 const chg=await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row="'+JSON.parse(localStorage.getItem('ma-ledger-v1')).findIndex(x=>x.id==='X:2')+'"]');s.value='A classificar';s.dispatchEvent(new Event('change',{bubbles:true}));return document.getElementById('ledger-message').textContent});await p.waitForTimeout(400);
 k=await B.appKeys(p);const x2=JSON.parse(k['ma-ledger-v1']).find(x=>x.id==='X:2');
 R('B-37','AJ-3: alterar a categoria de um legado (banco inválido) funciona sem apagar nem corromper a linha',!!x2&&(x2.kind==='A classificar'||/não|inválid/i.test(chg)),`kind após mudar=${x2&&x2.kind}; msg="${chg.slice(0,120)}"; banco preservado=${x2&&x2.bank}`,'AMARELO');
 // exportação CSV contém legados
 const dl=await B.tryDownload(p,()=>document.getElementById('export').click(),6000);const csv=await B.saveDl(dl,'exp_b37.csv');
 R('B-38','AJ-3: exportação CSV inclui os registros antigos',!!csv&&/Outro/.test(csv)&&/Lanc ficticio 5|Pix/.test(csv),`linhas CSV=${csv&&csv.split('\n').length}`,'AMARELO');
 // excluir legado
 await p.evaluate(()=>{document.querySelector('#transactions [data-delete="'+JSON.parse(localStorage.getItem('ma-ledger-v1')).findIndex(x=>x.id==='X:3')+'"]').click()});await p.waitForTimeout(400);
 k=await B.appKeys(p);
 R('B-39','AJ-3: excluir registro antigo funciona e só esse registro é removido',!JSON.parse(k['ma-ledger-v1']).some(x=>x.id==='X:3')&&JSON.parse(k['ma-ledger-v1']).some(x=>x.id==='X:2'),`ok`,'AMARELO');
 R('B-40','Erros de console (cenário de registros antigos)',r.errors.length===0,`erros=${r.errors.length} ${r.errors.slice(0,2).join('|')}`,'AMARELO');
 await r.ctx.close();
 // linhas ilegíveis variadas
 const bad=[null,'texto',[1],{},{id:'',date:'2026-09-01',amount:1},{id:'q',date:'',amount:1},{id:'q2',date:'2026-09-01',amount:'100'},{id:'q3',date:20260901,amount:1},{id:'q4',date:'2026-09-01'},{id:'q5',date:'2026-09-01',amount:null}];
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([row(1),...bad])}});p=r.page;
 k=await B.appKeys(p);const qq=B.qKeys(k);const nq=qq.length?JSON.parse(k[qq[0]]).rows.length:0;const sh=await B.shown(p);
 R('B-41','Linhas realmente ilegíveis (null, texto, vazio, valor texto, data numérica...) vão todas para a quarentena sem derrubar o livro',nq===bad.length&&sh===1,`quarentena=${nq}/${bad.length}; visíveis=${sh}; erros=${r.errors.length}`,'VERMELHO');
 await r.ctx.close();
 // XSS
 const P='"><img src=x onerror=window.__xss=1><script>window.__xss=2</script>';
 const xs=[{id:'x1'+P,date:'2026-09-01'+P,bank:'Itau'+P,description:P,amount:100,kind:'Receita'},{id:'x2',date:'2026-09-02',bank:P,description:'<b id=injb>b</b>',amount:-100,kind:P}];
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(xs)}});p=r.page;
 const pgs=await p.evaluate(()=>[...document.querySelectorAll('nav button')].map(x=>x.dataset.page));
 for(const pg of pgs){await p.evaluate(x=>go(x),pg);await p.waitForTimeout(100)}
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});await p.waitForTimeout(300);
 const xr=await p.evaluate(()=>({x:window.__xss,img:document.querySelectorAll('img[src="x"]').length,inj:!!document.getElementById('injb'),scripts:[...document.querySelectorAll('main script')].length}));
 R('B-42','AJ-3: HTML em id/data/banco/descrição/categoria de registro antigo não executa nem injeta elementos (todas as telas)',xr.x===undefined&&!xr.img&&!xr.inj,`window.__xss=${xr.x}; imgs injetadas=${xr.img}; <b> injetado=${xr.inj}`,'VERMELHO');
 await r.ctx.close();
 fs.writeFileSync('r_b3x.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b3x.json',JSON.stringify(L.results,null,1));process.exit(1)});
