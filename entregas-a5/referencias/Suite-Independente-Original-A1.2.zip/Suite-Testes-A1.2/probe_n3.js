const B=require('./b_lib');const {L}=B;
(async()=>{const b=await L.browser();
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(B.mkRows(3))}});const p=r.page;
 const before=await B.alertInfo(p);
 await B.addRow(p,'um','5');
 const out=[];for(const pg of ['ma56-home','dash','accounting','ledger','backup']){await p.evaluate(x=>go(x),pg);const ai=await B.alertInfo(p);out.push(pg+':'+(ai&&ai.shown?'FAIXA':'sem faixa'));}
 await p.reload();await B.reloadWait(p);await p.waitForTimeout(1500);
 const ai2=await B.alertInfo(p);
 console.log(JSON.stringify({antesDeGravar:before&&before.shown?'FAIXA':'sem faixa',depoisDeGravar:out,aposRecarregar:ai2&&ai2.shown?ai2.text.slice(0,200):'sem faixa',btns:ai2&&ai2.btns}));
 await b.close();})();
