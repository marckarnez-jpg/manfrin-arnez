const H=require('./a1lib');const {L,fs,row}=H;
(async()=>{const b=await L.browser();
 const own=[row(1),row(2)];const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(own)}});const p=r.page;
 await p.setInputFiles('#ma53-merge-file','bk_merge_a1.json');await p.waitForTimeout(3500);
 const m=await H.addRow(p,'Novo pos-mescla');console.log('addRow msg:',m.slice(0,80));
 let k=await H.appKeys(p);console.log('antes reload: rows=',JSON.parse(k['ma-ledger-v1']).length,'snap',Object.keys(k).filter(x=>x.includes('session-prev')).length);
 await p.reload({waitUntil:'load'});await p.waitForTimeout(500);await H.reloadWait(p);await p.waitForTimeout(2500);
 k=await H.appKeys(p);console.log('após reload: rows=',JSON.parse(k['ma-ledger-v1']).length,'qkeys',H.qKeys(k).length,'shown',await H.shown(p),'banner',JSON.stringify((await H.banner(p))||null).slice(0,160));
 await b.close();})();
