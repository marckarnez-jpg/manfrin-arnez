// S5b: cota, com critério de consistência tela x armazenamento a cada operação
const H=require('./a1lib');const {L,row,fs}=H;
const stCount=async p=>{const t=await H.get(p,'ma-ledger-v1');try{return JSON.parse(t).length}catch(e){return -1}};
(async()=>{const b=await L.browser();
 for(const mode of ['prev-nao-cabe','prev-cabe-principal-cresce-falha']){
  const S0=[row(1),row(2),row(3)];const RAW=JSON.stringify(S0);
  const r=await L.openDev(b,{seed:{'ma-ledger-v1':RAW}});const p=r.page;await H.shown(p);
  await H.saturate(p);
  const F=mode==='prev-nao-cabe'?100:RAW.length+39+20;
  await H.freeSpace(p,F);
  const steps=[];
  const snap=async(name,msgTxt)=>{const s=await H.shown(p);const c=await stCount(p);steps.push({name,tela:s,gravado:c,ok:s===c,msg:(msgTxt||'').slice(0,60)})};
  let m=await H.addRow(p,'sob cota');await snap('adicionar',m);
  await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row]');s.value='A classificar';s.dispatchEvent(new Event('change',{bubbles:true}))});await p.waitForTimeout(300);
  const catScreen=await p.evaluate(()=>document.querySelector('#transactions select[data-row]').value);
  const catStore=JSON.parse(await H.get(p,'ma-ledger-v1'))[0].kind;
  steps.push({name:'categoria',tela:catScreen,gravado:catStore,ok:catScreen===catStore,msg:await H.msg(p)});
  await p.evaluate(()=>document.querySelector('#transactions [data-delete]').click());await p.waitForTimeout(300);await snap('excluir',await H.msg(p));
  fs.writeFileSync('csv_q.csv','﻿id;data;banco;descricao;valor;categoria\ncq1;2026-10-01;Cora;Importado sob cota;100,00;Receita\n');
  await p.setInputFiles('#csv','csv_q.csv');await p.waitForTimeout(500);await snap('importar CSV',await H.msg(p));
  const k=await H.appKeys(p);
  const consistent=steps.every(s=>s.ok);
  L.record('A1-'+(mode==='prev-nao-cabe'?'56':'57'),`Cota (${mode==='prev-nao-cabe'?'nem a cópia prev cabe':'a cópia prev cabe, o crescimento do principal não'}): tela e armazenamento ficam coerentes após cada operação e nada é perdido sem pedido`,consistent&&('ma-ledger-v1' in k)?'APROVADO':'REPROVADO',
   steps.map(s=>`${s.name}: tela=${s.tela}/gravado=${s.gravado}${s.ok?'':' INCOERENTE'} ("${s.msg}")`).join(' | ')+`; prev ${'ma-ledger-v1-prev' in k?'presente, igual ao original='+(k['ma-ledger-v1-prev']===RAW):'ausente'}`);
  L.record('A1-'+(mode==='prev-nao-cabe'?'58':'59'),`Erros de console sob cota (${mode})`,r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length}`);
  await r.ctx.close();}
 fs.writeFileSync('r_s5b.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s5b.json',JSON.stringify(L.results,null,1));process.exit(1)});
