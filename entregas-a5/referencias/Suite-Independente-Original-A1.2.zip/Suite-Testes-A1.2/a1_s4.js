// S4: duas abas, mesclagem (P0-3), restauração (P1-7), sobrescrita de prev
const H=require('./a1lib');const {L,row,fs}=H;
(async()=>{const b=await L.browser();
 // --- duas abas
 {const ctx=await b.newContext({acceptDownloads:true});
  const mk=async()=>{const pg=await ctx.newPage();pg.on('dialog',d=>d.accept());await pg.goto(L.DEV,{timeout:240000});await pg.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000});return pg};
  const a=await mk(),c=await mk();
  const mA1=await H.addRow(a,'Aba A lanc 1');
  const mB1=await H.addRow(c,'Aba B lanc 1');
  const mA2=await H.addRow(a,'Aba A lanc 2');
  const st=JSON.parse(await H.get(a,'ma-ledger-v1')).map(x=>x.description);
  const bnB=await H.banner(c);
  L.record('A1-40','Duas abas abertas: a aba desatualizada NÃO sobrescreve os lançamentos da outra',(st.includes('Aba A lanc 1')&&st.includes('Aba A lanc 2')&&!st.includes('Aba B lanc 1'))?'APROVADO':'REPROVADO',
   `sequência A1, B1, A2 → principal=[${st.join('; ')}]; aba B recusou gravar (msg "${mB1.slice(0,70)}"); aviso na aba B="${bnB?.text?.slice(0,80)}"`);
  L.record('A1-41','Duas abas: o lançamento digitado na aba B é perdido ou fica visível ao usuário?', /não foi gravado|nada foi gravado|bloquead/i.test(mB1)?'APROVADO':'REPROVADO',`A aba B informa "${mB1.slice(0,90)}", mas o lançamento permanece apenas no formulário/na memória da aba e o livro-caixa da aba fica bloqueado até recarregar (recarregar descarta o que foi digitado). Linhas exibidas na aba B=${await H.shown(c)}`,{amarelo:true});
  // aba B após recarregar vê A
  await c.reload();await H.reloadWait(c);const nB=await H.shown(c);
  const mB2=await H.addRow(c,'Aba B lanc 2');const st2=JSON.parse(await H.get(c,'ma-ledger-v1')).map(x=>x.description);
  L.record('A1-42','Duas abas: após recarregar, a aba B enxerga os dados da A e volta a gravar',(nB===2&&st2.includes('Aba B lanc 2')&&st2.length===3)?'APROVADO':'REPROVADO',`linhas vistas após recarregar=${nB}; principal final=[${st2.join('; ')}]`);
  // a aba A (que não gravou depois) continua operante? ela está desatualizada agora
  const mA3=await H.addRow(a,'Aba A lanc 3');const st3=JSON.parse(await H.get(a,'ma-ledger-v1')).map(x=>x.description);
  L.record('A1-43','Duas abas: aba A, agora desatualizada, também é impedida de sobrescrever',st3.includes('Aba B lanc 2')&&!st3.includes('Aba A lanc 3')?'APROVADO':'REPROVADO',`principal=[${st3.join('; ')}]; mensagem aba A="${mA3.slice(0,70)}"`);
  await ctx.close();}
 // --- mesclagem de backup antigo (P0-3)
 {const own=[row(1),row(2)];const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(own)}});const p=r.page;
  const bk={format:'manfrin-arnez-backup',version:2,care:{version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]},ledger:[row(7,{id:'Cora:OLD7',description:'Do backup antigo A'}),row(8,{id:'Cora:OLD8',description:'Do backup antigo B'}),{id:'Cora:OLDBAD',note:'sem data'}],rateSettings:{}};
  fs.writeFileSync('bk_merge_a1.json',JSON.stringify(bk));
  await p.setInputFiles('#ma53-merge-file','bk_merge_a1.json');await p.waitForTimeout(2500);
  const afterMerge=JSON.parse(await H.get(p,'ma-ledger-v1')).map(x=>x.description||x.id);
  const viewMerge=await H.shown(p);
  const m=await H.addRow(p,'Novo pos-mescla');
  const afterAdd=JSON.parse(await H.get(p,'ma-ledger-v1')).map(x=>x.description||x.id);
  const lost=!afterAdd.includes('Do backup antigo A');
  L.record('A1-44','P0-3 com a A1: a mesclagem deixa de ser apagada pelo próximo lançamento',lost?'REPROVADO':'APROVADO',`após mesclar, principal=[${afterMerge.join('; ')}], linhas exibidas=${viewMerge}; novo lançamento → principal=[${afterAdd.join('; ')}]; mensagem="${m.slice(0,100)}"`,{vermelho:lost});
  L.record('A1-45','P0-3 com a A1: a tela mostra o que foi mesclado sem precisar recarregar',viewMerge===4?'APROVADO':'REPROVADO',`linhas exibidas logo após mesclar=${viewMerge} (esperado 4 válidas ou 5 com a inválida); o novo lançamento foi ${/BLOQUEAD|Alteração externa/i.test(m)?'RECUSADO pela proteção (dados preservados, mas a mesclagem continua sem refletir na tela — correção A4 pendente)':'aceito'}`,{amarelo:true});
  await p.reload();await H.reloadWait(p);
  const k=await H.appKeys(p);const bn=await H.banner(p);const sh=await H.shown(p);
  L.record('A1-46','Após recarregar, linha inválida vinda da mesclagem vai à quarentena e as válidas aparecem',(sh===4&&H.qKeys(k).length>=1)?'APROVADO':'REPROVADO',`linhas exibidas=${sh}; quarentenas=${H.qKeys(k).length}; aviso="${bn?.text?.slice(0,80)}"`);
  await r.ctx.close();}
 // --- restauração + prev
 {const S0=[row(1),row(2)];const r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(S0)}});let p=r.page;
  await H.addRow(p,'Sessao1 lanc');const k1=await H.appKeys(p);const S1=k1['ma-ledger-v1'];
  const bk={format:'manfrin-arnez-backup',version:2,care:{version:2,patients:[{id:'pz',name:'Paciente Ficticio Z',cpf:'',phone:'',email:'',address:'',cep:''}],records:[],notes:[]},ledger:[row(5,{id:'Cora:R5',description:'Restaurado ficticio'})],rateSettings:{}};
  fs.writeFileSync('bk_restore_a1.json',JSON.stringify(bk));
  await p.evaluate(()=>go('backup'));const nav=p.waitForNavigation({timeout:40000}).catch(()=>null);
  await p.setInputFiles('#backup-load','bk_restore_a1.json');await nav;await H.reloadWait(p);
  const k2=await H.appKeys(p);
  L.record('A1-47','Restauração: continua funcionando com a A1 (ledger substituído, página recarrega sem aviso)',(JSON.parse(k2['ma-ledger-v1']).length===1&&!(await H.banner(p)))?'APROVADO':'REPROVADO',`ledger após restaurar=[${JSON.parse(k2['ma-ledger-v1']).map(x=>x.description).join(';')}]; prev ainda guarda o estado pré-restauração da sessão 1=${k2['ma-ledger-v1-prev']===JSON.stringify(S0)}`);
  await H.addRow(p,'Sessao2 apos restaurar');const k3=await H.appKeys(p);
  const s1Gone=!Object.values(k3).some(v=>v&&v.includes('Sessao1 lanc'));
  L.record('A1-48','Restauração + próxima gravação: o estado anterior à restauração continua recuperável?',s1Gone?'REPROVADO':'APROVADO',`depois de restaurar e gravar, nenhum valor armazenado contém o lançamento da sessão 1 = ${s1Gone}; prev agora guarda o estado restaurado, não o anterior. A proteção da A1 NÃO cobre a restauração (P1-7 segue VERMELHO, como o relatório declara).`,{vermelho:s1Gone});
  await r.ctx.close();}
 fs.writeFileSync('r_s4.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s4.json',JSON.stringify(L.results,null,1));process.exit(1)});
