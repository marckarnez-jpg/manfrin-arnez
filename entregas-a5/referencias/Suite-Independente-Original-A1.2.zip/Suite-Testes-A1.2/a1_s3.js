// S3: funcionamento normal (armazenamento vazio), validação mais estrita, quarentenas repetidas
const H=require('./a1lib');const {L,row,fs}=H;
(async()=>{const b=await L.browser();
 // --- normal, sem chave
 let r=await L.openDev(b);let p=r.page;
 const k0=await H.appKeys(p);
 const nb=await H.banner(p);
 await H.addRow(p,'Normal 1','100');const m2=await H.addRow(p,'Normal 2','2500,00');
 let k1=await H.appKeys(p);let m=JSON.parse(k1['ma-ledger-v1']||'[]');
 L.record('A1-30','Livro-caixa inexistente: lançamentos novos gravam normalmente, sem aviso',(!('ma-ledger-v1' in k0)&&!nb&&m.length>=1&&m.some(x=>x.description==='Normal 1'))?'APROVADO':'REPROVADO',`sem chave inicial=${!('ma-ledger-v1' in k0)}; aviso=${nb?'sim':'não'}; gravados=${m.length} [${m.map(x=>x.description+':'+x.amount).join('; ')}]; msg="${m2.slice(0,60)}"`);
 L.record('A1-31','Primeira gravação cria prev = "[]" quando não havia livro-caixa',k1['ma-ledger-v1-prev']==='[]'?'APROVADO':'REPROVADO',`prev=${JSON.stringify(k1['ma-ledger-v1-prev'])}`);
 // categoria, exclusão, CSV, exportação
 await H.toLedger(p);
 await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row]');s.value='A classificar';s.dispatchEvent(new Event('change',{bubbles:true}))});await p.waitForTimeout(300);
 let k2=await H.appKeys(p);const catOk=JSON.parse(k2['ma-ledger-v1']).some(x=>x.kind==='A classificar');
 fs.writeFileSync('csv_ok.csv','﻿id;data;banco;descricao;valor;categoria\ncsv1;2026-10-01;Cora;Importado ficticio;100,00;Receita\ncsv2;2026-10-02;Sicredi;Importado dois;-50,00;Despesa\n');
 await p.setInputFiles('#csv','csv_ok.csv');await p.waitForTimeout(600);
 let k3=await H.appKeys(p);const csvOk=JSON.parse(k3['ma-ledger-v1']).filter(x=>/Importado/.test(x.description)).length;
 const msgCsv=await H.msg(p);
 await p.evaluate(()=>{document.querySelector('#transactions [data-delete]').click()});await p.waitForTimeout(300);
 let k4=await H.appKeys(p);const afterDel=JSON.parse(k4['ma-ledger-v1']).length;
 const [dl]=await Promise.all([p.waitForEvent('download'),p.evaluate(()=>document.getElementById('export').click())]);await dl.saveAs('exp_a1.csv');const csv=fs.readFileSync('exp_a1.csv','utf8');
 L.record('A1-32','Fluxos normais: alterar categoria, importar CSV, excluir, exportar CSV',(catOk&&csvOk===2&&afterDel===JSON.parse(k3['ma-ledger-v1']).length-1&&csv.includes('Importado ficticio'))?'APROVADO':'REPROVADO',`categoria gravada=${catOk}; CSV importado=${csvOk}/2 (msg "${msgCsv.slice(0,60)}"); após exclusão=${afterDel} linhas; CSV exportado contém importado=${csv.includes('Importado ficticio')}`);
 const dashTxt0=await p.evaluate(()=>{go('dash');return document.getElementById('dashboard-ledger')?.innerText?.slice(0,200)||''});
 await p.reload();await H.reloadWait(p);const k5=await H.appKeys(p);
 L.record('A1-33','Persistência após recarregar e reflexo na Visão financeira',(k5['ma-ledger-v1']===k4['ma-ledger-v1']&&/R\$/.test(dashTxt0))?'APROVADO':'REPROVADO',`principal idêntico após reload=${k5['ma-ledger-v1']===k4['ma-ledger-v1']}; painel financeiro="${dashTxt0.replace(/\s+/g,' ').slice(0,100)}"`);
 L.record('A1-34','Erros de console no uso normal',r.errors.length===0?'APROVADO':'REPROVADO',`erros=${r.errors.length} ${r.errors.slice(0,2).join('|')}`);
 await r.ctx.close();
 // --- validação mais estrita que a anterior
 const legacy=r=>!(!r||!r.id||!r.date||!Number.isFinite(r.amount));
 const cases=[
  ['válida',row(1)],
  ['banco fora de Cora/Sicredi',row(2,{id:'X:2',bank:'Outro'})],
  ['valor zero',row(3,{id:'X:3',amount:0})],
  ['valor fracionário (centavos não inteiros)',row(4,{id:'X:4',amount:1050.5})],
  ['categoria desconhecida',row(5,{id:'X:5',kind:'Pix'})],
  ['descrição vazia',row(6,{id:'X:6',description:''})],
  ['data inexistente (30/02)',row(7,{id:'X:7',date:'2026-02-30'})],
  ['data fora do padrão AAAA-MM-DD',row(8,{id:'X:8',date:'2026/09/08'})],
  ['receita com valor negativo',row(9,{id:'X:9',amount:-500})],
  ['id numérico',row(1,{id:12345})],
  ['sem campo categoria',(()=>{const x=row(2,{id:'X:11'});delete x.kind;return x})()],
  ['campo extra desconhecido (nota)',row(3,{id:'X:12',nota:'campo extra'})]];
 const raw=JSON.stringify(cases.map(c=>c[1]));
 r=await L.openDev(b,{seed:{'ma-ledger-v1':raw}});p=r.page;
 const kk=await H.appKeys(p);const qk=H.qKeys(kk);const q=qk.length?JSON.parse(kk[qk[0]]).rows:[];
 const qIdx=new Set(q.map(x=>x.index));
 const lines=cases.map(([n,rw],i)=>`${n}: ${legacy(rw)?'aceita pelo carregador antigo':'recusada também pelo antigo'} → ${qIdx.has(i+1)?'QUARENTENA':'visível'}`);
 const hiddenNew=cases.filter(([n,rw],i)=>legacy(rw)&&qIdx.has(i+1)).map(c=>c[0]);
 L.record('A1-35','Compatibilidade: linhas que o carregador antigo exibia e a leitura nova manda para quarentena',hiddenNew.length?'REPROVADO':'APROVADO',`${hiddenNew.length} de ${cases.length} casos mudaram de comportamento: ${hiddenNew.join('; ')}. Detalhe: ${lines.join(' | ')}`,{amarelo:true});
 const kept=await H.shown(p);
 // campo extra preservado na regravação?
 await H.addRow(p,'após estrito');const k6=await H.appKeys(p);const after=JSON.parse(k6['ma-ledger-v1']);
 L.record('A1-36','Linhas válidas com campo extra desconhecido mantêm o campo na regravação',after.some(x=>x.nota==='campo extra')?'APROVADO':'REPROVADO',`campo "nota" preservado=${after.some(x=>x.nota==='campo extra')}; linhas visíveis antes=${kept}, gravadas depois=${after.length}`);
 // somas da Visão financeira dependem de linhas visíveis
 await r.ctx.close();
 // --- quarentenas repetidas a cada recarga sem gravar
 const badRaw=JSON.stringify([row(1),{id:'Cora:BAD'}]);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':badRaw}});p=r.page;
 for(let i=0;i<2;i++){await p.reload();await H.reloadWait(p);}
 const kq=await H.appKeys(p);const nq=H.qKeys(kq).length;
 L.record('A1-37','Recarregar várias vezes sem gravar não deve multiplicar chaves de quarentena',nq===1?'APROVADO':'REPROVADO',`3 aberturas sem gravar → ${nq} chaves de quarentena idênticas (${Object.keys(kq).filter(k=>k.startsWith('ma-ledger-v1-rej')).join(', ')})`,{amarelo:true});
 await r.ctx.close();
 fs.writeFileSync('r_s3.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);require('fs').writeFileSync('r_s3.json',JSON.stringify(L.results,null,1));process.exit(1)});
