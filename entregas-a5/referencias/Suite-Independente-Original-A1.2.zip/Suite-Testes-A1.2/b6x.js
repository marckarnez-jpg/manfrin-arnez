// B6x: compatibilidade cruzada — a 6.1 DEV lê dados e backups produzidos pela dev.3 (rodar com DEV_FILE=6.1 DEV)
const B=require('./b_lib');const {L,R,fs}=B;
const ok=B.mkRows(2);const leg={id:'Itau:1',date:'2026-09-09',bank:'Itau',description:'legado',amount:500,kind:'Receita'};const num={id:77,date:'2026-09-10',bank:'Cora',description:'num',amount:300,kind:'Receita'};
const Q='ma-ledger-v1-rejeitados-20260101000000';
(async()=>{const b=await L.browser();let r,p,k;
 const extra={'ma-ledger-v1-prev':'[]',[Q]:'{"x":1}',['ma-ledger-v1-quarantine-review:'+Q]:JSON.stringify({version:1,key:Q,originalBody:'{"x":1}',reviewedAt:'2026-10-01T00:00:00Z',acknowledged:true}),'ma-ledger-v1-session-prev-20261001000000000-uuid-1':JSON.stringify(ok)};
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok,leg,num]),...extra}});p=r.page;
 const n=await B.shown(p);await B.addRow(p,'6.1 sobre dados da dev.3','1');k=await B.appKeys(p);
 const intact=Object.keys(extra).every(x=>k[x]===extra[x]);
 R('B-90','6.1 DEV lê o livro da dev.3 (com registro antigo e ID numérico) e grava sem erro; todas as chaves novas (-prev, quarentena, revisão, cópia por operação) permanecem intactas',n===4&&JSON.parse(k['ma-ledger-v1']).length===5&&intact&&r.errors.length===0,`linhas vistas=${n}; após novo=${JSON.parse(k['ma-ledger-v1']).length}; chaves novas intactas=${intact}; erros=${r.errors.length}`,'AMARELO');
 await r.ctx.close();
 for(const [id,f] of [['B-91','bk_c01.json'],['B-91b','bk_c14.json']]){
  const bk=JSON.parse(fs.readFileSync(f,'utf8'));
  r=await L.openDev(b,{seed:{}});p=r.page;
  await p.evaluate(()=>go('backup'));await p.setInputFiles('#backup-load',f);
  for(let i=0;i<60;i++){await new Promise(x=>setTimeout(x,1000));try{const kk=await B.appKeys(p);if(kk['ma-ledger-v1'])break}catch(e){}}
  await p.waitForFunction(()=>window.MA_DEV_SANDBOX===true&&document.querySelector('#ma56-home'),null,{timeout:240000}).catch(()=>{});await p.waitForTimeout(1500);
  k=await B.appKeys(p);
  R(id,'Backup principal gerado pela dev.3 ('+f+') é restaurável na 6.1 DEV',JSON.stringify(JSON.parse(k['ma-ledger-v1']))===JSON.stringify(bk.ledger)&&bk.version===2&&Object.keys(bk).join(',')==='format,version,createdAt,care,ledger,rateSettings',`lançamentos restaurados=${JSON.parse(k['ma-ledger-v1']).length}/${bk.ledger.length}; formato=${bk.format} v${bk.version}; campos=${Object.keys(bk).join(',')}`,'VERMELHO');
  await r.ctx.close();}
 await b.close();})().catch(e=>{console.log('ERR',e.stack)}).then(()=>fs.writeFileSync('r_b6x.json',JSON.stringify(L.results,null,1)));
