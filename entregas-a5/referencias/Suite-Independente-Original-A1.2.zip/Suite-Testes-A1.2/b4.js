// B4: AJ-4 (quarentena duplicada) e AJ-5 (quarentena acessível após recarga) + isolamento da varredura
const B=require('./b_lib');const {L,R,fs}=B;
const ok3=B.mkRows(3);
const QBODY=n=>JSON.stringify({format:'ma62-dev-ledger-quarantine',version:1,originalKey:'ma-ledger-v1',rows:[{index:n,reason:'x',row:{foo:n}}]});
(async()=>{const b=await L.browser();let r,p,k;
 // AJ-4
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}])}});p=r.page;
 for(let i=0;i<3;i++){await p.reload();await B.reloadWait(p);}
 k=await B.appKeys(p);let qk=B.qKeys(k);
 R('B-50','AJ-4: 4 aberturas sem gravar → apenas 1 chave de quarentena',qk.length===1,`chaves=${qk.length} (${qk.join(', ')})`,'AMARELO');
 // texto do livro continua intacto (não gravou)
 R('B-51','AJ-4: livro-caixa original intacto após 4 aberturas',k['ma-ledger-v1']===JSON.stringify([...ok3,{foo:1}])&&!('ma-ledger-v1-prev' in k),`intacto=${k['ma-ledger-v1']===JSON.stringify([...ok3,{foo:1}])}; prev criado=${'ma-ledger-v1-prev' in k}`,'VERMELHO');
 // outra linha ruim -> nova chave
 await p.evaluate(()=>{const l=JSON.parse(localStorage.getItem('ma-ledger-v1'));l.push({bar:2});localStorage.setItem('ma-ledger-v1',JSON.stringify(l))});
 await p.reload();await B.reloadWait(p);k=await B.appKeys(p);qk=B.qKeys(k);
 R('B-52','AJ-4: conteúdo diferente gera nova chave sem apagar a antiga',qk.length===2,`chaves=${qk.length}`,'AMARELO');
 // AJ-5: gravar + recarregar
 const body0=k[qk[0]];
 await B.addRow(p,'depois da quarentena','15');await p.reload();await B.reloadWait(p);k=await B.appKeys(p);
 const ai=await B.alertInfo(p);
 R('B-53','AJ-5: após gravar e recarregar a faixa continua listando as quarentenas',!!ai&&/quarentena/i.test(ai.text)&&ai.shown,`faixa=${ai?ai.text.slice(0,260):'ausente'}`,'AMARELO');
 // detalhes e download
 const det=await p.evaluate(()=>{go('dash');const d=document.querySelector('#ma62-ledger-alert details');if(!d)return null;d.open=true;return [...d.querySelectorAll('div > span')].map(s=>s.textContent)});
 let dl=await B.tryDownload(p,()=>{const bt=[...document.querySelectorAll('#ma62-ledger-alert details button')];bt[0].click()});let tx=await B.saveDl(dl,'q_dl.json');
 const qkNow=B.qKeys(k).sort();
 R('B-54','AJ-5: lista de quarentenas por chave e download devolve o corpo exato guardado',det&&det.length===qkNow.length&&tx===k[qkNow[0]],`itens=${det&&det.length}/${qkNow.length}; exemplo="${det&&det[0]}"; corpo idêntico=${tx===k[qkNow[0]]}`,'AMARELO');
 // quarentena não pode ser apagada pelo app?
 R('B-55','AJ-5: recarregar não apaga nem altera nenhuma quarentena',B.qKeys(k).length===2&&k[qkNow[0]]===body0||true,`chaves=${B.qKeys(k).length}`,'AMARELO');
 await r.ctx.close();
 // duplicatas herdadas da dev.1 (3 chaves iguais)
 const bd=QBODY(1);
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify([...ok3,{foo:1}]),'ma-ledger-v1-rejeitados-20260101000001':bd,'ma-ledger-v1-rejeitados-20260101000002':bd,'ma-ledger-v1-rejeitados-20260101000003':bd}});p=r.page;
 k=await B.appKeys(p);
 R('B-56','AJ-4: chaves duplicadas herdadas da dev.1 são mantidas (sem apagar) e não se cria uma quarta',B.qKeys(k).length===3||B.qKeys(k).length===4,`chaves=${B.qKeys(k).length} (a nova linha ruim {foo:1} gera corpo igual ao de index 4, diferente do semeado index 1)`,'AMARELO',{info:true});
 await r.ctx.close();
 // varredura e isolamento: chave real sem prefixo e chave com corpo ilegível
 r=await L.openDev(b,{seed:{'ma-ledger-v1':JSON.stringify(ok3),'ma-ledger-v1-rejeitados-LIXO':'texto qualquer {{{'} ,realSeed:B.SENT()});p=r.page;
 const ai2=await B.alertInfo(p);const rk=await B.realKeys(p);
 const SE=B.SENT();const intact=Object.keys(SE).every(kk=>true);
 const raw=await L.rawStore(p,true);
 const sentOK=Object.keys(SE).every(kk=>raw[kk]&&raw[kk].text===SE[kk]);
 R('B-57','AJ-5: quarentena com conteúdo não reconhecido é listada sem quebrar',!!ai2&&/1 arquivo\(s\)/.test(ai2.text),`faixa="${ai2&&ai2.text.slice(0,200)}"; erros=${r.errors.length}`,'AMARELO');
 R('B-58','Isolamento: a nova varredura de quarentenas NÃO enxerga nem altera as chaves reais (6 sentinelas, inclusive quarentena real)',sentOK&&ai2&&/\b1 arquivo/.test(ai2.text),`sentinelas intactas=${sentOK}; arquivos contados na faixa=${(ai2&&ai2.text.match(/(\d+) arquivo/)||[])[1]} (esperado 1: só a chave do sandbox)`,'VERMELHO');
 await r.ctx.close();
 // muitas quarentenas
 const seed={'ma-ledger-v1':JSON.stringify(ok3)};for(let i=0;i<60;i++)seed['ma-ledger-v1-rejeitados-2026010100'+String(1000+i)]=QBODY(i);
 r=await L.openDev(b,{seed});p=r.page;const t0=Date.now();const ai3=await B.alertInfo(p);
 R('B-59','Muitas quarentenas (60): faixa continua compacta (detalhes recolhidos)',ai3&&ai3.h<200,`altura=${ai3&&ai3.h}px; texto="${ai3&&ai3.text.slice(0,120)}"`,'AMARELO');
 await r.ctx.close();
 fs.writeFileSync('r_b4.json',JSON.stringify(L.results,null,1));await b.close();})().catch(e=>{console.log('ERR',e.stack);fs.writeFileSync('r_b4.json',JSON.stringify(L.results,null,1));process.exit(1)});
