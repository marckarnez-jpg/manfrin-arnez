// C6: desempenho comparativo (mesmo roteiro em dev.2 e dev.3): 12.000 linhas, gravar 1 lançamento, mudar 1 categoria, excluir 1
const B=require('./b_lib');const {L,fs}=B;
(async()=>{const b=await L.browser();
 const seed=JSON.stringify(B.mkRows(12000));
 const r=await L.openDev(b,{seed:{'ma-ledger-v1':seed}});const p=r.page;
 const t=async(f)=>{const t0=Date.now();const res=await f();return [Date.now()-t0,res]};
 await p.evaluate(()=>{go('ledger');const m=document.getElementById('month');m.value='';m.dispatchEvent(new Event('input',{bubbles:true}))});
 // tempo de submit puro (síncrono dentro da página)
 const w=await p.evaluate(()=>{const f=document.getElementById('transaction');f.elements.date.value='2026-10-05';f.elements.description.value='perf um';f.elements.amount.value='10';const t0=performance.now();f.requestSubmit();return Math.round(performance.now()-t0)});
 await p.waitForTimeout(300);
 const c=await p.evaluate(()=>{const s=document.querySelector('#transactions select[data-row]');s.value='A classificar';const t0=performance.now();s.dispatchEvent(new Event('change',{bubbles:true}));return Math.round(performance.now()-t0)});
 await p.waitForTimeout(300);
 const rend=await p.evaluate(()=>{const t0=performance.now();renderLedger();return Math.round(performance.now()-t0)});
 const bn=await p.evaluate(()=>{const t0=performance.now();ma62LedgerBanner();return Math.round(performance.now()-t0)});
 console.log(JSON.stringify({file:process.env.DEV_FILE.split('/').pop(),loadMs:r.loadMs,gravarNovoLancamentoMs:w,mudarCategoriaMs:c,renderLedgerMs:rend,faixaMs:bn,seedChars:seed.length}));
 await b.close();})().catch(e=>{console.log('ERR',e.message)});
